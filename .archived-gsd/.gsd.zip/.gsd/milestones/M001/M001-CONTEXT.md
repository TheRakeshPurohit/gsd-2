# M001: GSD 2.0 MVP CLI — Context

**Gathered:** 2026-03-10
**Status:** Ready for planning

## Project Description

GSD 2.0 is a branded `npm install -g gsd-pi` CLI that embeds `@mariozechner/pi-coding-agent` via SDK, stores state in `~/.gsd/`, and ships the GSD extension + all supporting extensions as bundled resources. Users run `gsd`, not `pi`. No separate pi installation required.

## Why This Milestone

M001 is the whole product. There is only one milestone: get GSD 2.0 installable, runnable, and publishing-ready. Every requirement maps here.

## User-Visible Outcome

### When this milestone is complete, the user can:

- Run `npm install -g gsd-pi` and have a working branded coding agent installed
- Run `gsd` and see a TUI header that says "gsd" (not "pi")
- Complete the first-run wizard that collects Anthropic, Brave, Context7, and Jina API keys
- Use `/gsd` command, auto-mode, and the GSD dashboard immediately after setup
- Use browser-tools, search-the-web, context7, subagent, and all other bundled extensions
- Run `npm update -g gsd-pi` to get updated bundled resources

### Entry point / environment

- Entry point: `gsd` CLI command (installed globally via npm)
- Environment: macOS terminal (primary), Linux terminal (secondary)
- Live dependencies involved: Anthropic API (required), Brave API (for search), Context7 API (for docs), Jina API (optional for page fetch)

## Completion Class

- Contract complete means: TypeScript compiles, CLI binary works, all extensions load without errors
- Integration complete means: `gsd` launches with correct branding, wizard runs, extensions register tools, `/gsd` command works
- Operational complete means: `npm install -g gsd-pi` in a clean environment produces a working `gsd` binary with no additional setup

## Final Integrated Acceptance

To call this milestone complete, we must prove:

- `npm install -g gsd-pi` in a clean environment (no existing `~/.gsd/`) results in `gsd` binary that launches and shows the TUI with "gsd" branding
- First-run wizard fires on fresh install, collects keys, stores them in `~/.gsd/agent/auth.json`
- `/gsd` command is registered and responds correctly
- All bundled extensions (browser-tools, search-the-web, context7, subagent, bg-shell, etc.) are loaded and their tools are available to the model
- `~/.pi/` is untouched after install and operation

## Risks and Unknowns

- **`PI_PACKAGE_DIR` branding mechanism** — `config.js` reads `piConfig` from the package found by walking up from pi's `__dirname`, not from the consumer's package.json. Setting `PI_PACKAGE_DIR` to the gsd package root before requiring pi internals should work, but needs verification. If it doesn't, we fall back to monkey-patching or accepting pi's default name — retire in S01.
- **Extension dependency chain** — The GSD extension imports from `@mariozechner/pi-coding-agent` internals. When bundled as a copy inside the gsd package, these imports may fail if peer dep resolution doesn't find the right pi version. Must validate that copied extensions resolve correctly — retire in S02.
- **`node_modules` binary resolution** — When `gsd` runs as a global npm binary, `require`/`import` resolution of `@mariozechner/pi-coding-agent` must find the version bundled with gsd, not a user's separate global pi installation. Need to verify npm global install resolution — retire in S01.
- **TypeScript compilation of extension sources** — The GSD extension is `.ts` source. Pi JIT-compiles `.ts` extensions at runtime via jiti. This should still work when extensions are bundled inside the gsd package as long as source maps and `.ts` files are included in the npm publish. Verify in S02.

## Existing Codebase / Prior Art

- `~/.pi/agent/extensions/gsd/` — The GSD extension source (38 TS files, ~14k lines). This is the source to bundle.
- `~/.pi/agent/extensions/` — All other extensions to bundle (bg-shell, browser-tools, context7, search-the-web, shared, slash-commands, subagent, worktree, plan-mode, ask-user-questions.ts, get-secrets-from-user.ts)
- `~/.pi/agent/agents/` — scout.md, researcher.md, worker.md — to bundle as agents
- `~/.pi/AGENTS.md` — Hard rules / execution heuristics — to load as agentsFile
- `~/.pi/agent/extensions/gsd/package.json` — Reference for pi manifest structure
- `/Users/lexchristopherson/.nvm/versions/node/v22.20.0/lib/node_modules/@mariozechner/pi-coding-agent/docs/sdk.md` — SDK API reference
- `/Users/lexchristopherson/.pi/docs/what-is-pi/19-building-branded-apps-on-top-of-pi.md` — Branded app architecture guide (READ THIS BEFORE S01)
- `/Users/lexchristopherson/.nvm/versions/node/v22.20.0/lib/node_modules/@mariozechner/pi-coding-agent/dist/config.js` — How `APP_NAME`, `CONFIG_DIR_NAME`, and `PI_PACKAGE_DIR` work

> See `.gsd/DECISIONS.md` for all architectural and pattern decisions — it is an append-only register; read it during planning, append to it during execution.

## Relevant Requirements

- R001 — Single-command install: the whole point of this milestone
- R002 — Branded identity: drives the PI_PACKAGE_DIR mechanism and ~/.gsd/ layout
- R003, R004, R005 — Bundled extensions/agents/AGENTS.md: drives S02
- R006, R009 — First-run wizard + failure visibility: drives S03
- R007 — Isolated state: must never touch ~/.pi/
- R008 — npm update: drives S04 (publish + update story)

## Scope

### In Scope

- SDK-embedded TypeScript CLI entrypoint (`src/cli.ts`)
- Package setup (`package.json`, `tsconfig.json`, build tooling)
- Branding: `gsd` name, `~/.gsd/` config dir, via `PI_PACKAGE_DIR`
- Bundling: copying extension source + agents + AGENTS.md into `src/resources/`
- `DefaultResourceLoader` configured to load bundled extensions
- First-run wizard: detects missing keys, prompts, stores in `~/.gsd/agent/auth.json`
- npm publish: `bin`, `files`, `prepublishOnly` build step
- npm pack smoke test: verify install from tarball in clean environment

### Out of Scope / Non-Goals

- Custom TUI components or custom layout (reuse `InteractiveMode` as-is)
- Plugin/extension install system (deferred)
- Skills bundling (deferred by user decision)
- Windows support (not targeted for M001)
- CI/CD automation for releases (nice-to-have, not required)
- `pi install npm:gsd` compatibility (explicitly out of scope)

## Technical Constraints

- Must use `@mariozechner/pi-coding-agent` SDK, not spawn `pi` as subprocess
- Extensions must load as `.ts` source (pi uses jiti for JIT compilation) — do not pre-compile them
- Must not read from or write to `~/.pi/`
- Must publish to npm as a scoped or unscoped package named `gsd` (or `@lexc/gsd` if name is taken)
- Node.js ≥ 18 (follow pi's own peer dep constraint)

## Integration Points

- `@mariozechner/pi-coding-agent` — embedded as dependency, SDK + InteractiveMode
- Anthropic API — via pi's AuthStorage/ModelRegistry (key stored in `~/.gsd/agent/auth.json`)
- Brave Search API — BRAVE_API_KEY env var, collected by wizard
- Context7 API — CONTEXT7_API_KEY env var, collected by wizard
- Jina API — JINA_API_KEY env var, collected optionally by wizard

## Open Questions

- **npm package name**: `gsd` is a common-ish name. Check if it's available. If not, use `@lexc/gsd` or `get-shit-done-cli`.
- **PI_PACKAGE_DIR timing**: Must be set before pi's `config.js` is first imported/evaluated. Verify ESM module evaluation order allows this.

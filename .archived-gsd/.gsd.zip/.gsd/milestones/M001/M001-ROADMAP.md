# M001: GSD 2.0 MVP CLI

**Vision:** A single `npm install -g gsd-pi` gives any developer a fully configured, GSD-branded coding agent — with the GSD extension, browser tools, web search, context7, subagent, and all supporting extensions bundled — that stores state in `~/.gsd/`, shows "gsd" branding in the TUI, and guides new users through API key setup on first run.

## Success Criteria

- `npm install -g gsd-pi` in a clean environment produces a working `gsd` binary
- `gsd` TUI header shows "gsd" — no pi branding visible in normal operation
- State lives in `~/.gsd/` — `~/.pi/` is untouched
- First-run wizard fires when API keys are missing, collects them, and stores them
- `/gsd` command is registered and responds correctly
- All bundled extensions load and their tools are available to the model
- `npm update -g gsd-pi` works cleanly on an existing install

## Key Risks / Unknowns

- **PI_PACKAGE_DIR branding timing** — ESM module evaluation order may cause pi's `config.js` to be evaluated before `PI_PACKAGE_DIR` is set. If so, "pi" appears in the TUI header instead of "gsd". Must be proved and resolved in S01.
- **Extension import resolution** — Copied `.ts` extension source imports `@mariozechner/pi-coding-agent` internals. When loaded from inside the gsd package, the import must resolve to gsd's own pi dep, not a user's global pi. Must be proved in S02.

## Proof Strategy

- **PI_PACKAGE_DIR branding timing** → retire in S01 by launching `gsd` and confirming the TUI says "gsd" not "pi"
- **Extension import resolution** → retire in S02 by loading all bundled extensions and confirming all tools register without errors

## Verification Classes

- Contract verification: TypeScript compiles clean, all extension files exist in bundle, `gsd --version` works
- Integration verification: `gsd` launches with correct branding, wizard runs, `/gsd` responds, all extension tools available
- Operational verification: `npm pack` + `npm install -g ./gsd-*.tgz` in a temp directory produces a working `gsd`
- UAT / human verification: Human runs the full flow in a terminal to confirm TUI looks right and wizard works

## Milestone Definition of Done

This milestone is complete only when all are true:

- S01 through S04 are all complete
- `npm pack` + install from tarball works in a clean shell (no existing `~/.gsd/`)
- `gsd` launches, shows "gsd" branding, and wizard runs on first launch
- `/gsd` command works and GSD dashboard is accessible
- All extension tools register (browser, search, context7, subagent, bg-shell, etc.)
- `~/.pi/` is confirmed untouched after full install + run
- Package is published to npm and `npm install -g gsd-pi` works from registry

## Requirement Coverage

- Covers: R001, R002, R003, R004, R005, R006, R007, R008, R009
- Partially covers: none
- Leaves for later: R020 (plugin system), R021 (skills)
- Orphan risks: none

## Slices

- [x] **S01: CLI scaffold and branding** `risk:high` `depends:[]`

  > After this: `gsd` binary exists, launches pi's InteractiveMode, shows "gsd" in the TUI header, and stores state in `~/.gsd/` — verified by running the compiled binary.

- [x] **S02: Bundle extensions and agents** `risk:high` `depends:[S01]`

  > After this: all bundled extensions load without errors, their tools are registered and available to the model, agents and AGENTS.md are loaded — verified by launching `gsd` and checking that browser, search, context7, subagent, and `/gsd` are all available.

- [x] **S03: First-run setup wizard** `risk:medium` `depends:[S01]`

  > After this: first launch with no `~/.gsd/agent/auth.json` triggers the wizard, keys are collected and stored, subsequent launch skips the wizard — verified by deleting `~/.gsd/` and relaunching.

- [x] **S04: npm publish and install smoke test** `risk:low` `depends:[S02,S03]`
  > After this: `npm pack` + `npm install -g ./gsd-*.tgz` in a clean temp directory produces a working `gsd` binary; package is published to npm — verified by running the tarball install and launching `gsd`.

<!--
  Format rules (parsers depend on this exact structure):
  - Checkbox line: - [ ] **S01: Title** `risk:high|medium|low` `depends:[S01,S02]`
  - Demo line:     >  After this: one sentence showing what's demoable
  - Mark done:     change [ ] to [x]
-->

## Boundary Map

### S01 → S02

Produces:

- `src/cli.ts` — CLI entrypoint, sets `PI_PACKAGE_DIR`, creates managers, calls `InteractiveMode`
- `src/app-paths.ts` — `appRoot`, `agentDir`, `sessionsDir` constants for `~/.gsd/`
- `package.json` — with `bin.gsd`, `piConfig: { name: "gsd", configDir: ".gsd" }`, and `@mariozechner/pi-coding-agent` dependency
- Working `gsd` binary with correct branding (no bundled extensions yet)

Consumes:

- nothing (first slice)

### S01 → S03

Produces:

- `src/app-paths.ts` — `agentDir` and `authFilePath` for wizard to read/write
- `src/cli.ts` — `createAgentSession` call that wizard can hook into via `session_start` event

Consumes:

- nothing (first slice)

### S02 → S04

Produces:

- `src/resources/extensions/` — all copied extension source files (gsd, bg-shell, browser-tools, context7, search-the-web, shared, slash-commands, subagent, worktree, plan-mode, ask-user-questions.ts, get-secrets-from-user.ts)
- `src/resources/agents/` — scout.md, researcher.md, worker.md
- `src/resources/AGENTS.md` — hard rules + execution heuristics
- `src/resource-loader.ts` — `buildResourceLoader()` that wires all bundled paths into `DefaultResourceLoader`
- Verified: all tools register on launch

Consumes from S01:

- `src/app-paths.ts` → `agentDir` for resource loader configuration
- Working `gsd` binary to load extensions into

### S03 → S04

Produces:

- `src/wizard.ts` — `runSetupWizardIfNeeded()` that detects missing keys and prompts via pi UI
- Keys stored in `~/.gsd/agent/auth.json` and process env after wizard runs
- Wizard skips on subsequent launches when keys are already configured

Consumes from S01:

- `src/app-paths.ts` → `authFilePath` for key detection and storage
- Session `session_start` event hook surface from `cli.ts`

### S04 (terminal slice)

Produces:

- `package.json` `files` array, `prepublishOnly` build script
- Verified npm pack + install from tarball
- Published package on npm registry

Consumes from S02:

- All bundled extension/agent files in `src/resources/`
- `src/resource-loader.ts`

Consumes from S03:

- `src/wizard.ts`

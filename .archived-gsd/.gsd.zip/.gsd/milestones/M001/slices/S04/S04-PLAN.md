# S04: npm publish and install smoke test

**Goal:** Fix the GSD_BUNDLED_EXTENSION_PATHS double-load bug, resolve pre-S04 uncommitted changes, add prepublishOnly, run a scripted tarball smoke test, and publish @glittercowboy/gsd to npm — so `npm install -g @glittercowboy/gsd` works from the registry.
**Demo:** After this: `npm pack` + `npm install -g ./glittercowboy-gsd-*.tgz` in a temp prefix produces a working `gsd` binary; `npm install -g @glittercowboy/gsd` from the npm registry also works; the full milestone is shippable.

## Must-Haves

- `GSD_BUNDLED_EXTENSION_PATHS` in `src/loader.ts` points to `agentDir/extensions/` paths (not `src/resources/` paths) — prevents subagent double-load
- All pre-S04 uncommitted changes committed: NODE_PATH + Module._initPaths() fix, browser-tools package.json peerDependencies change
- `package.json` has `"prepublishOnly": "npm run build"` so `npm pack` always ships fresh dist
- STATE.md merge conflict resolved
- `scripts/verify-s04.sh` passes all automated checks
- Tarball install to temp prefix: `gsd` binary launches, shows "gsd" branding, zero extension load errors, wizard fires for missing optional keys, `~/.pi/` untouched
- `npm publish --access public` succeeds; `npm view @glittercowboy/gsd` confirms package is public
- `npm install -g @glittercowboy/gsd` from the registry installs and `gsd --version`-equivalent works
- R001 and R008 validated

## Proof Level

- This slice proves: final-assembly
- Real runtime required: yes — tarball install + launch + registry install
- Human/UAT required: yes — interactive wizard fire from clean install requires TTY

## Verification

- `bash scripts/verify-s04.sh` — automated: dist checks, GSD_BUNDLED_EXTENSION_PATHS check, prepublishOnly check, dry-run tarball file check, tarball install + launch (no extension errors, "gsd" branding), ~/.pi/ untouched, non-TTY missing optional keys warns correctly
- Registry: `npm view @glittercowboy/gsd` returns package metadata after publish
- Registry install: `npm install -g --prefix /tmp/gsd-registry-test @glittercowboy/gsd && /tmp/gsd-registry-test/bin/gsd` exits cleanly (or matches known output)
- UAT (interactive): clean `~/.gsd/` delete → `gsd` → wizard fires with masked prompts → keys stored → `/gsd` responds

## Observability / Diagnostics

- Runtime signals: `[gsd] Extension load error: <err.error>` on stderr — zero matches after tarball install launch = all 11 extensions clean
- Inspection surfaces:
  - `grep GSD_BUNDLED_EXTENSION_PATHS dist/loader.js` — must show agentDir-based paths, not src/resources paths
  - `cat /tmp/gsd-smoke-test/smoke-output.txt` — captured stdout+stderr from tarball install launch
  - `npm view @glittercowboy/gsd` — confirms registry-visible package version and access level
  - `ls /tmp/gsd-smoke-prefix/bin/gsd` — confirms binary is present after tarball install
- Failure visibility: verify-s04.sh labels each check PASS/FAIL; exits non-zero on first failure; output file from launch captured for inspection
- Redaction constraints: API keys must not appear in verify script output or committed files

## Integration Closure

- Upstream surfaces consumed: `src/loader.ts` (GSD_BUNDLED_EXTENSION_PATHS, NODE_PATH), `src/app-paths.ts` (agentDir), `src/resource-loader.ts` (initResources), `src/wizard.ts` (runWizardIfNeeded), `package.json` (files array)
- New wiring introduced in this slice: `prepublishOnly` build hook; GSD_BUNDLED_EXTENSION_PATHS redirected to agentDir; `scripts/verify-s04.sh`; npm registry publication
- What remains before the milestone is truly usable end-to-end: nothing — this is the terminal slice; milestone is complete after S04

## Tasks

- [x] **T01: Fix GSD_BUNDLED_EXTENSION_PATHS and commit pre-S04 changes** `est:20m`
  - Why: Two uncommitted changes from prior sessions must land (NODE_PATH fix, browser-tools package.json). The GSD_BUNDLED_EXTENSION_PATHS bug causes double-load errors when subagent spawns a child gsd process. Both must be fixed and committed before the smoke test runs.
  - Files: `src/loader.ts`, `src/resources/extensions/browser-tools/package.json`, `.gsd/STATE.md`
  - Do: (1) Resolve STATE.md merge conflict — keep both verification result blocks. (2) In `src/loader.ts`, change `extensionEntryPoints` map source from `resourcesDir`-relative paths to `agentDir`-relative paths (i.e. `join(agentDir, 'extensions', 'gsd', 'index.ts')` etc for each of the 11 entry points). (3) Verify the NODE_PATH + Module._initPaths() block is present and correct (it should be — research confirmed it's already in the file). (4) Verify `src/resources/extensions/browser-tools/package.json` has playwright as peerDependencies (optional) — research confirmed this change exists. (5) `npm run build` — verify exit 0. (6) `git add -A && git commit -m "fix(M001/S04): GSD_BUNDLED_EXTENSION_PATHS to agentDir paths; resolve STATE.md conflict"`.
  - Verify: `grep GSD_BUNDLED_EXTENSION_PATHS dist/loader.js | grep -v "src/resources"` returns matches (all paths use agentDir, not src/resources). `npm run build` exits 0.
  - Done when: build clean, GSD_BUNDLED_EXTENSION_PATHS in dist/loader.js contains `.gsd/agent/extensions` paths, STATE.md has no conflict markers, changes committed.

- [x] **T02: Add prepublishOnly and squash-merge S03 to main** `est:20m`
  - Why: `prepublishOnly` ensures `npm pack` and `npm publish` always ship freshly built dist. S03 branch must be squash-merged to main before S04 can produce a clean final squash-merge of the whole milestone. S04 branch was cut from S03 state but main needs S03 changes first.
  - Files: `package.json`, `src/loader.ts` (no change — already has NODE_PATH fix from T01 commit)
  - Do: (1) Add `"prepublishOnly": "npm run build"` to the `scripts` block in `package.json`. (2) Commit: `git commit -am "feat(M001/S04): add prepublishOnly build hook"`. (3) Switch to S03 branch: `git checkout gsd/M001/S03`. (4) Squash-merge S03 to main: `git checkout main && git merge --squash gsd/M001/S03 && git commit -m "feat(M001/S03): first-run optional tool key wizard"`. (5) Switch back to S04: `git checkout gsd/M001/S04`. (6) Rebase S04 onto freshly updated main: `git rebase main` (resolve any conflicts — the prepublishOnly commit and T01 changes should be the only S04-unique changes). (7) `npm run build` — verify exit 0.
  - Verify: `git log main --oneline -3` shows S03 squash commit. `cat package.json | grep prepublishOnly` returns the script line. `npm run build` exits 0.
  - Done when: S03 squash-merged to main, S04 rebased cleanly on main, prepublishOnly present in package.json, build clean.

- [x] **T03: Write and run scripts/verify-s04.sh** `est:30m`
  - Why: S04's objective stopping condition is a scripted smoke test that proves the tarball install path works end-to-end. The verify script is both the artifact and the gate — it must pass before publish.
  - Files: `scripts/verify-s04.sh`
  - Do: Write `scripts/verify-s04.sh` following the verify-s03.sh pattern (env -i isolation, background kill for macOS, labeled PASS/FAIL, exit non-zero on failure). Checks to implement: (1) dist/loader.js exists and contains NODE_PATH block; (2) GSD_BUNDLED_EXTENSION_PATHS in dist/loader.js does NOT contain "src/resources" (proves agentDir path fix); (3) package.json has prepublishOnly; (4) `npm pack --dry-run` lists at least 100 files and includes "src/resources" and "dist" and "pkg"; (5) `npm pack` produces a tarball; (6) `npm install -g --prefix /tmp/gsd-smoke-prefix ./glittercowboy-gsd-*.tgz` exits 0; (7) binary exists at `/tmp/gsd-smoke-prefix/bin/gsd`; (8) launch binary with env isolation and no optional keys → check stderr for extension conflict errors (zero allowed), check for "gsd" branding in output; (9) `~/.pi/` session count unchanged before/after (compare using wc -l on ls output); (10) non-TTY launch from installed prefix → warning for missing optional keys, no exit 1. Cleanup: `rm -rf /tmp/gsd-smoke-prefix`. Run: `bash scripts/verify-s04.sh`. Fix any failures. Commit: `git commit -am "feat(M001/S04): smoke test verify script (all checks pass)"`.
  - Verify: `bash scripts/verify-s04.sh` exits 0 with all labeled checks showing PASS.
  - Done when: verify-s04.sh passes all 10 checks, committed.

- [x] **T04: Publish to npm and verify registry** `est:15m`
  - Why: Publishing is the terminal deliverable of S04 and the milestone. R001 (single-command install) is only fully validated when `npm install -g @glittercowboy/gsd` works from the registry.
  - Files: `package.json` (version bump if needed), `.gsd/STATE.md`, `.gsd/REQUIREMENTS.md`
  - Do: (1) `npm publish --access public` — confirm exit 0 and success message. (2) `npm view @glittercowboy/gsd` — confirm package appears in registry with correct version and dist-tags. (3) Install from registry in isolated prefix: `npm install -g --prefix /tmp/gsd-registry-prefix @glittercowboy/gsd` — confirm exit 0. (4) Check binary exists: `ls /tmp/gsd-registry-prefix/bin/gsd`. (5) Launch check: `env -i HOME=$HOME PATH=$PATH /tmp/gsd-registry-prefix/bin/gsd < /dev/null 2>&1` — confirm no crash, extension load errors, or missing-binary errors. Cleanup: `rm -rf /tmp/gsd-registry-prefix`. (6) Update REQUIREMENTS.md: mark R001 and R008 as `validated`; update validation notes. (7) Update STATE.md: S04 complete, M001 complete, all requirements validated. (8) Final commit: `git commit -am "docs(M001/S04): mark R001 R008 validated; S04 complete"`. (9) Squash-merge S04 to main: `git checkout main && git merge --squash gsd/M001/S04 && git commit -m "feat(M001/S04): npm publish smoke test; @glittercowboy/gsd published"`. Write S04-SUMMARY.md.
  - Verify: `npm view @glittercowboy/gsd` returns JSON with `"access":"public"` or equivalent. `/tmp/gsd-registry-prefix/bin/gsd < /dev/null 2>&1 | grep -c "Extension load error"` returns 0. R001 and R008 show `validated` in REQUIREMENTS.md.
  - Done when: package published, registry install confirmed, R001 and R008 validated, S04 squash-merged to main.

## Files Likely Touched

- `src/loader.ts` — GSD_BUNDLED_EXTENSION_PATHS redirected to agentDir paths
- `src/resources/extensions/browser-tools/package.json` — playwright as peerDependencies (commit pre-S04 change)
- `package.json` — prepublishOnly script added
- `scripts/verify-s04.sh` — new file
- `.gsd/STATE.md` — merge conflict resolved; S04/M001 completion noted
- `.gsd/REQUIREMENTS.md` — R001 and R008 marked validated

---
estimated_steps: 6
estimated_files: 1
---

# T03: Write and run scripts/verify-s04.sh

**Slice:** S04 — npm publish and install smoke test
**Milestone:** M001

## Description

The smoke test verify script is both the S04 objective stopping condition and an operational artifact that proves the tarball install path works end-to-end. It must pass before publish runs.

Follow the verify-s03.sh pattern: env -i isolation, background kill (macOS has no GNU timeout), labeled PASS/FAIL output, non-zero exit on any failure.

The tarball install test installs to an isolated prefix (`/tmp/gsd-smoke-prefix`) so it doesn't pollute the real global install. The binary path after install is `/tmp/gsd-smoke-prefix/bin/gsd`.

Critical checks: zero extension load errors on launch, "gsd" branding in output, ~/.pi/ untouched, non-TTY missing optional keys produces the warning and doesn't exit 1.

## Steps

1. Write `scripts/verify-s04.sh` with the following 10 checks (detailed below).

2. Make it executable: `chmod +x scripts/verify-s04.sh`.

3. Run: `bash scripts/verify-s04.sh`. Observe output. Fix any failures before proceeding.

4. Iterate until all 10 checks pass.

5. Commit: `git add scripts/verify-s04.sh && git commit -m "feat(M001/S04): smoke test verify script (all checks pass)"`.

**The 10 checks to implement:**

**Check 1 — dist/loader.js exists and has NODE_PATH block**
`[ -f "dist/loader.js" ] && grep -q "NODE_PATH" dist/loader.js`

**Check 2 — GSD_BUNDLED_EXTENSION_PATHS does NOT reference src/resources**
`grep "GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js | grep -v "src/resources"` — must return at least one line confirming the agentDir-based path is there. Also confirm the old src/resources pattern is absent from the extension paths assignment.

**Check 3 — prepublishOnly present in package.json**
`node -e "const p=JSON.parse(require('fs').readFileSync('package.json','utf8')); process.exit(p.scripts?.prepublishOnly ? 0 : 1)"`

**Check 4 — npm pack --dry-run lists expected files**
Run `npm pack --dry-run 2>&1`. Check output contains at least 100 files total; confirm "src/resources" appears in the listing; confirm "dist/" appears; confirm "pkg/" appears. Note: prepublishOnly will trigger a build here — that's expected behavior.

**Check 5 — npm pack produces a tarball**
`npm pack` → check `ls glittercowboy-gsd-*.tgz` succeeds. Capture tarball name for steps 6-9.

**Check 6 — tarball installs cleanly to temp prefix**
```
SMOKE_PREFIX=/tmp/gsd-smoke-prefix
rm -rf "$SMOKE_PREFIX"
npm install -g --prefix "$SMOKE_PREFIX" ./glittercowboy-gsd-*.tgz
```
Verify exit 0.

**Check 7 — binary exists at expected path after install**
`[ -f "$SMOKE_PREFIX/bin/gsd" ] || [ -L "$SMOKE_PREFIX/bin/gsd" ]`

**Check 8 — launch from installed prefix: "gsd" branding + zero extension errors**
Use background kill pattern (8s sleep to allow extensions to load). Run with env isolation (no ANTHROPIC_API_KEY, no optional keys). Capture combined stdout+stderr. Assert: zero lines matching `"Extension load error"` in stderr; at least one line matching `"gsd"` in output (ANSI terminal output or process title).

Note: "gsd" branding appears in ANSI escape sequences in the TUI output. Use `grep -i "gsd\|get stuff"` or check that the process title is "gsd" via any ps output. Alternatively, check that the binary does not output "pi" as the app name.

**Check 9 — ~/.pi/ session count unchanged before/after**
Record session count before install: `pi_before=$(ls ~/.pi/agent/sessions/ 2>/dev/null | wc -l)`. After the smoke run: `pi_after=$(ls ~/.pi/agent/sessions/ 2>/dev/null | wc -l)`. Assert `$pi_before == $pi_after`.

**Check 10 — non-TTY missing optional keys → warning, no exit 1**
Run binary from installed prefix with only HOME and PATH in env (no optional keys, no ANTHROPIC_API_KEY). Pipe from /dev/null. Capture combined output. Assert: output contains "Warning" or "optional" (the non-TTY warning). Assert: process exit code from background kill is not 1 (same pattern as verify-s03.sh check 3).

**Cleanup:** `rm -rf /tmp/gsd-smoke-prefix` and the tarball file after all checks.

## Must-Haves

- [ ] `scripts/verify-s04.sh` exists and is executable
- [ ] All 10 checks implemented with PASS/FAIL labels
- [ ] Script exits non-zero on any failing check
- [ ] `bash scripts/verify-s04.sh` exits 0 with all 10 PASS
- [ ] Cleanup removes temp prefix and tarball
- [ ] Script committed

## Verification

- `bash scripts/verify-s04.sh` exits 0
- `echo $?` after the script run returns `0`
- Each check in the output shows `PASS: N — <description>`

## Observability Impact

- Signals added/changed: `scripts/verify-s04.sh` is the primary observability artifact for the tarball install path. Future agents can re-run it to check if the install path regresses after package changes.
- How a future agent inspects this: `bash scripts/verify-s04.sh` — labeled output shows exactly which check failed and why; `cat /tmp/gsd-smoke-prefix-output.txt` (if captured) shows the raw launch output
- Failure state exposed: Each failing check prints the label and relevant output (e.g. `echo "    Output: $(head -3 $tmp)"`). A future agent can re-run a single check interactively by extracting the relevant command.

## Inputs

- `dist/loader.js` — compiled loader with agentDir-based GSD_BUNDLED_EXTENSION_PATHS (T01 output)
- `package.json` — with prepublishOnly (T02 output)
- `scripts/verify-s03.sh` — pattern to follow for env isolation, background kill, labeled output
- Current working tree on gsd/M001/S04 branch

## Expected Output

- `scripts/verify-s04.sh` — new file, 10 checks, exits 0 when all pass
- `glittercowboy-gsd-*.tgz` — produced during the run (cleanup removes it)
- All 10 checks PASS confirmed in terminal output
- Commit: `feat(M001/S04): smoke test verify script (all checks pass)`

---
id: T01
parent: S04
milestone: M001
provides:
  - GSD_BUNDLED_EXTENSION_PATHS now uses agentDir-based paths for all 11 extensions
  - NODE_PATH + Module._initPaths() block confirmed present in src/loader.ts
  - browser-tools playwright confirmed as peerDependencies
  - STATE.md confirmed free of merge conflict markers
key_files:
  - src/loader.ts
key_decisions:
  - D021 implemented: GSD_BUNDLED_EXTENSION_PATHS → agentDir paths (not src/resources) prevents subagent double-load
patterns_established:
  - GSD_BUNDLED_EXTENSION_PATHS constructed inline using agentDir + join() for each of 11 entry points
  - no intermediate extensionEntryPoints variable needed since paths are homogenous (all under agentDir/extensions/)
observability_surfaces:
  - "grep GSD_BUNDLED_EXTENSION_PATHS dist/loader.js → shows agentDir-based paths"
  - "grep join(agentDir dist/loader.js | wc -l → must be 11"
duration: ~10 minutes
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T01: Fix GSD_BUNDLED_EXTENSION_PATHS and commit pre-S04 changes

**Redirected GSD_BUNDLED_EXTENSION_PATHS from src/resources/extensions/ to agentDir-based paths, eliminating the subagent double-load extension conflict bug.**

## What Happened

The working tree was already clean — prior sessions had committed the NODE_PATH fix and browser-tools peerDependencies change. STATE.md had no conflict markers either.

The only real work: edited `src/loader.ts` to replace the `extensionEntryPoints` array + `.map(rel => join(resourcesDir, rel))` pattern with an inline array constructing all 11 paths via `join(agentDir, 'extensions', ...)`. Added an explanatory comment block documenting why agentDir is correct (initResources() syncs to agentDir before extension loading, so paths are always valid; using agentDir matches what buildResourceLoader discovers, enabling pi's deduplication to work correctly).

Ran `npm run build` → exit 0. Committed with the canonical message from the task plan.

## Verification

- `grep "join(agentDir" dist/loader.js | wc -l` → 11 (all 11 extension entry points use agentDir)
- `grep "src/resources" dist/loader.js | grep -v "//" | grep -i extension` → 0 matches (no non-comment extension path references to src/resources)
- `grep "_initPaths" dist/loader.js` → 1 match (`Module._initPaths?.()`)
- `cat src/resources/extensions/browser-tools/package.json` → playwright in peerDependencies, not dependencies
- `grep -c "<<<" .gsd/STATE.md` → 0
- `npm run build` → exit 0
- `git log --oneline -1` → `11e0fe1 fix(M001/S04): redirect GSD_BUNDLED_EXTENSION_PATHS to agentDir paths; resolve STATE.md conflict`

## Diagnostics

- `grep GSD_BUNDLED_EXTENSION_PATHS dist/loader.js` — shows the env var assignment; confirms agentDir-based construction
- `grep "join(agentDir" dist/loader.js` — lists all 11 extension path join calls; count must be 11
- If subagent extension conflict errors reappear in future: check if GSD_BUNDLED_EXTENSION_PATHS paths match what `buildResourceLoader` discovers from agentDir; mismatch = deduplication fails = double-load

## Deviations

- STATE.md and browser-tools peerDependencies were already committed — no action needed for those steps. The plan assumed they'd be uncommitted; they were not. This shortened execution.
- No `extensionEntryPoints` intermediate variable in the new implementation — paths are constructed directly inline. Functionally equivalent, slightly more readable.

## Known Issues

none

## Files Created/Modified

- `src/loader.ts` — GSD_BUNDLED_EXTENSION_PATHS now uses agentDir-based paths for all 11 extensions; comment block explains the rationale
- `dist/loader.js` — compiled output reflecting the src/loader.ts change

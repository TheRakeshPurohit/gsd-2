---
id: T02
parent: S04
milestone: M001
provides:
  - prepublishOnly hook in package.json; npm pack/publish always rebuilds dist first
  - S04 branch confirmed rebased on main (merge base = main HEAD; rebase was no-op)
  - main branch confirmed has S01 + S02 + S03 squash commits; S04 not yet merged
key_files:
  - package.json
key_decisions:
  - S03 squash-merge to main was already completed before T02 began; no action needed
patterns_established:
  - prepublishOnly = "npm run build" ensures stale dist can never be published; enforced by npm lifecycle
observability_surfaces:
  - "cat package.json | grep prepublishOnly — confirms hook present"
  - "git log main --oneline -3 — confirms S03 is top feat commit on main"
  - "npm run build — exits 0 means dist is always fresh before any publish"
duration: ~5m
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T02: Add prepublishOnly and squash-merge S03 to main

**Added `prepublishOnly: npm run build` to package.json; confirmed S03 already squash-merged on main; S04 rebased clean.**

## What Happened

Added `"prepublishOnly": "npm run build"` to the scripts block in package.json, placed after the `postinstall` line.

Checked main branch history before attempting the S03 squash-merge — main already had `881cabe feat(M001/S03): first-run optional tool key wizard` as a squash commit from a prior session. The squash-merge step was already done; skipped to avoid duplicate commits.

Ran `git rebase main` on the S04 branch. The merge base between S04 and main was `1507dfa` (the chore commit after S03 reassess), which is identical to main's current HEAD. Rebase was a no-op: "Current branch gsd/M001/S04 is up to date."

Ran `npm run build` — tsc compiled cleanly, copy-themes completed, exit 0.

## Verification

- `cat package.json | grep prepublishOnly` → `"prepublishOnly": "npm run build"` ✓
- `git log main --oneline -3` → top commit is `881cabe feat(M001/S03): first-run optional tool key wizard` ✓
- `git branch --show-current` → `gsd/M001/S04` ✓
- `npm run build` → exit 0 ✓

## Diagnostics

- `cat package.json | grep prepublishOnly` — confirms hook is present in scripts block
- `git log main --oneline -5` — shows S01/S02/S03 squash commits; S04 not yet merged
- If `npm pack` aborts in future: prepublishOnly causes build failure to surface as pack failure with non-zero exit — visible in terminal

## Deviations

S03 squash-merge was already done before this task ran. The task plan included steps to perform it; those were skipped since repeating them would create a duplicate squash commit on main. All outcomes were verified to match what the plan required.

## Known Issues

none

## Files Created/Modified

- `package.json` — added `"prepublishOnly": "npm run build"` to scripts block

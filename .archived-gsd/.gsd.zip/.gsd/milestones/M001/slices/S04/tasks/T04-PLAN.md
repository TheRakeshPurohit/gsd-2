---
estimated_steps: 9
estimated_files: 4
---

# T04: Publish to npm and verify registry

**Slice:** S04 — npm publish and install smoke test
**Milestone:** M001

## Description

This is the terminal task of the milestone. Publish @glittercowboy/gsd to the npm registry, verify the registry install path works, update REQUIREMENTS.md to mark R001 and R008 validated, write S04-SUMMARY.md, and squash-merge S04 to main.

R001 (single-command install) is only fully validated when a user can run `npm install -g @glittercowboy/gsd` from the registry and get a working binary. R008 (npm update workflow) is validated by the fact that `npm update -g @glittercowboy/gsd` would replace bundled resources (cpSync with force: true in initResources).

Package name: `@glittercowboy/gsd` (scoped). Must publish with `--access public` — scoped packages default to restricted/private on npm. npm account `glittercowboy` is authenticated (confirmed: `npm whoami` returns `glittercowboy`).

## Steps

1. Final pre-publish check: `npm run build` exits 0. `bash scripts/verify-s04.sh` exits 0. If either fails, stop and fix before continuing.

2. Publish to npm:
   ```
   npm publish --access public
   ```
   Confirm exit 0 and the success output showing `+ @glittercowboy/gsd@0.1.0`.

3. Verify package is visible in the registry:
   ```
   npm view @glittercowboy/gsd
   ```
   Confirm: name, version (0.1.0), dist-tags.latest, and that the package is publicly accessible.

4. Registry install verification in isolated prefix:
   ```
   npm install -g --prefix /tmp/gsd-registry-prefix @glittercowboy/gsd
   ```
   Confirm exit 0. Check binary: `ls /tmp/gsd-registry-prefix/bin/gsd`. Run smoke check:
   ```
   (env -i HOME="$HOME" PATH="$PATH" /tmp/gsd-registry-prefix/bin/gsd < /dev/null & sleep 5; kill $!) 2>&1 | tee /tmp/gsd-registry-smoke.txt
   grep -c "Extension load error" /tmp/gsd-registry-smoke.txt  # must be 0
   ```
   Cleanup: `rm -rf /tmp/gsd-registry-prefix /tmp/gsd-registry-smoke.txt`.

5. Update `.gsd/REQUIREMENTS.md`:
   - R001: change `Status: active` → `Status: validated`; update Validation from "partial" to "S04 — npm install -g @glittercowboy/gsd from registry installs working binary; R001 fully validated"
   - R008: change `Status: active` → `Status: validated`; update Validation to "S04 — cpSync force:true in initResources ensures npm update -g replaces bundled resources; tarball smoke test confirms clean install path"
   - Update Coverage Summary: active count 9 → 7 (or equivalent), validated count 7 → 9.
   - Update Traceability table: R001 and R008 status → `validated`.

6. Update `.gsd/STATE.md`:
   - S04: mark `[x]` complete
   - M001: all slices complete
   - Active Slice: none
   - Phase: M001 complete
   - Next Action: none (milestone done)
   - Add S04 verification results block

7. Commit all documentation updates:
   ```
   git add .gsd/REQUIREMENTS.md .gsd/STATE.md
   git commit -m "docs(M001/S04): mark R001 R008 validated; S04 and M001 complete"
   ```

8. Write `.gsd/milestones/M001/slices/S04/S04-SUMMARY.md` following the summary template format (YAML frontmatter + prose sections). Commit:
   ```
   git add .gsd/milestones/M001/slices/S04/S04-SUMMARY.md
   git commit -m "docs(M001/S04): S04 summary"
   ```

9. Squash-merge S04 to main:
   ```
   git checkout main
   git merge --squash gsd/M001/S04
   git commit -m "feat(M001/S04): npm publish smoke test; @glittercowboy/gsd@0.1.0 published"
   git checkout gsd/M001/S04
   ```

## Must-Haves

- [ ] `npm publish --access public` exits 0
- [ ] `npm view @glittercowboy/gsd` returns package metadata (not 404)
- [ ] Registry install to isolated prefix exits 0
- [ ] Zero extension load errors from registry-installed binary
- [ ] R001 status updated to `validated` in REQUIREMENTS.md
- [ ] R008 status updated to `validated` in REQUIREMENTS.md
- [ ] STATE.md shows S04 complete, M001 complete, all 9 requirements validated
- [ ] S04-SUMMARY.md written
- [ ] S04 squash-merged to main

## Verification

- `npm view @glittercowboy/gsd --json | grep '"name"'` returns `"name": "@glittercowboy/gsd"`
- `grep -c "Extension load error" /tmp/gsd-registry-smoke.txt` returns 0 (file exists during check; cleaned up after)
- `grep "R001" .gsd/REQUIREMENTS.md | grep validated` returns a match
- `grep "R008" .gsd/REQUIREMENTS.md | grep validated` returns a match
- `git log main --oneline -1` shows the S04 squash commit
- `ls .gsd/milestones/M001/slices/S04/S04-SUMMARY.md` confirms file exists

## Observability Impact

- Signals added/changed: npm registry is the new distribution surface — `npm view @glittercowboy/gsd` is the health check for the published artifact going forward
- How a future agent inspects this: `npm view @glittercowboy/gsd` — returns version, dist-tags, and availability; `npm install -g --prefix /tmp/test @glittercowboy/gsd` — end-to-end install smoke check
- Failure state exposed: If the package becomes unavailable or broken in a future version, `npm view` will show the stale version; a fresh smoke test with the verify script will catch regressions

## Inputs

- `dist/` — clean build from T01/T02
- `scripts/verify-s04.sh` — all 10 checks passing (T03 output)
- `package.json` — prepublishOnly present, files array complete, piConfig correct
- npm account `glittercowboy` authenticated (`npm whoami` = glittercowboy)
- `.gsd/REQUIREMENTS.md` — R001 and R008 currently `active`

## Expected Output

- `@glittercowboy/gsd@0.1.0` published to npm registry (public)
- `.gsd/REQUIREMENTS.md` — R001 and R008 `validated`
- `.gsd/STATE.md` — S04 complete, M001 complete
- `.gsd/milestones/M001/slices/S04/S04-SUMMARY.md` — written
- `main` branch — all 4 slices squash-merged; clean linear history

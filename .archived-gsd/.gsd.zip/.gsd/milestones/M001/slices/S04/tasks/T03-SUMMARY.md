---
id: T03
parent: S04
milestone: M001
provides:
  - scripts/verify-s04.sh — 10-check smoke test covering dist integrity, GSD_BUNDLED_EXTENSION_PATHS, prepublishOnly, npm pack dry-run, tarball install, binary path, launch (zero extension errors + gsd branding), ~/.pi/ isolation, non-TTY warning
key_files:
  - scripts/verify-s04.sh
key_decisions:
  - grep -c replaced with grep | wc -l to avoid multi-value output when no matches found (grep -c returns 0 with exit 1, the || echo "0" fallback appended a second line breaking integer comparisons)
  - set -e removed in favor of set -uo pipefail to allow explicit FAIL tracking without early exit on assertion failures
  - grep "join(" filter added to Check 2 to avoid false match on comment line "NOT src/resources"
patterns_established:
  - Check 2 pattern for GSD_BUNDLED_EXTENSION_PATHS: check join() lines only (not comments) with grep -A 15 … | grep "join(" | grep -q "src/resources"
  - Line counting pattern: use `grep "pattern" file | wc -l | tr -d ' '` not `grep -c` to get a clean integer in a variable
  - Background kill pattern for slow launch checks: (env -i … binary < /dev/null > out 2>&1) & pid=$!; sleep N; kill $pid; wait $pid
observability_surfaces:
  - bash scripts/verify-s04.sh — labeled PASS/FAIL output for all 10 checks; exits non-zero on first failure
  - /tmp/gsd-smoke-prefix/bin/gsd — binary path after tarball install (cleaned up by script trap)
  - cat /tmp/gsd-smoke-prefix-output.txt — not captured to disk in this version; smoke_out tmpfile used inline and removed
duration: ~25min (2 iterations to fix grep -c and Check 2 comment match)
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T03: Write and run scripts/verify-s04.sh

**Wrote and ran `scripts/verify-s04.sh` — all 10 checks PASS (exit 0), committed.**

## What Happened

Wrote `scripts/verify-s04.sh` following the verify-s03.sh pattern: env -i isolation, background kill (no GNU timeout on macOS), labeled PASS/FAIL output, non-zero exit on any failure. The script covers the full tarball install smoke test path.

First run exposed two bugs fixed in the second iteration:

1. **Check 2 false fail**: The `grep -A 15 "GSD_BUNDLED_EXTENSION_PATHS"` context window included the comment `// IMPORTANT: paths point to agentDir … NOT src/resources/extensions/.` — the word "src/resources" in the comment triggered the grep. Fixed by adding `| grep "join("` to check only actual code lines, not comments.

2. **Check 8a integer crash**: `grep -c "Extension load error" file` returns exit code 1 when there are no matches. The `|| echo "0"` fallback then ran, producing a two-line variable `"0\n0"`. The subsequent `[ "$ext_errors" -eq 0 ]` failed with "integer expression expected". Also, `set -e` caused the script to exit immediately at that point rather than recording a FAIL and continuing. Fixed by replacing `grep -c` with `grep … | wc -l | tr -d ' '` and dropping `set -e`.

Second run: all 10 checks PASS.

## Verification

```
bash scripts/verify-s04.sh
EXIT_CODE: 0
```

Full output:
```
=== S04 Verification ===
--- Dist integrity ---
  PASS: 1 — dist/loader.js exists and contains NODE_PATH block
  PASS: 2 — GSD_BUNDLED_EXTENSION_PATHS uses agentDir-based paths (no src/resources)
--- package.json hooks ---
  PASS: 3 — prepublishOnly hook present in package.json
--- npm pack dry-run ---
  PASS: 4 — dry-run: 135 files listed, dist/ present, pkg/ present, src/resources present
--- tarball pack ---
  PASS: 5 — tarball produced: glittercowboy-gsd-0.1.0.tgz
--- tarball install ---
  PASS: 6 — tarball installed to /tmp/gsd-smoke-prefix (exit 0)
  PASS: 7 — /tmp/gsd-smoke-prefix/bin/gsd exists after install
--- launch smoke ---
  PASS: 8a — zero Extension load errors on launch
  PASS: 8b — "gsd" / "get stuff done" branding found in launch output
--- ~/.pi/ isolation ---
  PASS: 9 — ~/.pi/agent/sessions/ count unchanged (28 sessions before and after)
--- non-TTY warning path ---
  PASS: 10a — non-TTY missing optional keys → warning emitted
  PASS: 10b — non-TTY missing optional keys → did NOT exit 1 (code: killed)
=== Results ===
All checks passed.
```

Slice-level verification checks per S04-PLAN.md:
- `bash scripts/verify-s04.sh` → EXIT 0 ✅
- Registry checks (npm view, registry install, UAT) → pending T04

## Diagnostics

- Re-run `bash scripts/verify-s04.sh` at any time to verify the tarball install path
- If Check 2 fails in future: `grep -A 15 "GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js | grep "join("` — should show 11 agentDir-based paths, none referencing src/resources
- If Check 8a fails: check `grep "Extension load error"` against the smoke output file (smoke_out tmpfile — not persisted; re-run script to capture fresh)
- If Check 6 fails: run `npm install -g --prefix /tmp/gsd-smoke-prefix ./glittercowboy-gsd-*.tgz` manually and inspect npm error output

## Deviations

- Task plan split Check 10 as a single check; implemented as 10a (warning emitted) and 10b (no exit 1) for clearer labeling. Functionally identical to the plan's intent.
- `set -e` removed (plan didn't specify it); without it the script continues past check failures to show all results, which is the correct behavior for a verification script.

## Known Issues

None.

## Files Created/Modified

- `scripts/verify-s04.sh` — new file; 10-check smoke test; exits 0 when all pass; committed as `feat(M001/S04): smoke test verify script (all checks pass)`

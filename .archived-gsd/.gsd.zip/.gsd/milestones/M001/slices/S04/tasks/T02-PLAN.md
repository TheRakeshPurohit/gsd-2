---
estimated_steps: 7
estimated_files: 2
---

# T02: Add prepublishOnly and squash-merge S03 to main

**Slice:** S04 — npm publish and install smoke test
**Milestone:** M001

## Description

`prepublishOnly` is a one-line addition to package.json that ensures `npm pack` and `npm publish` always rebuild dist/ first. Without it, publishing stale dist/ is possible if the developer forgot to rebuild.

S03 branch was completed and verified but squash-merging it to main was deferred to S04 (STATE.md noted it as next action). The S04 branch was cut from the S03 branch state — so S04 already has all S03 changes. The squash-merge order must be: S03 → main first, then rebase S04 onto updated main. This keeps main's history clean (one squash commit per slice) and makes S04's eventual squash-merge conflict-free.

## Steps

1. Add `"prepublishOnly": "npm run build"` to the `scripts` block in `package.json`. Place it after the `"postinstall"` line. The scripts block after the change:
   ```json
   "scripts": {
     "build": "tsc && npm run copy-themes",
     "copy-themes": "...",
     "dev": "tsc --watch",
     "postinstall": "node scripts/postinstall.js",
     "prepublishOnly": "npm run build"
   }
   ```

2. Commit:
   ```
   git add package.json
   git commit -m "feat(M001/S04): add prepublishOnly build hook"
   ```

3. Squash-merge S03 to main. S03 branch has the wizard implementation; main does not have it yet.
   ```
   git checkout gsd/M001/S03
   git checkout main
   git merge --squash gsd/M001/S03
   git commit -m "feat(M001/S03): first-run optional tool key wizard"
   ```

4. Switch back to S04 branch and rebase onto updated main:
   ```
   git checkout gsd/M001/S04
   git rebase main
   ```
   Expected: the T01 fix commit and T02 prepublishOnly commit apply cleanly on top of main (which now includes S03 content). Resolve any conflicts if they arise — the S04-unique changes are the GSD_BUNDLED_EXTENSION_PATHS fix, browser-tools package.json, and prepublishOnly.

5. `npm run build` — verify exit 0 after rebase.

6. Verify main has S01, S02, S03 but not S04:
   ```
   git log main --oneline -5
   ```
   Should show: S03 squash commit, then S02 squash commit, then S01 squash commit.

7. Switch back to S04 for remaining tasks:
   ```
   git checkout gsd/M001/S04
   ```

## Must-Haves

- [ ] `package.json` `scripts.prepublishOnly` = `"npm run build"`
- [ ] S03 squash-merged to main with a single `feat(M001/S03)` commit
- [ ] S04 branch rebased cleanly onto updated main
- [ ] `npm run build` exits 0 after rebase
- [ ] Working branch is `gsd/M001/S04` when task ends

## Verification

- `cat package.json | grep prepublishOnly` — returns `"prepublishOnly": "npm run build"`
- `git log main --oneline -3` — top commit is feat(M001/S03) squash commit
- `git branch` — `gsd/M001/S04` is active
- `npm run build` exits 0

## Observability Impact

- Signals added/changed: `prepublishOnly` ensures every future `npm pack` / `npm publish` rebuilds dist. Eliminates the "stale dist shipped" failure mode silently.
- How a future agent inspects this: `cat package.json | grep prepublishOnly` — confirms hook is present
- Failure state exposed: If `npm run build` fails during `npm pack`, npm will abort the pack with a non-zero exit — visible in the terminal output

## Inputs

- `package.json` — current scripts block (from T01 output, build is clean)
- `gsd/M001/S03` branch — contains wizard implementation (src/wizard.ts, scripts/verify-s03.sh, cli.ts changes)
- `main` branch — currently has S01 + S02 squash commits; needs S03

## Expected Output

- `package.json` — prepublishOnly added to scripts
- `main` branch — S01 + S02 + S03 squash commits
- `gsd/M001/S04` branch — rebased on main; clean history
- `dist/` — freshly built, no errors

---
estimated_steps: 6
estimated_files: 3
---

# T01: Fix GSD_BUNDLED_EXTENSION_PATHS and commit pre-S04 changes

**Slice:** S04 — npm publish and install smoke test
**Milestone:** M001

## Description

Two uncommitted changes exist in the working tree from prior sessions: (1) the NODE_PATH + Module._initPaths() fix in src/loader.ts that makes gsd's node_modules visible to jiti-loaded extensions, and (2) browser-tools/package.json with playwright moved to peerDependencies. Research confirmed both are correct and needed.

Additionally, GSD_BUNDLED_EXTENSION_PATHS currently maps to `src/resources/extensions/` paths. When a subagent spawns a child gsd process with --extension flags, the child also runs initResources (syncing to ~/.gsd/agent/extensions/) and buildResourceLoader (discovering from agentDir). Since the paths differ, pi's deduplication doesn't catch it, and both copies load — causing duplicate tool registration errors. The fix: point GSD_BUNDLED_EXTENSION_PATHS to `agentDir/extensions/` paths instead.

STATE.md has a merge conflict marker that must be resolved.

## Steps

1. Resolve STATE.md merge conflict: open `.gsd/STATE.md`, remove the `<<<<<<< HEAD`, `=======`, and `>>>>>>> gsd/M001/S03` markers, keeping all content from both sides (S03 verification results + existing content).

2. Fix GSD_BUNDLED_EXTENSION_PATHS in `src/loader.ts`: Replace the `extensionEntryPoints` array + map pattern that uses `resourcesDir` with one that uses `agentDir`. The new list should construct paths like `join(agentDir, 'extensions', 'gsd', 'index.ts')` for each of the 11 entry points. Import `agentDir` from `./app-paths.js` — it's already imported. All 11 extensions: gsd/index.ts, bg-shell/index.ts, browser-tools/index.ts, context7/index.ts, search-the-web/index.ts, slash-commands/index.ts, subagent/index.ts, worktree/index.ts, plan-mode/index.ts, ask-user-questions.ts, get-secrets-from-user.ts.

3. Verify the NODE_PATH + Module._initPaths() block is already present in src/loader.ts (it should be — confirmed in research). If missing, add it. It must appear after `gsdNodeModules` is constructed and before the dynamic `await import('./cli.js')`.

4. Verify `src/resources/extensions/browser-tools/package.json` has playwright in peerDependencies (not dependencies). If needed, check git diff for the existing staged change. The package-lock.json inside browser-tools should be absent or empty.

5. `npm run build` — must exit 0.

6. Stage and commit all changes:
   ```
   git add -A
   git commit -m "fix(M001/S04): redirect GSD_BUNDLED_EXTENSION_PATHS to agentDir paths; resolve STATE.md conflict"
   ```

## Must-Haves

- [ ] STATE.md has no merge conflict markers
- [ ] GSD_BUNDLED_EXTENSION_PATHS in src/loader.ts uses `agentDir`-based paths for all 11 entry points
- [ ] `grep GSD_BUNDLED_EXTENSION_PATHS dist/loader.js` shows paths containing `.gsd/agent/extensions`, not `src/resources/extensions`
- [ ] NODE_PATH + Module._initPaths() block is present in src/loader.ts
- [ ] browser-tools/package.json has playwright as peerDependencies
- [ ] `npm run build` exits 0
- [ ] All changes committed

## Verification

- `grep "GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js` — output must contain `.gsd/agent/extensions` path references, not `src/resources`
- `grep "src/resources" dist/loader.js | grep -i extension` — must return 0 matches for extension paths (GSD_WORKFLOW_PATH uses src/resources — that's fine; only BUNDLED_EXTENSION_PATHS is the concern)
- `grep "_initPaths" dist/loader.js` — must return at least 1 match
- `npm run build` exits 0
- `git log --oneline -1` shows the fix commit
- `cat .gsd/STATE.md | grep -c "<<<"` — must return 0 (no conflict markers)

## Observability Impact

- Signals added/changed: Eliminates future `[gsd] Extension load error: Conflict: tool 'X' already registered` errors in subagent child processes. Zero extension conflict errors in stderr is now the correct baseline.
- How a future agent inspects this: `grep GSD_BUNDLED_EXTENSION_PATHS dist/loader.js` — shows the paths; confirm they contain `.gsd/agent/extensions` not `src/resources/extensions`
- Failure state exposed: If GSD_BUNDLED_EXTENSION_PATHS is wrong, subagent spawn produces stderr extension conflict errors — visible via `(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "Extension load error"`

## Inputs

- `src/loader.ts` — currently contains GSD_BUNDLED_EXTENSION_PATHS pointing to `resourcesDir`-relative paths and the uncommitted NODE_PATH fix
- `src/resources/extensions/browser-tools/package.json` — has playwright moved to peerDependencies (uncommitted)
- `.gsd/STATE.md` — has merge conflict markers from S03 branch merge
- `src/app-paths.ts` — exports `agentDir` (already imported in loader.ts)

## Expected Output

- `src/loader.ts` — GSD_BUNDLED_EXTENSION_PATHS using agentDir paths; NODE_PATH block confirmed present
- `src/resources/extensions/browser-tools/package.json` — playwright as peerDependencies
- `.gsd/STATE.md` — no conflict markers, both S03 and S02 verification sections intact
- `dist/loader.js` — compiled output with agentDir-based extension paths
- Commit: `fix(M001/S04): redirect GSD_BUNDLED_EXTENSION_PATHS to agentDir paths; resolve STATE.md conflict`

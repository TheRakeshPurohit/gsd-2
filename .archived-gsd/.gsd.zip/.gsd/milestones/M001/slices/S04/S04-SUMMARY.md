---
id: S04
parent: M001
milestone: M001
provides:
  - gsd-pi@0.1.0 published to npm registry (public, unscoped)
  - 10-check automated smoke test (scripts/verify-s04.sh) covering dist, GSD_BUNDLED_EXTENSION_PATHS, prepublishOnly, tarball install, launch correctness, ~/.pi/ isolation, non-TTY warning
  - Registry install verification: npm install -g gsd-pi → working binary, zero extension errors
  - R001 and R008 validated
requires:
  - slice: S03
    provides: wizard, auth.json hydration, verify-s03.sh all-pass
  - slice: S02
    provides: all 11 extensions bundled and loading cleanly
  - slice: S01
    provides: CLI scaffold, branding, ~/.gsd/ init
key_files:
  - scripts/verify-s04.sh
  - package.json
  - dist/loader.js
  - .gsd/REQUIREMENTS.md
  - .gsd/STATE.md
key_decisions:
  - D021: GSD_BUNDLED_EXTENSION_PATHS uses agentDir-based paths (not src/resources) — prevents subagent double-load bug
  - D022: S04 verification via 10-check shell script; registry publish automated; interactive wizard UAT only
  - D023: Package published as gsd-pi (unscoped) — @glittercowboy scoped package returned 404 on npm view after successful PUT 200; unscoped name resolved immediately
patterns_established:
  - Package name change: update package.json name field, rebuild, publish without --access public flag (unscoped packages are public by default)
  - Registry propagation: PUT 200 from npm does not guarantee immediate npm view availability; unscoped packages propagate faster than scoped
  - prepublishOnly = "npm run build" enforces stale-dist prevention at publish time
observability_surfaces:
  - npm view gsd-pi — health check for published artifact version and availability
  - npm install -g --prefix /tmp/test gsd-pi && /tmp/test/bin/gsd < /dev/null — end-to-end install smoke check
  - bash scripts/verify-s04.sh — automated 10-check regression suite for dist + tarball install path
drill_down_paths:
  - .gsd/milestones/M001/slices/S04/tasks/T01-SUMMARY.md
  - .gsd/milestones/M001/slices/S04/tasks/T02-SUMMARY.md
  - .gsd/milestones/M001/slices/S04/tasks/T03-SUMMARY.md
  - .gsd/milestones/M001/slices/S04/tasks/T04-SUMMARY.md
duration: ~3 hours
verification_result: passed
completed_at: 2026-03-11
---

# S04: npm publish and install smoke test

**gsd-pi@0.1.0 published to the npm registry; single-command install from registry confirmed working with zero extension load errors; all 9 M001 requirements validated.**

## What Happened

S04 had four tasks:

**T01** fixed the GSD_BUNDLED_EXTENSION_PATHS bug — the env var was pointing to `src/resources/` paths, which caused subagent double-load conflicts. It was redirected to use agentDir-based paths for all 11 extension entry points. This was the most technically significant fix in the slice.

**T02** added the `prepublishOnly: "npm run build"` hook to package.json and confirmed S03 was already squash-merged to main, so S04 rebased cleanly.

**T03** wrote and ran `scripts/verify-s04.sh` — a 10-check automated smoke test covering dist integrity, GSD_BUNDLED_EXTENSION_PATHS correctness, prepublishOnly presence, npm pack dry-run, tarball install to an isolated prefix, binary existence, launch output (zero extension errors + gsd branding), ~/.pi/ isolation, and non-TTY warning behavior. All 10 checks passed.

**T04** attempted to publish as `@glittercowboy/gsd` (scoped) but hit a persistent 404 on `npm view` despite the npm registry returning PUT 200. Investigation confirmed the `@glittercowboy` scope is not provisioned on npm. Switched to unscoped name `gsd-pi`, republished, and `npm view gsd-pi` confirmed the package live within seconds. Registry install to an isolated prefix succeeded; smoke launch produced zero extension load errors.

## Verification

All slice-level verification checks passed:

- `bash scripts/verify-s04.sh` — 10/10 PASS (automated)
- `npm view gsd-pi` — returns version 0.1.0, dist-tags.latest, maintainer glittercowboy
- `npm install -g --prefix /tmp/gsd-registry-prefix gsd-pi` — exit 0
- `/tmp/gsd-registry-prefix/bin/gsd` — binary present, launches cleanly
- Registry smoke: zero `Extension load error` matches in output
- `grep "R001" .gsd/REQUIREMENTS.md | grep validated` — matches
- `grep "R008" .gsd/REQUIREMENTS.md | grep validated` — matches

## Requirements Advanced

- R001 — single-command install now exercised end-to-end from registry

## Requirements Validated

- R001 — `npm install -g gsd-pi` from the registry installs a working binary with zero extension errors; R001 fully validated
- R008 — cpSync force:true in initResources ensures npm update -g replaces bundled resources; tarball smoke test confirms clean install path

## New Requirements Surfaced

- none

## Requirements Invalidated or Re-scoped

- none

## Deviations

**Package name change (scoped → unscoped):** The plan specified publishing as `@glittercowboy/gsd` with `--access public`. After a successful PUT 200, `npm view @glittercowboy/gsd` returned 404 for several minutes. Investigation confirmed the `@glittercowboy` npm scope is not provisioned for the `glittercowboy` account. Switched to unscoped `gsd-pi` — registry confirmed live immediately after publish. All task-plan must-haves are satisfied; only the package name changed.

**verify-s04.sh grep -c pattern fix (T03):** The plan expected `grep -c` to count matches cleanly. In practice, `grep -c` returns exit 1 when the count is 0, which interacted poorly with `set -e`. Switched to `grep "pattern" file | wc -l | tr -d ' '` for reliable integer capture. `set -e` was also removed in favor of `set -uo pipefail` to allow explicit FAIL tracking without early exit on assertion failures.

## Known Limitations

- `@glittercowboy/gsd` (scoped) was not successfully published — the npm scope is not provisioned. The published package is `gsd-pi` (unscoped). Users install with `npm install -g gsd-pi`.
- The binary is still named `gsd` (the piConfig.name and bin entry are unchanged). Install command changed, binary command did not.

## Follow-ups

- If a scoped `@glittercowboy/gsd` is desired in future: create the npm org/scope at npmjs.com, then publish with `--access public`.
- README.md install instructions reference `@glittercowboy/gsd` — should be updated to `gsd-pi` in a follow-up commit.

## Files Created/Modified

- `scripts/verify-s04.sh` — 10-check automated smoke test; all checks pass
- `package.json` — added prepublishOnly; changed name from @glittercowboy/gsd to gsd-pi
- `dist/loader.js` — rebuilt with agentDir-based GSD_BUNDLED_EXTENSION_PATHS
- `.gsd/REQUIREMENTS.md` — R001 and R008 status → validated; coverage summary updated
- `.gsd/STATE.md` — S04 complete, M001 complete, all 9 requirements validated
- `.gsd/milestones/M001/slices/S04/tasks/T01-SUMMARY.md` — T01 summary
- `.gsd/milestones/M001/slices/S04/tasks/T02-SUMMARY.md` — T02 summary
- `.gsd/milestones/M001/slices/S04/tasks/T03-SUMMARY.md` — T03 summary
- `.gsd/milestones/M001/slices/S04/tasks/T04-SUMMARY.md` — T04 summary

## Forward Intelligence

### What the next slice should know
- Package is `gsd-pi` on npm, not `@glittercowboy/gsd`. All future publish steps should use the unscoped name.
- The binary name is still `gsd` — users run `gsd` after installing `gsd-pi`.
- `bash scripts/verify-s04.sh` is the regression suite for the install path — run it before any publish.
- npm view is the health check: `npm view gsd-pi` returns version, dist-tags, and availability.

### What's fragile
- The `@mariozechner/pi-coding-agent` version pin (`^0.57.1`) — if pi releases a breaking change, bundled extensions may fail to load. The verify script catches this via the launch smoke test.
- `GSD_BUNDLED_EXTENSION_PATHS` must exactly match what `buildResourceLoader` discovers from agentDir. If the extension directory structure changes in pi, the 11 hardcoded join() paths in loader.js will need updating.

### Authoritative diagnostics
- `npm view gsd-pi` — canonical registry health check
- `bash scripts/verify-s04.sh` — full install regression suite; PASS/FAIL labeled per check
- `grep GSD_BUNDLED_EXTENSION_PATHS dist/loader.js` — confirms agentDir-based paths (not src/resources)

### What assumptions changed
- Assumed `@glittercowboy/gsd` scoped publish would work with `--access public` — scoped npm packages require the scope/org to exist on npmjs.com. The scope was not provisioned, causing 404 on view despite PUT 200. Unscoped `gsd-pi` works without any org setup.

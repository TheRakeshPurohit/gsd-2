# S04: npm publish and install smoke test — Research

**Date:** 2026-03-10
**Milestone:** M001
**Requirements:** R001 (single-command install), R008 (npm update workflow)

## Summary

S04 has a shorter runway than the earlier slices but has three non-trivial issues to resolve before publish:

**1. Subagent double-extension-load bug (confirmed).** `GSD_BUNDLED_EXTENSION_PATHS` in `loader.ts` currently points to `src/resources/extensions/*.ts` (package-relative source paths). The main gsd process is clean — `buildResourceLoader({ agentDir })` discovers extensions from `~/.gsd/agent/extensions/` only. But when the patched subagent spawns a child gsd process with `--extension` CLI flags (from `GSD_BUNDLED_EXTENSION_PATHS`), the child also runs `initResources` (syncing to `~/.gsd/agent/extensions/`) and `buildResourceLoader({ agentDir })` (discovering from agentDir). Pi's `mergePaths` deduplicates by resolved path — `src/resources/extensions/gsd/index.ts` ≠ `~/.gsd/agent/extensions/gsd/index.ts` — so both load. Pi's `detectExtensionConflicts` catches identical tool names from different paths and surfaces them as `extensionsResult.errors` → stderr. The fix: point `GSD_BUNDLED_EXTENSION_PATHS` to `agentDir/extensions/` paths instead of `src/resources/extensions/` paths. Since subagent spawning only happens inside a running session (after `initResources` has already synced), `~/.gsd/agent/extensions/` is guaranteed to exist by the time any child is spawned.

**2. Uncommitted pre-S04 changes in working tree.** Two prior-session changes are staged but uncommitted: (a) `src/loader.ts` has a `NODE_PATH` + `Module._initPaths()` fix that makes gsd's own `node_modules` (including `playwright`) visible to jiti-loaded extensions — critical for browser-tools to work; (b) `src/resources/extensions/browser-tools/package.json` changed `playwright` from `dependencies` to `peerDependencies` (optional) and deleted `package-lock.json` — prevents npm from trying to install playwright again inside the browser-tools subtree. Both are valid and needed; they should be committed as the first act of S04.

**3. `prepublishOnly` script is missing.** The milestone roadmap explicitly lists this as a deliverable. Without it, `npm publish` may ship stale `dist/` if the developer forgot to rebuild. The fix is one line: `"prepublishOnly": "npm run build"`.

The tarball install test already works — a manual test during research confirmed the binary installs cleanly, the TUI shows "gsd" branding, the wizard fires (for missing optional keys), and extensions load without errors. The primary remaining work is: (1) fix GSD_BUNDLED_EXTENSION_PATHS, (2) commit and rebuild, (3) run a scripted smoke test, (4) publish.

## Recommendation

**Four tasks:**

- **T01 — Fix GSD_BUNDLED_EXTENSION_PATHS + commit pre-S04 changes:** Update `loader.ts` to compute extension entry points from `agentDir` instead of `resourcesDir`. Commit the NODE_PATH fix, browser-tools package.json fix, and GSD_BUNDLED_EXTENSION_PATHS fix together. Rebuild. Verify no double-load errors when subagent would run.

- **T02 — Add prepublishOnly, resolve STATE.md conflict, squash-merge S03:** Add `"prepublishOnly": "npm run build"` to `package.json`. Fix the merge conflict in `STATE.md`. Squash-merge S03 branch to main. Cut S04 fresh from main.

- **T03 — Tarball smoke test + scripts/verify-s04.sh:** `npm pack` → fresh tarball → `npm install -g --prefix /tmp/gsd-smoke-test ./gsd-*.tgz` → run binary → assert branding, extension load (zero errors), wizard fires for missing optional keys, `~/.pi/` untouched. Script should be automated where possible (non-TTY path); interactive wizard is UAT-only.

- **T04 — Publish to npm + registry verification:** `npm publish --access public`. Verify with `npm view @glittercowboy/gsd`. Then `npm install -g @glittercowboy/gsd` from the registry in a clean prefix to confirm the registry-served package works.

## Don't Hand-Roll

| Problem | Existing Solution | Why Use It |
|---------|------------------|------------|
| Clean global install test | `npm install -g --prefix /tmp/test-prefix ./gsd-*.tgz` | Installs to an isolated prefix without polluting the real global. Binary is at `$prefix/bin/gsd`. Standard npm feature. |
| Stale dist/ before publish | `"prepublishOnly": "npm run build"` | npm lifecycle hook that runs before `npm publish` and `npm pack`. One-line addition. |
| Verifying tarball contents | `npm publish --dry-run` | Lists all 129 files with sizes, confirms tarball details without publishing. Already works. |
| Scoped package visibility | `npm publish --access public` | Scoped packages (`@scope/pkg`) default to `--access restricted` (private). Required for free npm accounts to publish publicly. |

## Existing Code and Patterns

- `src/loader.ts` — Sets all 4 GSD_ env vars before `cli.js` loads. Has uncommitted NODE_PATH fix (must be committed). **GSD_BUNDLED_EXTENSION_PATHS currently points to `src/resources/extensions/` paths — must be changed to `agentDir/extensions/` paths** to prevent double-load in subagent children. Import pattern for the fix: `agentDir` is already imported from `./app-paths.js`.

- `src/resource-loader.ts` — `initResources(agentDir)` syncs `src/resources/extensions/` → `agentDir/extensions/` using `cpSync` with `force: true` on every launch. This is the always-overwrite strategy for `npm update -g` (R008). Extensions in `~/.gsd/agent/extensions/` are always the versions from the currently installed package. `buildResourceLoader(agentDir)` creates `DefaultResourceLoader({ agentDir })` with no `additionalExtensionPaths` — relies entirely on pi's agentDir scan.

- `scripts/postinstall.js` — Runs `npx playwright install chromium` after `npm install`. Wrapped in try/catch; non-fatal if it fails. Uses `import` syntax (ESM) — correct since `package.json` has `"type": "module"`. Works correctly: confirmed during tarball install test.

- `scripts/verify-s03.sh` — Pattern to follow for `scripts/verify-s04.sh`: uses `env -i` for env isolation, background process + `sleep + kill` pattern (macOS has no GNU timeout), labeled `PASS/FAIL` output, exits non-zero on first failure.

- `package.json` `files` array: `["dist", "pkg", "src/resources", "scripts/postinstall.js", "package.json", "README.md"]`. All required files are present. `src/resources` is correctly included — this is the S02 forward-intelligence concern that has been validated. Tarball at 350.7 kB packed / 1.4 MB unpacked / 129 files.

- `pkg/` shim — Contains `package.json` (piConfig) + `dist/modes/interactive/theme/` (pi theme assets). `PI_PACKAGE_DIR` in `loader.ts` resolves to this via `resolve(dirname(fileURLToPath(import.meta.url)), '..', 'pkg')`. Confirmed correct after global install: `~/.nvm/.../dist/loader.js` → `..` → package root → `pkg/`.

## Constraints

- **Scoped package requires `--access public`** — `@glittercowboy/gsd` is a scoped package. npm defaults to restricted (private) for scoped packages. Must pass `--access public` to publish publicly. npm account `glittercowboy` is confirmed authenticated (`npm whoami` returns `glittercowboy`).

- **Package name is `@glittercowboy/gsd`, not `gsd-pi`** — The `package.json` name is `@glittercowboy/gsd`. README install command is `npm install -g @glittercowboy/gsd`. The milestone roadmap/requirements reference `gsd-pi` as the package name, but that reflects an earlier naming discussion. The current code uses the scoped name; the plain `gsd` name is taken on npm (by an unrelated package). Do not rename — proceed with `@glittercowboy/gsd`.

- **`agentDir/extensions/` must exist before referencing as GSD_BUNDLED_EXTENSION_PATHS** — The paths in `GSD_BUNDLED_EXTENSION_PATHS` are passed by the subagent as `--extension` CLI args to spawned child processes. `initResources` must have run at least once (on first launch) before subagent spawning is used. This is guaranteed by the execution order: wizard → initResources → createAgentSession → user interaction → subagent spawn.

- **NODE_PATH + `Module._initPaths()` must stay in loader.ts** — jiti loads extensions from their path; Node's module resolution for `require`/`import` inside extensions looks at `NODE_PATH`. Without this, `browser-tools/index.ts` cannot resolve `playwright` from gsd's `node_modules/`. The `Module._initPaths()` call must happen before the `cli.js` dynamic import, while loader.ts is still evaluating synchronously.

- **`copy-themes` uses CJS `require()` in inline `-e` script** — This works even though `"type": "module"` is set, because `node -e` inline scripts don't inherit the ESM module type from `package.json`. Do not "fix" this.

- **State/merge conflict in STATE.md** — There is a Git merge conflict marker (`<<<<<<< HEAD` / `>>>>>>> gsd/M001/S03`) in `STATE.md`. Must be resolved before S04 commits.

## Common Pitfalls

- **Publishing without `--access public`** — Scoped package defaults to restricted. The publish command will succeed (no error), but the package will be private and `npm install -g @glittercowboy/gsd` will fail with 403 for anonymous users. Always include `--access public`.

- **Testing with shell env vars leaking into the "clean" test** — If `BRAVE_API_KEY`, `CONTEXT7_API_KEY`, or `JINA_API_KEY` are exported in the shell, the tarball install test binary will see them and the wizard won't fire. Use `env -i HOME=$HOME PATH=$PATH <test command>` to isolate, as in `verify-s03.sh`. The tarball install test during research showed only Jina warning because the shell had Brave/Context7 set.

- **Double-load in subagent if GSD_BUNDLED_EXTENSION_PATHS fix is skipped** — If `GSD_BUNDLED_EXTENSION_PATHS` still points to `src/resources/extensions/` paths, every subagent spawn will emit conflict errors like `[gsd] Extension load error: Conflict: tool 'bash' already registered from ~/.gsd/agent/extensions/...`. The model still runs but with duplicate tools in context. Fix before S04 closes.

- **prepublishOnly runs on `npm pack` too** — `prepublishOnly` fires before both `npm publish` and `npm pack`. This means every `npm pack` will rebuild dist/ — which is correct but takes ~3 seconds. Do not use `prepare` (which also runs on `npm install`) instead of `prepublishOnly`.

- **Tarball vs registry install path difference** — The binary resolves `PI_PACKAGE_DIR`, `GSD_WORKFLOW_PATH`, and `GSD_BUNDLED_EXTENSION_PATHS` using `import.meta.url` (the dist/loader.js path). After tarball install to a temp prefix: `<prefix>/lib/node_modules/@glittercowboy/gsd/dist/loader.js`. After real global install: `~/.nvm/.../node_modules/@glittercowboy/gsd/dist/loader.js`. Both resolve `..` correctly to the package root. Confirmed working in tarball test.

- **dist/modes/ in the bundle (extra but harmless)** — `dist/modes/interactive/theme/` appears in the tarball because it's under `dist/` (in `files`). The correct theme dir (for `PI_PACKAGE_DIR`) is `pkg/dist/modes/...`. The extra copy in `dist/modes/` is harmless redundancy from an early S01 copy-themes invocation — don't try to clean it up in S04 (it would complicate git history unnecessarily).

## Open Risks

- **`Module._initPaths()` is a private Node.js API** — It could be removed in a future Node.js version. The `?.()` optional-chaining call makes it fail gracefully, but if it's removed, browser-tools will again fail to load (jiti can't find `playwright`). A more robust fix would be to pass `--require` or use `--import` in the node exec, but that's more invasive. Acceptable risk for M001.

- **npm `postinstall` running `playwright install` on every `npm install -g`** — On CI or constrained environments, this could fail and print warnings. The try/catch makes it non-fatal. But if the user doesn't have network access at install time, browser tools won't work until they manually run `npx playwright install chromium`. Accept for M001; note in README.

- **R001 says `gsd-pi` but code ships as `@glittercowboy/gsd`** — The requirement description references `gsd-pi` as the package name. The actual package is `@glittercowboy/gsd`. R001's validation criteria (single-command install) is met; only the specific package name in the description is stale. No functional risk — update R001 description in REQUIREMENTS.md when closing S04.

- **Subagent spawn not exercised in S04 smoke test** — The tarball smoke test will verify extension load and branding, but actually exercising subagent delegation requires running a task through `/gsd auto`. This would require a real Anthropic key and make the smoke test non-deterministic. Accept: extension load verification (zero conflict errors in stderr) is the proxy for correctness; full subagent delegation is UAT-only.

## Skills Discovered

| Technology | Skill | Status |
|------------|-------|--------|
| npm publish / release | none found | none found |

No relevant installed skills. This slice uses standard npm tooling — no skill needed.

## Verification Plan (informs S04-PLAN.md)

The verify script (`scripts/verify-s04.sh`) should cover:

1. `dist/loader.js` exists and has NODE_PATH block
2. `GSD_BUNDLED_EXTENSION_PATHS` in dist/loader.js resolves to agentDir paths (not src/resources paths)
3. `package.json` has `prepublishOnly: "npm run build"`
4. `npm pack --dry-run` lists all expected files (dist/, pkg/, src/resources/, scripts/postinstall.js)
5. Tarball install to temp prefix → binary at `$prefix/bin/gsd` symlinks correctly
6. Binary from temp prefix launches without extension conflict errors
7. Binary from temp prefix shows "gsd" branding in ANSI output
8. `~/.pi/` session count unchanged before/after tarball install test
9. Non-TTY launch from tarball install → warning for missing optional keys (not crash)

UAT (interactive only):
- Launch from tarball install with no optional keys → wizard fires with masked prompts
- `/gsd` command responds correctly
- `~/.gsd/agent/extensions/` populated after first launch

## Sources

- Pi resource-loader.js source (`mergePaths`, `detectExtensionConflicts`) — confirmed double-load behavior when same tool registered from two different resolved paths; deduplication only works if paths resolve identically
- Tarball install test (manual, during research) — `npm install -g --prefix /tmp/test ./glittercowboy-gsd-0.1.0.tgz` produced working binary; TUI showed "gsd" branding; Jina warning only (Brave/Context7 from shell env); 294 packages in 11s
- `npm publish --dry-run` (during research) — confirmed 129 files, 350.7 kB packed, correct tarball contents; all critical files present
- `git diff src/loader.ts` — revealed uncommitted NODE_PATH + Module._initPaths fix; confirmed needed for browser-tools playwright resolution
- `git diff src/resources/extensions/browser-tools/package.json` — revealed playwright changed to peerDependencies (optional); prevents double-install

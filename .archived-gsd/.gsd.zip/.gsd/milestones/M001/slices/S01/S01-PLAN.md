# S01: CLI Scaffold and Branding

**Goal:** `gsd` binary exists, launches pi's InteractiveMode, shows "gsd" in the TUI header, and stores state in `~/.gsd/` — verified by running the compiled binary.
**Demo:** `node dist/loader.js` launches and the TUI header reads "gsd" not "pi"; pressing Ctrl+C confirms process exits cleanly; `ls ~/.gsd/` shows state directories created.

## Must-Haves

- `package.json` declares `name: "@lexc/gsd"`, `bin: { gsd: "dist/loader.js" }`, `type: "module"`, `piConfig: { name: "gsd", configDir: ".gsd" }`, and `@mariozechner/pi-coding-agent` as a dependency
- `tsconfig.json` compiles with `module: "NodeNext"`, `moduleResolution: "NodeNext"`, `target: "ES2022"`
- `src/loader.ts` sets `PI_PACKAGE_DIR` to the package root and then does a dynamic `import('./cli.js')` — no static pi imports in this file
- `src/cli.ts` uses static imports of pi SDK (`AuthStorage`, `ModelRegistry`, `SettingsManager`, `SessionManager`, `DefaultResourceLoader`, `createAgentSession`, `InteractiveMode`) and wires them together
- `src/app-paths.ts` exports `appRoot`, `agentDir`, `sessionsDir`, `authFilePath` pointing into `~/.gsd/`
- `tsc` produces `dist/loader.js`, `dist/cli.js`, `dist/app-paths.js` with zero errors
- `node dist/loader.js` launches and TUI header shows "gsd" not "pi"
- State is written to `~/.gsd/`, never `~/.pi/`

## Proof Level

- This slice proves: integration
- Real runtime required: yes — binary must actually launch and show correct TUI
- Human/UAT required: no — TUI header text can be verified by inspecting pi source behavior; `~/.gsd/` existence verifiable with `ls`

## Verification

The stopping condition is a shell verification script that covers all must-haves:

```bash
# 1. Build succeeds
npm run build 2>&1 | tail -5

# 2. dist/ files exist
ls dist/loader.js dist/cli.js dist/app-paths.js

# 3. Binary launches (non-interactive test — check env var injection)
node -e "
  import('./dist/loader.js').catch(e => {
    // InteractiveMode will fail in non-TTY — that's expected
    // What matters is PI_PACKAGE_DIR was set before it ran
    console.log('launch attempted')
  })
"

# 4. PI_PACKAGE_DIR is set to the package root (branding mechanism)
node -e "
  import { fileURLToPath } from 'url'
  import { dirname, resolve } from 'path'
  const pkgDir = resolve(dirname(fileURLToPath(import.meta.url)))
  const expected = pkgDir
  console.log('package root:', pkgDir)
" 

# 5. ~/.gsd/ state directories created after a run
ls ~/.gsd/ || echo 'not yet created (first run)'

# 6. Confirm ~/.pi/ is untouched (R007)
ls ~/.pi/agent/sessions/ 2>/dev/null | wc -l  # should not grow
```

Primary integration verification: run `node dist/loader.js` with a real TTY (via `script -q /dev/null node dist/loader.js`) and confirm TUI output contains "gsd" and not just "pi". This is the binary launch smoke test.

Secondary: confirm `piConfig` in `package.json` is parsed correctly by reading `dist/config.js`-equivalent behavior:
```bash
node -e "
  import { createRequire } from 'module'
  const req = createRequire(import.meta.url)
  const pkg = req('./package.json')
  console.log('name:', pkg.piConfig?.name)      // must be 'gsd'
  console.log('configDir:', pkg.piConfig?.configDir)  // must be '.gsd'
"
```

## Observability / Diagnostics

- Runtime signals: `PI_PACKAGE_DIR` environment variable is the primary diagnostic — if set wrong, `config.js` falls back to walking up from `__dirname` and finds pi's own `package.json` instead of gsd's; TUI header will show "pi"
- Inspection surfaces: `node -e "import('./dist/loader.js').then(() => process.exit(0))"` — error output reveals import failures; `echo $PI_PACKAGE_DIR` after launch (not useful — it's an in-process var, not exported to parent shell)
- Failure visibility: if TUI shows "pi" → `PI_PACKAGE_DIR` was not set before `config.js` loaded; if `tsc` fails → TypeScript errors in stderr; if `node dist/loader.js` throws → import path or dep resolution issue visible in stack trace
- Redaction constraints: none — no secrets in this slice

## Integration Closure

- Upstream surfaces consumed: `@mariozechner/pi-coding-agent` SDK (`AuthStorage`, `ModelRegistry`, `SettingsManager`, `SessionManager`, `DefaultResourceLoader`, `createAgentSession`, `InteractiveMode`)
- New wiring introduced in this slice: `loader.ts → cli.ts` (dynamic import chain), `cli.ts → pi SDK` (static imports), `piConfig` in `package.json → config.js` (branding), `app-paths.ts → cli.ts` (state paths)
- What remains before the milestone is truly usable end-to-end: S02 (extensions/agents), S03 (first-run wizard), S04 (npm publish)

## Tasks

- [x] **T01: Scaffold package.json and tsconfig** `est:20m`
  - Why: Foundation. Nothing compiles or installs without `package.json` + `tsconfig.json`. This also installs the pi SDK dep so T02 has types to import against.
  - Files: `package.json`, `tsconfig.json`
  - Do: Write `package.json` with `name: "@lexc/gsd"`, `version: "0.1.0"`, `type: "module"`, `bin: { "gsd": "dist/loader.js" }`, `piConfig: { "name": "gsd", "configDir": ".gsd" }`, `engines: { "node": ">=20.6.0" }`, `scripts: { "build": "tsc", "dev": "tsc --watch" }`, deps `{ "@mariozechner/pi-coding-agent": "^0.57.1" }`, devDeps `{ "@types/node": "^22.0.0", "typescript": "^5.4.0" }`. Write `tsconfig.json` with `compilerOptions: { module: "NodeNext", moduleResolution: "NodeNext", target: "ES2022", outDir: "dist", rootDir: "src", strict: true, declaration: true, esModuleInterop: true }` and `include: ["src"]`. Run `npm install`.
  - Verify: `npm install` exits 0; `node_modules/@mariozechner/pi-coding-agent` exists; `npx tsc --version` works; `cat package.json | node -e "const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); console.log(d.piConfig?.name)"` prints `gsd`
  - Done when: `npm install` succeeds and `package.json` has correct `piConfig`, `bin`, and `type` fields

- [x] **T02: Write app-paths, loader, and cli source** `est:30m`
  - Why: The three source files are the entire application. `app-paths.ts` provides path constants. `loader.ts` is the binary entrypoint that enforces ESM evaluation order. `cli.ts` is the SDK integration. All must be written before any build attempt.
  - Files: `src/app-paths.ts`, `src/loader.ts`, `src/cli.ts`
  - Do:
    1. Write `src/app-paths.ts`: import `os` and `path`; export `appRoot = join(homedir(), '.gsd')`, `agentDir = join(appRoot, 'agent')`, `sessionsDir = join(appRoot, 'sessions')`, `authFilePath = join(agentDir, 'auth.json')`. Use `.js` extension in any cross-file imports.
    2. Write `src/loader.ts`: use `import { fileURLToPath } from 'url'` and `import { dirname, resolve } from 'path'` (these are Node built-ins — safe to import statically). Compute `const pkgDir = resolve(dirname(fileURLToPath(import.meta.url)), '..')`. Set `process.env.PI_PACKAGE_DIR = pkgDir` and `process.title = 'gsd'`. Then `await import('./cli.js')`. No pi SDK imports in this file.
    3. Write `src/cli.ts`: static imports from `@mariozechner/pi-coding-agent` — `AuthStorage`, `ModelRegistry`, `SettingsManager`, `SessionManager`, `DefaultResourceLoader`, `createAgentSession`, `InteractiveMode`. Import `agentDir`, `sessionsDir`, `authFilePath` from `'./app-paths.js'`. Create managers in this order: `AuthStorage.create(authFilePath)`, `ModelRegistry.create()`, `SettingsManager.create(agentDir)`, `SessionManager.create(process.cwd(), sessionsDir)`. Create `DefaultResourceLoader` with `{ agentDir }`. Call `createAgentSession({ authStorage, modelRegistry, settingsManager, sessionManager, resourceLoader })`. Call `await InteractiveMode.run(session)`. Wrap in top-level async IIFE or use top-level await.
    - Key constraint: loader.ts must have zero pi SDK imports. cli.ts must have zero dynamic imports — all pi imports are static.
  - Verify: Each file exists and is valid TypeScript (check with `npx tsc --noEmit` before building)
  - Done when: `npx tsc --noEmit` exits 0 with zero errors across all three files

- [x] **T03: Build, link, and verify gsd launches with correct branding** `est:30m`
  - Why: Closes the slice. Proves the two-file loader pattern works, `PI_PACKAGE_DIR` is seen by `config.js` before it evaluates `APP_NAME`, and the TUI header shows "gsd". Also confirms `~/.gsd/` state isolation (R007).
  - Files: `dist/` (output), `package.json` (add `files` and `.gitignore` for dist)
  - Do:
    1. Run `npm run build` — fix any tsc errors.
    2. Add `dist/` to `.gitignore` if not present. Add `"files": ["dist", "package.json"]` to `package.json` (prep for S04).
    3. Run `npm link` (or `node dist/loader.js`) to test the binary.
    4. Verify branding: launch `gsd` (or `node dist/loader.js`) in a TTY context. Confirm TUI header says "gsd". The fastest headless check: `node -e "import('./dist/loader.js')" 2>&1 | head -20` — even without a real TTY, pi will error with a message referencing its app name or config dir, revealing whether the right package was loaded.
    5. Confirm `piConfig` is read: `node -e "import { createRequire } from 'module'; const r=createRequire(import.meta.url); const p=r('./package.json'); console.log(p.piConfig?.name, p.piConfig?.configDir)"` → prints `gsd .gsd`.
    6. After a real `gsd` launch (or `node dist/loader.js` in interactive TTY), confirm `~/.gsd/` directories exist and `~/.pi/agent/sessions/` count hasn't grown.
    7. Confirm `~/.pi/` is untouched by running: `stat ~/.pi/agent/sessions/ 2>/dev/null` before and after; session count must not change.
  - Verify:
    - `npm run build` exits 0
    - `dist/loader.js`, `dist/cli.js`, `dist/app-paths.js` all exist
    - `node -e "import { createRequire } from 'module'; const r=createRequire(import.meta.url); const p=r('./package.json'); console.log(p.piConfig?.name)"` → `gsd`
    - TUI header shows "gsd" when launched with real TTY
    - `~/.gsd/` exists after run (state isolation confirmed)
    - `~/.pi/agent/sessions/` session count unchanged (R007 confirmed)
  - Done when: `npm run build` exits 0, binary launches showing "gsd" branding, `~/.gsd/` exists, `~/.pi/` is untouched

## Files Likely Touched

- `package.json`
- `tsconfig.json`
- `src/app-paths.ts`
- `src/loader.ts`
- `src/cli.ts`
- `dist/loader.js` (generated)
- `dist/cli.js` (generated)
- `dist/app-paths.js` (generated)
- `.gitignore`

---
id: S01
parent: M001
milestone: M001
provides:
  - gsd binary (dist/loader.js) that launches pi's InteractiveMode with "gsd" TUI header
  - src/loader.ts — binary entrypoint: sets PI_PACKAGE_DIR to pkg/ shim before dynamic-importing cli.js
  - src/cli.ts — full SDK wiring (AuthStorage, ModelRegistry, SettingsManager, SessionManager, DefaultResourceLoader, createAgentSession, InteractiveMode)
  - src/app-paths.ts — ~/.gsd/ path constants (appRoot, agentDir, sessionsDir, authFilePath)
  - pkg/ shim directory with piConfig package.json and pi theme assets
  - package.json with bin.gsd, piConfig, type:module, files array, and build scripts
  - tsconfig.json with NodeNext/ESM compilation settings
  - State isolation confirmed: ~/.gsd/ created, ~/.pi/ untouched (R007)
requires: []
affects:
  - slice: S02
    provides: "src/app-paths.ts (agentDir for resource loader), working gsd binary to load extensions into"
  - slice: S03
    provides: "src/app-paths.ts (authFilePath for wizard), session_start hook surface from cli.ts"
key_files:
  - src/loader.ts
  - src/cli.ts
  - src/app-paths.ts
  - pkg/package.json
  - pkg/dist/modes/interactive/theme/dark.json
  - pkg/dist/modes/interactive/theme/light.json
  - package.json
  - tsconfig.json
key_decisions:
  - D003: PI_PACKAGE_DIR branding mechanism — set before pi internals load, points to pkg/ shim
  - D008: S01 verification strategy — shell commands + real TTY launch, no test framework
  - D009: files array set in S01 for S04 readiness
  - D010: ModelRegistry is a constructor, not static factory
  - D011: InteractiveMode.run() is an instance method, not static
  - D012: skipLibCheck:true to suppress transitive @google/genai type error
  - D013: PI_PACKAGE_DIR shim directory (pkg/) — avoids src/ collision in config.js::getThemesDir()
patterns_established:
  - Two-file loader pattern: loader.ts (sets env, dynamic-imports) → cli.ts (static SDK imports)
  - pkg/ is a shim directory — no src/, piConfig in package.json, pi theme assets in dist/modes/interactive/theme/
  - npm run copy-themes populates pkg/dist/modes/interactive/theme/ from node_modules at build time
  - All relative imports use .js extension (NodeNext requirement)
  - PI_PACKAGE_DIR must point to a directory with no src/ subdir to avoid getThemesDir() collision
observability_surfaces:
  - "Branding: (node dist/loader.js & sleep 2; kill $!) 2>&1 | strings | grep gsd — 'gsd' in output confirms header"
  - "State isolation: ls ~/.gsd/ shows agent/ and sessions/ dirs after first launch"
  - "R007: ls ~/.pi/agent/sessions/ | wc -l — count unchanged after gsd run"
  - "Theme load failure: ENOENT on dark.json means PI_PACKAGE_DIR wrong or copy-themes not run"
  - "Loader env var: grep PI_PACKAGE_DIR dist/loader.js — confirms pkg/ path"
  - "piConfig: node --input-type=module -e '...createRequire...pkg.piConfig' — confirms name=gsd"
drill_down_paths:
  - .gsd/milestones/M001/slices/S01/tasks/T01-SUMMARY.md
  - .gsd/milestones/M001/slices/S01/tasks/T02-SUMMARY.md
  - .gsd/milestones/M001/slices/S01/tasks/T03-SUMMARY.md
duration: ~1h (T01: 5m, T02: ~20m, T03: ~45m)
verification_result: passed
completed_at: 2026-03-10
---

# S01: CLI Scaffold and Branding

**`gsd` binary compiles, launches with "gsd" in TUI header, writes state to `~/.gsd/`, and leaves `~/.pi/` untouched — state isolation confirmed.**

## What Happened

Three tasks built the complete CLI scaffold:

**T01** wrote `package.json` and `tsconfig.json`. The key facts established here: `piConfig: { name: "gsd", configDir: ".gsd" }` embedded in `package.json` drives branding via the `PI_PACKAGE_DIR` mechanism; `type: "module"` enforces ESM-only; NodeNext module resolution is required. `npm install` resolved 292 packages including `@mariozechner/pi-coding-agent@^0.57.1`.

**T02** wrote all three source files. The pi SDK's actual API shapes differed from the plan's assumptions — `ModelRegistry` is a constructor (not a static factory), all manager `.create()` calls are synchronous (not async), `createAgentSession` returns `{ session, extensionsResult, ... }` requiring destructuring, and `InteractiveMode.run()` is an instance method. All three deviations were discovered from SDK type declarations and corrected. `npx tsc --noEmit` exits 0 after adding `skipLibCheck: true` to suppress a transitive type error from `@google/genai`.

**T03** built the binary and discovered a critical undocumented behavior: `config.js::getThemesDir()` checks if `<PI_PACKAGE_DIR>/src` exists — if yes, it routes theme resolution to `<PI_PACKAGE_DIR>/src/modes/interactive/theme/`. Because our project has a real `src/` directory, pointing `PI_PACKAGE_DIR` at the project root caused an `ENOENT` on theme files. The fix was a `pkg/` shim directory — a lean subdirectory containing only `package.json` (with piConfig) and `dist/modes/interactive/theme/` (pi theme assets). `PI_PACKAGE_DIR` now points to `pkg/`, which has no `src/` subdir. A `copy-themes` build step populates the theme assets from `node_modules` on every build. After this fix, the binary launched cleanly showing "gsd v0.1.0" in the TUI header.

## Verification

All slice-level must-haves verified:

```bash
# 1. Build exits 0
npm run build → exit 0

# 2. Dist files exist
ls dist/loader.js dist/cli.js dist/app-paths.js → all present

# 3. piConfig is correct
node --input-type=module → piConfig.name=gsd, piConfig.configDir=.gsd ✓

# 4. PI_PACKAGE_DIR set to pkg/
grep PI_PACKAGE_DIR dist/loader.js → process.env.PI_PACKAGE_DIR = pkgDir ✓

# 5. Theme assets present
ls pkg/dist/modes/interactive/theme/ → dark.json, light.json present ✓

# 6. TUI header shows "gsd"
(node dist/loader.js & sleep 2; kill $!) 2>&1 | strings | grep gsd
→ "gsd" appears 3+ times in TUI output ✓

# 7. State created in ~/.gsd/
ls ~/.gsd/ → agent/ sessions/ ✓

# 8. ~/.pi/ untouched (R007)
pi sessions before=28, after=28 → R007 OK ✓
```

## Requirements Advanced

- R001 — `gsd` binary exists at `dist/loader.js`, `bin.gsd` is declared in `package.json`; binary launches from `node dist/loader.js`. Full npm install smoke test deferred to S04.
- R002 — TUI header confirmed to show "gsd" not "pi"; `piConfig.name=gsd`, `piConfig.configDir=.gsd` verified; state is in `~/.gsd/`.
- R007 — State isolation confirmed: `~/.gsd/` is created; `~/.pi/agent/sessions/` count unchanged (28 before and after gsd launch).

## Requirements Validated

- R002 — Validated: TUI header shows "gsd" in live runtime launch; `piConfig` confirmed correct; `~/.gsd/` confirmed created; `~/.pi/` confirmed untouched. All R002 success criteria are directly observable and verified.
- R007 — Validated: session count in `~/.pi/agent/sessions/` is identical before and after `gsd` launch (28/28). State isolation is mechanically enforced by `app-paths.ts` and verified at runtime.

## New Requirements Surfaced

- None discovered during S01 execution.

## Requirements Invalidated or Re-scoped

- None.

## Deviations

**D013 (significant):** `PI_PACKAGE_DIR` was changed from pointing to the project root to pointing to `pkg/` shim directory. The plan assumed pointing to project root would work. Root cause: `config.js::getThemesDir()` checks for a `src/` subdirectory at the PI_PACKAGE_DIR target — if found, it routes theme resolution through `src/` instead of `dist/`, causing ENOENT. Our project's real `src/` directory triggered this path. The two-file loader pattern is unchanged; only the value of `PI_PACKAGE_DIR` and the introduction of the `pkg/` shim are new. This deviation is documented in D013 and affects how S04 packages the binary — `pkg/` must be included in `files`.

**SDK API shapes (T02):** Four plan assumptions about pi SDK APIs were wrong (ModelRegistry constructor, synchronous managers, createAgentSession destructuring, InteractiveMode instance method). All corrected from SDK type declarations. No architectural impact.

**`copy-themes` scope (T03):** Plan described copying themes to `dist/modes/interactive/theme/`. Changed to `pkg/dist/modes/interactive/theme/` — the actual PI_PACKAGE_DIR target.

## Known Limitations

- No bundled extensions yet — `gsd` launches but `/gsd` command is unavailable (S02's job).
- No first-run wizard — `gsd` will not prompt for API keys on fresh install (S03's job).
- `pkg/` contains a copy of pi's theme JSON files that must be kept in sync with the pi dep version. The `copy-themes` build step handles this automatically, but it is a coupling point.

## Follow-ups

- S02 must add `pkg/` to the `files` array (already done — `"files": ["dist", "pkg", "package.json", "README.md"]`) and ensure resource loader works correctly with `agentDir` from `app-paths.ts`.
- S03 must hook into the `session_start` event surface exposed by `cli.ts` for wizard triggering.
- S04 must verify that `pkg/` is included in the tarball and that `copy-themes` runs correctly during `prepublishOnly`.

## Files Created/Modified

- `package.json` — project manifest with piConfig, bin.gsd, type:module, files array, build+copy-themes scripts, and all dependencies
- `tsconfig.json` — NodeNext/ESM TypeScript compilation config with skipLibCheck:true
- `src/app-paths.ts` — exports appRoot, agentDir, sessionsDir, authFilePath pointing to ~/.gsd/
- `src/loader.ts` — binary entrypoint: sets PI_PACKAGE_DIR to pkg/ shim, sets process.title, dynamic-imports cli.js
- `src/cli.ts` — SDK integration: constructs all managers, calls createAgentSession, runs InteractiveMode
- `pkg/package.json` — piConfig shim with { name: "gsd", configDir: ".gsd" }
- `pkg/dist/modes/interactive/theme/dark.json` — pi theme asset (copied by build)
- `pkg/dist/modes/interactive/theme/light.json` — pi theme asset (copied by build)
- `.gitignore` — dist/ added
- `node_modules/` — 292 packages installed including @mariozechner/pi-coding-agent
- `package-lock.json` — generated lockfile
- `dist/loader.js`, `dist/cli.js`, `dist/app-paths.js` — compiled output (gitignored)

## Forward Intelligence

### What the next slice should know

- `PI_PACKAGE_DIR` points to `pkg/`, not the project root. Any resource that pi's config.js resolves relative to `PI_PACKAGE_DIR` must exist inside `pkg/`. S02's resource loader wires extension paths through `DefaultResourceLoader.additionalExtensionPaths` — these are absolute paths, not relative to `PI_PACKAGE_DIR`, so this should not be a problem.
- `pkg/` is a committed shim directory. `pkg/dist/modes/interactive/theme/` is populated at build time by `copy-themes`. The static JSON assets (`dark.json`, `light.json`) are not committed — they're generated on every `npm run build`.
- `agentDir` from `app-paths.ts` is `~/.gsd/agent/`. S02's `DefaultResourceLoader` should use this as the base for its agent directory. Extensions in `src/resources/extensions/` will need an absolute path wired in.
- The `session_start` event hook in `cli.ts` is the injection point for S03's wizard. The current `cli.ts` has no event listener wired yet — S03 adds it.
- `createAgentSession` returns `{ session, extensionsResult, modelFallbackMessage }`. The `extensionsResult` is available for S02 to inspect extension load success/failure at launch time.

### What's fragile

- `pkg/dist/modes/interactive/theme/` contents — if `copy-themes` doesn't run (or runs against a different node_modules path), the binary will fail at launch with ENOENT on dark.json. The `postbuild` hook mitigates this for local builds, but S04 must verify the `prepublishOnly` script covers it for npm publish.
- `config.js::getThemesDir()` src-check behavior — this is undocumented pi internals. If pi updates `config.js` to change this logic, the `pkg/` shim approach could break silently. Mitigation: the ENOENT on dark.json is the observable failure signal.
- `skipLibCheck: true` — masks any future type errors from transitive pi/google deps. Not harmful today but worth revisiting if type safety needs tightening.

### Authoritative diagnostics

- **Branding failure:** If TUI shows "pi" → `cat dist/loader.js | grep PI_PACKAGE_DIR` confirms the value being set. Wrong value (or not set before config.js loads) means config.js finds pi's own package.json.
- **Theme failure (ENOENT):** `ls pkg/dist/modes/interactive/theme/` — must show dark.json and light.json. Run `npm run copy-themes` to fix.
- **Import failures:** `node dist/loader.js` stack trace prints the unresolved path verbatim.
- **Type errors:** `npx tsc --noEmit` names exact file + line.

### What assumptions changed

- Plan assumed `PI_PACKAGE_DIR` → project root. Actually → `pkg/` shim required due to undocumented getThemesDir() src-check behavior.
- Plan assumed `ModelRegistry.create()` static factory. Actually → `new ModelRegistry(authStorage)` constructor.
- Plan assumed `InteractiveMode.run(session)` static call. Actually → instance method.
- Plan assumed async manager creation. Actually → all synchronous.

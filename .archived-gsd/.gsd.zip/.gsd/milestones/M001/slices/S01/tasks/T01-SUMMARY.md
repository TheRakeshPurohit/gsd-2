---
id: T01
parent: S01
milestone: M001
provides:
  - package.json with correct piConfig, bin, type, and dependencies
  - tsconfig.json with NodeNext/ESM compilation settings
  - node_modules/ with @mariozechner/pi-coding-agent installed
  - package-lock.json lockfile
key_files:
  - package.json
  - tsconfig.json
key_decisions:
  - Used @mariozechner/pi-coding-agent@^0.57.1 as runtime dependency (resolved to latest compatible)
  - NodeNext module+moduleResolution pair required for ESM with Node import resolution
patterns_established:
  - piConfig embedded in package.json drives branding via PI_PACKAGE_DIR mechanism
  - type:module at package level enforces ESM-only; no CJS interop needed
observability_surfaces:
  - "cat package.json | jq .piConfig — confirms branding config is correct"
  - "ls node_modules/@mariozechner/pi-coding-agent — confirms SDK installed"
duration: 5m
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T01: Scaffold package.json and tsconfig

**Created `package.json` and `tsconfig.json` with correct ESM/NodeNext settings and piConfig branding, installed all dependencies including `@mariozechner/pi-coding-agent`.**

## What Happened

Wrote `package.json` with `name: "@lexc/gsd"`, `type: "module"`, `bin: { "gsd": "dist/loader.js" }`, `piConfig: { "name": "gsd", "configDir": ".gsd" }`, and dependencies. Wrote `tsconfig.json` with `module: "NodeNext"`, `moduleResolution: "NodeNext"`, `target: "ES2022"`, `outDir: "dist"`, `rootDir: "src"`. Ran `npm install` — resolved 292 packages in ~6 seconds with 0 vulnerabilities.

## Verification

All checks passed:

```
cat package.json | node -e "...assert piConfig, type, bin..."  → package.json OK
ls node_modules/@mariozechner/pi-coding-agent/dist/config.js  → file exists
npx tsc --version                                              → Version 5.9.3
node -e "...createRequire...pkg.piConfig?.name..."             → gsd .gsd
```

## Diagnostics

- `cat package.json | jq .piConfig` → `{"name":"gsd","configDir":".gsd"}` — primary branding diagnostic
- `cat tsconfig.json` → confirms NodeNext/ESM settings
- If branding fails at runtime: wrong `PI_PACKAGE_DIR` — `config.js` finds pi's own package.json, TUI shows "pi" instead of "gsd"

## Deviations

TypeScript resolved to 5.9.3 (task plan specified `^5.4.0` — 5.9.3 is within the caret range, no issue).

## Known Issues

None.

## Files Created/Modified

- `package.json` — project manifest with piConfig branding, bin entry, ESM type, and all dependencies
- `tsconfig.json` — NodeNext/ESM TypeScript compilation config
- `node_modules/` — installed 292 packages including @mariozechner/pi-coding-agent
- `package-lock.json` — generated lockfile

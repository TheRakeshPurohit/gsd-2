---
estimated_steps: 5
estimated_files: 3
---

# T02: Write app-paths, loader, and cli source

**Slice:** S01 — CLI Scaffold and Branding
**Milestone:** M001

## Description

Write the three source files that constitute the entire gsd application for S01. `app-paths.ts` provides path constants for `~/.gsd/` state. `loader.ts` is the binary entrypoint — it sets `PI_PACKAGE_DIR` and then dynamically imports `cli.ts`. `cli.ts` does static pi SDK imports and wires the managers together. The ESM evaluation order is the critical invariant: pi's `config.js` must see `PI_PACKAGE_DIR` before its top-level `const APP_NAME` executes.

## Steps

1. Create `src/` directory if it doesn't exist.

2. Write `src/app-paths.ts`:
   ```typescript
   import { homedir } from 'os'
   import { join } from 'path'

   export const appRoot = join(homedir(), '.gsd')
   export const agentDir = join(appRoot, 'agent')
   export const sessionsDir = join(appRoot, 'sessions')
   export const authFilePath = join(agentDir, 'auth.json')
   ```
   No cross-file imports from gsd code needed here.

3. Write `src/loader.ts`:
   ```typescript
   import { fileURLToPath } from 'url'
   import { dirname, resolve } from 'path'

   // Compute the package root (one level up from dist/, where package.json lives)
   const pkgDir = resolve(dirname(fileURLToPath(import.meta.url)), '..')

   // MUST be set before any dynamic import of pi SDK fires — this is what config.js
   // reads to determine APP_NAME and CONFIG_DIR_NAME
   process.env.PI_PACKAGE_DIR = pkgDir
   process.title = 'gsd'

   // Dynamic import defers ESM evaluation — config.js will see PI_PACKAGE_DIR above
   await import('./cli.js')
   ```
   **Critical:** Zero pi SDK imports in this file. Only Node built-ins (`url`, `path`). Any static `import from '@mariozechner/pi-coding-agent'` here would be evaluated before the `process.env` assignment.

4. Write `src/cli.ts` — static pi SDK imports are safe here because this file only loads after loader.ts has set `PI_PACKAGE_DIR`:
   ```typescript
   import {
     AuthStorage,
     ModelRegistry,
     SettingsManager,
     SessionManager,
     DefaultResourceLoader,
     createAgentSession,
     InteractiveMode,
   } from '@mariozechner/pi-coding-agent'
   import { agentDir, sessionsDir, authFilePath } from './app-paths.js'

   const authStorage = await AuthStorage.create(authFilePath)
   const modelRegistry = await ModelRegistry.create()
   const settingsManager = await SettingsManager.create(agentDir)
   const sessionManager = await SessionManager.create(process.cwd(), sessionsDir)
   const resourceLoader = new DefaultResourceLoader({ agentDir })
   const session = await createAgentSession({
     authStorage,
     modelRegistry,
     settingsManager,
     sessionManager,
     resourceLoader,
   })

   await InteractiveMode.run(session)
   ```
   Use `.js` extensions on all relative imports (NodeNext requirement). Use top-level await (valid in ESM). Check the exact SDK export names against `node_modules/@mariozechner/pi-coding-agent/dist/index.js` to avoid runtime "not exported" errors.

5. Run `npx tsc --noEmit` to validate TypeScript without emitting — fix any type errors before T03.

## Must-Haves

- [ ] `src/loader.ts` has zero imports from `@mariozechner/pi-coding-agent` (static or dynamic)
- [ ] `src/loader.ts` sets `process.env.PI_PACKAGE_DIR` to `resolve(dirname(fileURLToPath(import.meta.url)), '..')` — pointing one level above `dist/` (i.e., the package root)
- [ ] `src/loader.ts` uses `await import('./cli.js')` (dynamic, not static)
- [ ] `src/cli.ts` uses static imports for all pi SDK items
- [ ] All relative imports use `.js` extension (e.g., `'./app-paths.js'` not `'./app-paths'`)
- [ ] `src/app-paths.ts` exports `appRoot`, `agentDir`, `sessionsDir`, `authFilePath` all pointing into `~/.gsd/`
- [ ] `npx tsc --noEmit` exits 0

## Verification

- `npx tsc --noEmit` exits 0 with no errors
- `grep 'PI_PACKAGE_DIR' src/loader.ts` → shows the assignment
- `grep 'import.*pi-coding-agent' src/loader.ts` → empty (no pi imports in loader)
- `grep "await import('./cli.js')" src/loader.ts` → matches
- `grep "from './app-paths.js'" src/cli.ts` → matches (correct extension)
- `node -e "import { homedir } from 'os'; import { join } from 'path'; console.log(join(homedir(), '.gsd'))"` → prints `~/.gsd` expanded path (sanity check app-paths logic)

## Observability Impact

- Signals added/changed: `process.env.PI_PACKAGE_DIR` is the primary runtime signal — if set incorrectly, `config.js` falls back to pi's own package.json and `APP_NAME` becomes "pi". Inspectable after the fact by checking what `config.js` resolved.
- How a future agent inspects this: If TUI shows wrong branding → `grep PI_PACKAGE_DIR src/loader.ts` confirms the value being set; `node -e "import('./dist/loader.js')" 2>&1` shows config resolution errors
- Failure state exposed: `tsc --noEmit` errors name the exact file + line; import resolution failures at runtime print the unresolved path; wrong `PI_PACKAGE_DIR` value produces "pi" TUI header (observable by running the binary)

## Inputs

- `T01-PLAN.md` / T01 output — `package.json` and `tsconfig.json` must exist; `node_modules/@mariozechner/pi-coding-agent` must be installed (for types)
- S01-RESEARCH.md — confirmed SDK exports (`AuthStorage`, `ModelRegistry`, `SettingsManager`, `SessionManager`, `DefaultResourceLoader`, `createAgentSession`, `InteractiveMode`), confirmed two-file loader pattern works, confirmed `.js` extension requirement in NodeNext
- D001 — SDK embedding via `createAgentSession` + `InteractiveMode` is locked
- D002 — state in `~/.gsd/` is locked; `app-paths.ts` must never reference `~/.pi/`
- D003 — `PI_PACKAGE_DIR` branding mechanism is locked; loader pattern is mandatory

## Expected Output

- `src/app-paths.ts` — path constants for `~/.gsd/` state directories
- `src/loader.ts` — binary entrypoint: sets `PI_PACKAGE_DIR`, dynamic-imports `cli.js`
- `src/cli.ts` — SDK integration: managers + session + InteractiveMode
- `npx tsc --noEmit` exits 0 (all three files compile cleanly)

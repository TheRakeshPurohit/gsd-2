---
estimated_steps: 7
estimated_files: 3
---

# T03: Build, link, and verify gsd launches with correct branding

**Slice:** S01 — CLI Scaffold and Branding
**Milestone:** M001

## Description

Compile the TypeScript source to `dist/`, then launch the binary and verify the TUI header shows "gsd", state lands in `~/.gsd/`, and `~/.pi/` is untouched. This is the integration proof for S01 — every must-have in the slice flows through this task. Fix any tsc or runtime errors that surface. Add `.gitignore` and `files` array cleanup.

## Steps

1. Run `npm run build`. If it fails, inspect `tsc` errors and fix in the source files. Common issues:
   - Wrong export names from `@mariozechner/pi-coding-agent` → check `node_modules/@mariozechner/pi-coding-agent/dist/index.js` for actual exports
   - Missing `.js` extensions on relative imports → add them
   - `top-level await` not allowed → ensure `tsconfig.json` has `target: "ES2022"` and `module: "NodeNext"`

2. Confirm output files exist: `ls dist/loader.js dist/cli.js dist/app-paths.js` → all three present.

3. Add `dist/` to `.gitignore` if not already present. Add `"files": ["dist", "package.json", "README.md"]` to `package.json` (correct npm publish manifest for S04).

4. Verify `piConfig` is readable at the package root:
   ```bash
   node -e "
     import { createRequire } from 'module'
     const req = createRequire(import.meta.url)
     const pkg = req('./package.json')
     console.log('piConfig.name:', pkg.piConfig?.name)
     console.log('piConfig.configDir:', pkg.piConfig?.configDir)
   "
   ```
   Must print `gsd` and `.gsd`.

5. Run the binary in a real TTY to verify branding. The most reliable headless check:
   ```bash
   # Note the session count before
   before=$(ls ~/.pi/agent/sessions/ 2>/dev/null | wc -l)
   
   # Launch with timeout (SIGTERM after 3s) — enough to see TUI init
   timeout 3 node dist/loader.js 2>&1 || true
   
   # Note sessions after
   after=$(ls ~/.pi/agent/sessions/ 2>/dev/null | wc -l)
   echo "pi sessions before=$before after=$after (must be equal for R007)"
   ```
   If the terminal is non-interactive, pi will likely exit quickly — that's fine. The key signals are:
   - Any error mentioning "gsd" or `.gsd` config dir → correct package loaded
   - No new entries in `~/.pi/agent/sessions/` → R007 confirmed

6. Launch `node dist/loader.js` in an actual interactive terminal (or use `script -q /dev/null node dist/loader.js`) and confirm visually that the TUI header reads "gsd" not "pi". This is the direct proof of the branding mechanism. If it shows "pi":
   - Check that `src/loader.ts` sets `process.env.PI_PACKAGE_DIR` before the dynamic import
   - Check that `PI_PACKAGE_DIR` points to the directory containing `package.json` (not `dist/`)
   - Check `dist/loader.js` to confirm the compiled output correctly sets the env var before the dynamic import

7. After a real launch, confirm `~/.gsd/` was created:
   ```bash
   ls ~/.gsd/
   # Expected: agent/ sessions/ (or similar — AuthStorage and SessionManager create dirs)
   ```
   Confirm `~/.pi/agent/sessions/` count is unchanged from before the run (step 5 baseline).

## Must-Haves

- [ ] `npm run build` exits 0
- [ ] `dist/loader.js`, `dist/cli.js`, `dist/app-paths.js` all exist
- [ ] `dist/` is in `.gitignore`
- [ ] `package.json` has `"files"` array including `"dist"` and `"package.json"`
- [ ] `piConfig.name` is `"gsd"` and `piConfig.configDir` is `".gsd"` (readable from package root)
- [ ] TUI header shows "gsd" when binary launches (integration proof)
- [ ] `~/.gsd/` exists after a run (state isolation — R002, R007)
- [ ] `~/.pi/agent/sessions/` count unchanged after gsd run (R007 confirmed)

## Verification

```bash
# 1. Build
npm run build && echo "BUILD OK"

# 2. Dist files
ls dist/loader.js dist/cli.js dist/app-paths.js && echo "DIST OK"

# 3. piConfig check
node -e "
  import { createRequire } from 'module'
  const r = createRequire(import.meta.url)
  const p = r('./package.json')
  console.assert(p.piConfig?.name === 'gsd', 'piConfig.name must be gsd')
  console.assert(p.piConfig?.configDir === '.gsd', 'piConfig.configDir must be .gsd')
  console.log('piConfig OK')
"

# 4. .gitignore includes dist
grep -q 'dist' .gitignore && echo "GITIGNORE OK"

# 5. files array includes dist
node -e "
  import { createRequire } from 'module'
  const r = createRequire(import.meta.url)
  const p = r('./package.json')
  console.assert(Array.isArray(p.files) && p.files.includes('dist'), 'files must include dist')
  console.log('files OK')
"

# 6. R007: ~/.pi/ session count unchanged
before=$(ls ~/.pi/agent/sessions/ 2>/dev/null | wc -l)
timeout 3 node dist/loader.js 2>&1 | head -5 || true
after=$(ls ~/.pi/agent/sessions/ 2>/dev/null | wc -l)
[ "$before" = "$after" ] && echo "R007 OK (pi untouched)" || echo "R007 FAIL (pi sessions changed)"

# 7. ~/.gsd/ exists (or will after real TTY launch)
ls ~/.gsd/ 2>/dev/null && echo "GSD STATE OK" || echo "GSD STATE: not yet created (may need real TTY launch)"
```

TUI branding verification (requires interactive terminal or `script` wrapper):
```bash
script -q /dev/null node dist/loader.js
# Visually confirm header shows "gsd" — Ctrl+C to exit
```

## Observability Impact

- Signals added/changed: Binary launch produces observable TUI output (header text is the branding signal); `~/.gsd/` directory creation is the state isolation signal; `~/.pi/` unchanged is the R007 signal
- How a future agent inspects this: `ls ~/.gsd/` → shows state was created; `ls ~/.pi/agent/sessions/` count before/after → confirms isolation; `timeout 3 node dist/loader.js 2>&1` → shows initialization output including any config errors
- Failure state exposed: If TUI shows "pi" → `PI_PACKAGE_DIR` misconfigured (check `dist/loader.js` assignment); if `~/.pi/` gains sessions → state path bug in `app-paths.ts` or `SessionManager` call; if binary crashes → tsc output or runtime import error visible in stderr

## Inputs

- T02 output — `src/app-paths.ts`, `src/loader.ts`, `src/cli.ts` all written and passing `tsc --noEmit`
- T01 output — `package.json`, `tsconfig.json`, `node_modules/` all present
- S01-RESEARCH.md — confirmed that `PI_PACKAGE_DIR` must point to package root (one level above `dist/`); confirmed `~/.gsd/` as correct state location
- D002, D003 — state isolation and branding mechanism locked

## Expected Output

- `dist/loader.js`, `dist/cli.js`, `dist/app-paths.js` — compiled TypeScript output
- `.gitignore` — updated with `dist/`
- `package.json` — updated with `files` array
- Working `gsd` binary: launches, shows "gsd" branding, writes state to `~/.gsd/`, leaves `~/.pi/` untouched
- S01 slice goal met: integration-level proof that the two-file loader pattern correctly sets `PI_PACKAGE_DIR` before pi's `config.js` evaluates `APP_NAME`

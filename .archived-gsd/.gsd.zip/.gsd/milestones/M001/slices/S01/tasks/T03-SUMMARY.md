---
id: T03
parent: S01
milestone: M001
provides:
  - Compiled dist/ (loader.js, cli.js, app-paths.js)
  - pkg/ shim directory with piConfig and pi theme assets
  - npm run build with copy-themes postbuild step
  - Verified gsd binary launches with "gsd" branding in TUI header
  - State isolation confirmed: ~/.gsd/ created, ~/.pi/ untouched (R007)
key_files:
  - src/loader.ts
  - pkg/package.json
  - pkg/dist/modes/interactive/theme/dark.json
  - pkg/dist/modes/interactive/theme/light.json
  - package.json
key_decisions:
  - D013: PI_PACKAGE_DIR points to pkg/ shim (not project root) to avoid src/ collision in config.js::getThemesDir()
patterns_established:
  - pkg/ is a shim directory — no src/, has piConfig in package.json, has pi theme assets in dist/modes/interactive/theme/
  - npm run copy-themes populates pkg/dist/modes/interactive/theme/ from node_modules at build time
  - dist/ is gitignored; pkg/ is committed (contains static JSON assets and package.json)
observability_surfaces:
  - "Branding: strings | grep gsd in TUI output confirms header shows 'gsd'"
  - "State isolation: ls ~/.gsd/ shows agent/ and sessions/ dirs after first launch"
  - "R007: ls ~/.pi/agent/sessions/ | wc -l — count unchanged after gsd run"
  - "Theme load failure: ENOENT on dark.json means PI_PACKAGE_DIR wrong or copy-themes not run"
  - "Loader env var: cat dist/loader.js | grep PI_PACKAGE_DIR — confirms pkg/ path"
duration: 45m
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T03: Build, link, and verify gsd launches with correct branding

**Binary compiles, launches, and shows "gsd" in TUI header; state goes to ~/.gsd/; ~/.pi/ is untouched.**

## What Happened

`npm run build` succeeded on the first attempt (tsc exit 0, all three dist files produced). The binary launched but immediately failed with `ENOENT: no such file or directory, open '/Users/lexchristopherson/Developer/gsd-2/src/modes/interactive/theme/dark.json'`.

**Root cause discovered:** `config.js::getThemesDir()` uses `getPackageDir()` (= `PI_PACKAGE_DIR`) and checks `existsSync(join(packageDir, "src"))`. Since our project has a real `src/` directory, it resolves themes to `<project-root>/src/modes/interactive/theme/` — which doesn't exist. This also would fail in production (no `src/`, but theme assets not in gsd's `dist/` either).

**Fix:** Created `pkg/` shim directory at project root with:
- `package.json` containing `piConfig: { name: "gsd", configDir: ".gsd" }`
- `dist/modes/interactive/theme/dark.json` and `light.json` (pi theme assets)

`PI_PACKAGE_DIR` now points to `pkg/` (updated in `src/loader.ts`). `pkg/` has no `src/` → `getThemesDir()` uses `dist/` → resolves to `pkg/dist/modes/interactive/theme/` → files found.

Added `npm run copy-themes` to the build script to populate `pkg/dist/modes/interactive/theme/` from `node_modules/@mariozechner/pi-coding-agent/dist/modes/interactive/theme/` on every build.

Updated `package.json`:
- Added `"files": ["dist", "pkg", "package.json", "README.md"]`
- `copy-themes` script using CJS `require` with direct relative `node_modules` path (pi's exports map doesn't export `./package.json`, so `require.resolve('@mariozechner/pi-coding-agent/package.json')` fails; direct path is reliable at build time)

After these fixes, binary launched cleanly with `gsd v0.1.0` in TUI header.

## Verification

```bash
# 1. Build
npm run build → exit 0, BUILD OK

# 2. Dist files
ls dist/loader.js dist/cli.js dist/app-paths.js → all present

# 3. piConfig
node --input-type=module → piConfig.name=gsd, piConfig.configDir=.gsd ✓
files array includes 'dist' and 'pkg' ✓

# 4. gitignore
grep dist .gitignore → GITIGNORE OK ✓

# 5. Branding
(node dist/loader.js & sleep 2; kill $PID) | strings | grep gsd
→ "gsd" appears 3+ times in TUI output ✓

# 6. R007 isolation
pi sessions before=28, after=28 → R007 OK (pi untouched) ✓

# 7. State
ls ~/.gsd/ → agent/ sessions/ → GSD STATE OK ✓
```

All slice-level must-haves confirmed.

## Diagnostics

- **Branding check:** `(node dist/loader.js & sleep 2; kill $!) 2>&1 | strings | grep gsd` — "gsd" in output confirms header
- **Theme path:** `cat dist/loader.js | grep PI_PACKAGE_DIR` — confirms `pkg/` is the target
- **Theme assets:** `ls pkg/dist/modes/interactive/theme/` — must show dark.json, light.json
- **R007:** `ls ~/.pi/agent/sessions/ | wc -l` before and after — count must be equal
- **State created:** `ls ~/.gsd/` — must show `agent/` and `sessions/`
- **Build fresh:** `npm run build` — always repopulates `pkg/dist/modes/interactive/theme/` via copy-themes

## Deviations

**Significant deviation:** `PI_PACKAGE_DIR` was changed from pointing to the project root to pointing to `pkg/` shim directory. Original plan assumed pointing to project root would work. Root cause was undocumented behavior of `config.js::getThemesDir()` colliding with our project's `src/` directory. The two-file loader pattern itself is unchanged; only the value set in `PI_PACKAGE_DIR` changed.

**`copy-themes` scope:** Originally planned to copy themes to `dist/modes/interactive/theme/`. Changed to copy to `pkg/dist/modes/interactive/theme/` — the actual PI_PACKAGE_DIR target.

## Known Issues

None. All S01 must-haves pass.

## Files Created/Modified

- `src/loader.ts` — Updated: `PI_PACKAGE_DIR` now points to `pkg/` shim instead of project root
- `pkg/package.json` — Created: piConfig shim with `{ name: "gsd", configDir: ".gsd" }`
- `pkg/dist/modes/interactive/theme/dark.json` — Created by copy-themes: pi theme asset
- `pkg/dist/modes/interactive/theme/light.json` — Created by copy-themes: pi theme asset
- `package.json` — Updated: added `files` array, added `copy-themes` script to build
- `dist/loader.js` — Compiled output (gitignored, regenerated by build)
- `dist/cli.js` — Compiled output (gitignored, regenerated by build)
- `dist/app-paths.js` — Compiled output (gitignored, regenerated by build)

---
id: T02
parent: S01
milestone: M001
provides:
  - src/app-paths.ts with ~/.gsd/ path constants
  - src/loader.ts as binary entrypoint (sets PI_PACKAGE_DIR, dynamic-imports cli.js)
  - src/cli.ts with full SDK wiring (managers + session + InteractiveMode)
  - npx tsc --noEmit exits 0
key_files:
  - src/app-paths.ts
  - src/loader.ts
  - src/cli.ts
  - tsconfig.json
key_decisions:
  - ModelRegistry takes constructor arg (authStorage), not a static .create() factory
  - AuthStorage.create(), SettingsManager.create(), SessionManager.create() are all synchronous
  - createAgentSession returns { session, extensionsResult, modelFallbackMessage } — must destructure
  - InteractiveMode is instantiated with new InteractiveMode(session), then .run() is called on the instance
  - skipLibCheck: true added to tsconfig to suppress transitive type error in @google/genai -> @modelcontextprotocol/sdk
patterns_established:
  - loader.ts contains zero SDK imports; only Node built-ins (url, path)
  - PI_PACKAGE_DIR set via process.env before any dynamic import to guarantee ESM evaluation order
  - All relative imports use .js extension (NodeNext requirement)
  - Top-level await used throughout (valid in ESM modules)
observability_surfaces:
  - process.env.PI_PACKAGE_DIR — primary branding diagnostic; wrong value → TUI shows "pi" instead of "gsd"
  - tsc --noEmit — type-level correctness surface for all three source files
  - node dist/loader.js — runtime smoke test; errors print stack with unresolved import paths
duration: ~20min
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T02: Write app-paths, loader, and cli source

**Three source files written and TypeScript-verified: loader sets PI_PACKAGE_DIR before SDK loads, cli wires all managers to InteractiveMode.**

## What Happened

Created `src/` directory and wrote all three source files per the task plan. The SDK type declarations revealed three deviations from the plan's assumed API shapes:

1. `ModelRegistry` has no static `.create()` — takes `authStorage` directly in constructor
2. `AuthStorage.create()`, `SettingsManager.create()`, `SessionManager.create()` are synchronous (no `await`)
3. `InteractiveMode` is not called as `InteractiveMode.run(session)` — must instantiate then call `.run()` on the instance

Additionally, `@google/genai`'s published type declarations reference `@modelcontextprotocol/sdk/client/index.js` which is not installed as a type dep, causing a transitive `tsc` error unrelated to gsd code. Added `skipLibCheck: true` to `tsconfig.json` to suppress it — standard practice for transitive type issues in third-party packages.

After corrections, `npx tsc --noEmit` exits 0 with no errors in any gsd source file.

## Verification

```
# tsc passes clean
npx tsc --noEmit → exit 0, no output

# PI_PACKAGE_DIR assignment present
grep 'PI_PACKAGE_DIR' src/loader.ts → process.env.PI_PACKAGE_DIR = pkgDir

# No pi SDK imports in loader
grep 'import.*pi-coding-agent' src/loader.ts → (empty — correct)

# Dynamic import present
grep "await import('./cli.js')" src/loader.ts → matches

# Correct .js extension on relative import
grep "from './app-paths.js'" src/cli.ts → matches

# app-paths logic sanity check
node -e "import { homedir } from 'os'; ..." → /Users/lexchristopherson/.gsd
```

All must-haves confirmed.

## Diagnostics

- **Branding**: If TUI shows "pi" → `grep PI_PACKAGE_DIR src/loader.ts` confirms value being set; wrong value means `config.js` walked up to pi's own package.json
- **Import failures**: `node dist/loader.js` stack trace prints unresolved path verbatim
- **Type errors**: `npx tsc --noEmit` names exact file + line

## Deviations

1. **ModelRegistry API**: Plan said `await ModelRegistry.create()` — actual API is `new ModelRegistry(authStorage)` (constructor, synchronous)
2. **Other managers**: Plan said `await X.create(...)` for AuthStorage/SettingsManager/SessionManager — all are synchronous
3. **createAgentSession result**: Plan passed result directly to `InteractiveMode.run(session)` but result is `{ session, extensionsResult, ... }` — must destructure `{ session }`
4. **InteractiveMode**: Plan said `InteractiveMode.run(session)` (static) — actual API is `new InteractiveMode(session); mode.run()` (instance)
5. **tsconfig.json**: Added `skipLibCheck: true` to suppress transitive type error from `@google/genai` — not in original plan but required for `tsc --noEmit` to exit 0

## Known Issues

None. All source files compile cleanly.

## Files Created/Modified

- `src/app-paths.ts` — exports appRoot, agentDir, sessionsDir, authFilePath all pointing to ~/.gsd/
- `src/loader.ts` — binary entrypoint: sets PI_PACKAGE_DIR from dist/../ (package root), dynamic-imports cli.js
- `src/cli.ts` — SDK integration: constructs all managers, calls createAgentSession, runs InteractiveMode
- `tsconfig.json` — added skipLibCheck: true to suppress transitive type error in @google/genai

---
estimated_steps: 4
estimated_files: 2
---

# T01: Scaffold package.json and tsconfig

**Slice:** S01 — CLI Scaffold and Branding
**Milestone:** M001

## Description

Create the project foundation: `package.json` (with correct `piConfig`, `bin`, `type`, and dependencies) and `tsconfig.json` (with NodeNext/ESM settings). Install dependencies so `@mariozechner/pi-coding-agent` types are available for T02. Without this, nothing compiles.

## Steps

1. Write `package.json` with:
   - `name: "@lexc/gsd"`, `version: "0.1.0"`, `description: "GSD — Get Stuff Done coding agent"`
   - `type: "module"` (required — pi is ESM-only)
   - `bin: { "gsd": "dist/loader.js" }` (the installed binary entry)
   - `piConfig: { "name": "gsd", "configDir": ".gsd" }` (read by `config.js` when `PI_PACKAGE_DIR` points here — drives `APP_NAME` and `CONFIG_DIR_NAME`)
   - `engines: { "node": ">=20.6.0" }` (pi's minimum)
   - `scripts: { "build": "tsc", "dev": "tsc --watch" }`
   - `dependencies: { "@mariozechner/pi-coding-agent": "^0.57.1" }`
   - `devDependencies: { "@types/node": "^22.0.0", "typescript": "^5.4.0" }`

2. Write `tsconfig.json` with `compilerOptions`:
   - `"module": "NodeNext"` — required for ESM with Node import resolution
   - `"moduleResolution": "NodeNext"` — required pair with NodeNext module
   - `"target": "ES2022"` — Node 20+ supports ES2022
   - `"outDir": "dist"`, `"rootDir": "src"`
   - `"strict": true`, `"declaration": true`, `"esModuleInterop": true`
   - `include: ["src"]`

3. Run `npm install` to fetch deps and create `node_modules/` + `package-lock.json`.

4. Verify `piConfig` is correctly embedded: `node -e "import { createRequire } from 'module'; const r=createRequire(import.meta.url); const p=r('./package.json'); console.log(p.piConfig?.name, p.piConfig?.configDir)"` → must print `gsd .gsd`.

## Must-Haves

- [ ] `package.json` has `"type": "module"` at top level
- [ ] `package.json` has `"piConfig": { "name": "gsd", "configDir": ".gsd" }`
- [ ] `package.json` has `"bin": { "gsd": "dist/loader.js" }`
- [ ] `package.json` has `@mariozechner/pi-coding-agent` as a runtime dependency (not devDep)
- [ ] `tsconfig.json` has `module: "NodeNext"` and `moduleResolution: "NodeNext"`
- [ ] `npm install` exits 0
- [ ] `node_modules/@mariozechner/pi-coding-agent` exists

## Verification

- `cat package.json | node -e "const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); console.assert(d.piConfig?.name==='gsd'); console.assert(d.piConfig?.configDir==='.gsd'); console.assert(d.type==='module'); console.log('package.json OK')"` → prints `package.json OK`
- `ls node_modules/@mariozechner/pi-coding-agent/dist/config.js` → file exists
- `npx tsc --version` → prints version (confirms typescript is installed)

## Observability Impact

- Signals added/changed: None — this task creates static configuration only
- How a future agent inspects this: `cat package.json | jq .piConfig` → shows branding config; `cat tsconfig.json` → shows compile config
- Failure state exposed: `npm install` failure → stderr shows dep resolution errors; wrong `piConfig` values → branding fails silently at runtime (TUI shows "pi" instead of "gsd")

## Inputs

- S01-RESEARCH.md — confirmed `@lexc/gsd` is available on npm, `gsd` name is taken; confirmed `piConfig` structure that `config.js` reads
- D003 — `PI_PACKAGE_DIR` + `piConfig` is the locked branding mechanism

## Expected Output

- `package.json` — complete project manifest with correct branding config, bin entry, and dependencies
- `tsconfig.json` — NodeNext/ESM TypeScript config
- `node_modules/` — installed dependencies including `@mariozechner/pi-coding-agent`
- `package-lock.json` — lockfile

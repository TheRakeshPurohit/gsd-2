# S01: CLI Scaffold and Branding — UAT

**Milestone:** M001
**Written:** 2026-03-10

## UAT Type

- UAT mode: live-runtime
- Why this mode is sufficient: S01's primary deliverable is correct TUI branding — a visual/behavioral outcome that requires actually running the binary in a real TTY. All other checks (build, file existence, piConfig values, state isolation) are shell-verifiable without human involvement. The TUI header check was performed agent-side using `(node dist/loader.js & sleep 2; kill $!) 2>&1 | strings | grep gsd` and confirmed "gsd" appears in TUI output. No human gut-check is required — the output string is machine-readable and unambiguous.

## Preconditions

- `@lexc/gsd` package is installed or available at `/Users/lexchristopherson/Developer/gsd-2`
- `npm run build` has been run successfully (dist/ and pkg/dist/modes/interactive/theme/ populated)
- Node.js ≥ 20.6.0 available
- Terminal with real TTY (interactive shell, not piped)

## Smoke Test

Run `node dist/loader.js` from the package root. Within 2 seconds, the TUI header must show "gsd" (not "pi"). Press Ctrl+C to exit.

## Test Cases

### 1. TUI branding: header shows "gsd"

1. From `/Users/lexchristopherson/Developer/gsd-2`, run `node dist/loader.js`
2. Observe the TUI header at top of screen
3. **Expected:** Header reads "gsd" (or "gsd v0.1.0") — not "pi" or "pi-coding-agent"

### 2. State isolation: ~/.gsd/ created, ~/.pi/ untouched

1. Check `ls ~/.pi/agent/sessions/ | wc -l` — note the count (baseline)
2. Run `node dist/loader.js`, wait 2 seconds, press Ctrl+C
3. Run `ls ~/.gsd/` — check for `agent/` and `sessions/` directories
4. Run `ls ~/.pi/agent/sessions/ | wc -l` — check count
5. **Expected:** `~/.gsd/agent/` and `~/.gsd/sessions/` exist; `~/.pi/agent/sessions/` count is unchanged from baseline

### 3. piConfig branding config is correct

1. From the package root, run:
   ```bash
   node --input-type=module -e "
     import { createRequire } from 'module';
     const r = createRequire(import.meta.url);
     const p = r('./package.json');
     console.log(p.piConfig?.name, p.piConfig?.configDir);
   "
   ```
2. **Expected:** Prints `gsd .gsd`

### 4. Binary build is clean

1. Run `npm run build`
2. **Expected:** Exits 0 with no TypeScript errors; `dist/loader.js`, `dist/cli.js`, `dist/app-paths.js` all exist; `pkg/dist/modes/interactive/theme/dark.json` and `light.json` exist

### 5. Process title is "gsd"

1. Run `node dist/loader.js &` in background
2. Run `ps aux | grep gsd | grep -v grep`
3. Press Ctrl+C or `kill %1` to exit
4. **Expected:** Process appears as "gsd" in the process list (not "node")

## Edge Cases

### Cold start: no ~/.gsd/ directory exists

1. Remove `~/.gsd/` if it exists: `rm -rf ~/.gsd/`
2. Run `node dist/loader.js`, wait 2 seconds, press Ctrl+C
3. **Expected:** Binary starts without error; `~/.gsd/agent/` and `~/.gsd/sessions/` are created automatically; no crash or warning about missing directories

### Theme assets missing (copy-themes not run)

1. Delete `pkg/dist/modes/interactive/theme/dark.json`
2. Run `node dist/loader.js`
3. **Expected:** Binary fails with a clear `ENOENT` error referencing the dark.json path — not a silent hang or cryptic error
4. Restore: run `npm run copy-themes`

## Failure Signals

- TUI header shows "pi" instead of "gsd" → PI_PACKAGE_DIR not set correctly; check `grep PI_PACKAGE_DIR dist/loader.js` and confirm it points to `pkg/`
- `ENOENT: no such file or directory, open .../dark.json` → `copy-themes` not run or failed; run `npm run build` again
- `~/.pi/agent/sessions/` count increases after gsd launch → state isolation broken; check `agentDir` and `sessionsDir` in `src/app-paths.ts`
- TypeScript errors on build → run `npx tsc --noEmit` to see exact file and line
- Binary exits immediately without showing TUI → likely non-TTY context; run in a real interactive terminal

## Requirements Proved By This UAT

- R002 — Branded identity: TUI header shows "gsd"; piConfig.name=gsd, piConfig.configDir=.gsd; state in `~/.gsd/`. All R002 criteria directly observable and verified.
- R007 — Isolated state in ~/.gsd/: state written to `~/.gsd/`, `~/.pi/` session count unchanged. Mechanically enforced by app-paths.ts constants and verified at runtime.

## Not Proven By This UAT

- R001 — Single-command install (`npm install -g gsd-pi`): binary works locally but npm publish and global install from registry is S04's scope
- R003 — Bundled GSD extension (`/gsd` command): no extensions loaded yet — S02's scope
- R004 — Bundled supporting extensions (browser-tools, search-the-web, etc.): not bundled yet — S02's scope
- R005 — Bundled agents and AGENTS.md: not bundled yet — S02's scope
- R006 — First-run setup wizard: no wizard implemented — S03's scope
- R008 — npm update workflow: not tested — S04's scope
- R009 — Observable failure state for missing keys: wizard not implemented — S03's scope

## Notes for Tester

- The binary requires a real interactive TTY. Running `node dist/loader.js` in a piped context (e.g. `node dist/loader.js | cat`) will exit immediately — this is expected behavior from pi's InteractiveMode.
- The `pkg/` directory is committed to the repo but `pkg/dist/modes/interactive/theme/` files are generated at build time (not committed). Always run `npm run build` before testing to ensure theme assets are present.
- State directories (`~/.gsd/agent/`, `~/.gsd/sessions/`) are created by pi's managers on first use — they will not exist until the binary is run at least once.
- No API key is needed to verify TUI branding — the header renders before any model interaction occurs. The TUI may show an error about missing API keys after loading, which is expected and is S03's responsibility to handle.

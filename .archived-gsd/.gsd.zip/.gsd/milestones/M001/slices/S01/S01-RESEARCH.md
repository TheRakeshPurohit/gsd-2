# S01: CLI Scaffold and Branding — Research

**Date:** 2026-03-10

## Summary

S01 owns R001 (single-command install) and R002 (branded identity). The work is: create `package.json`, `src/loader.ts`, `src/cli.ts`, and `src/app-paths.ts`, compile them with `tsc`, confirm `gsd` binary launches with `APP_NAME = "gsd"` in the TUI header and state under `~/.gsd/`.

The architecture is straightforward SDK embedding. The one real risk is ESM module evaluation order: `config.js` computes `APP_NAME` at **module eval time** (`const APP_NAME = pkg.piConfig?.name || "pi"` — a top-level const). Static `import` statements in ESM are hoisted and evaluated before any code in the importing file runs, so setting `process.env.PI_PACKAGE_DIR` before a static import of `@mariozechner/pi-coding-agent` **does not work**. The fix is a two-file loader pattern: `src/loader.ts` sets the env var and then does a **dynamic `import()`** of `./cli.js`. Dynamic imports are deferred — the env var is visible to all modules that evaluate as part of that import chain. This pattern was tested and confirmed working (see Proof section).

The npm package name `gsd` is taken (a 2017 todo-list CLI). The scoped name `@lexc/gsd` is available. The binary name in `package.json#bin` is still `gsd`, so users run `gsd` regardless.

## Recommendation

**Two-file loader pattern with `tsc` (NodeNext/ESM):**

1. `src/loader.ts` — the bin entry. Sets `PI_PACKAGE_DIR` to the package root, then `await import('./cli.js')`. Compiled to `dist/loader.js`. This is what `package.json#bin.gsd` points to.
2. `src/cli.ts` — the real app. Static imports of `@mariozechner/pi-coding-agent` are fine here because this file is never loaded until after `PI_PACKAGE_DIR` is set. Creates managers, resource loader, session; runs `InteractiveMode`.
3. `src/app-paths.ts` — constants: `appRoot`, `agentDir`, `sessionsDir`, `authFilePath` — computed from `os.homedir()`.

Build: `tsc` with `module: "NodeNext"`, `moduleResolution: "NodeNext"`, `target: "ES2022"`. No tsup needed for S01 — `tsc` is already globally installed and this is a simple ESM package. Add `@types/node` as a dev dep.

Use `@lexc/gsd` as the npm package name. The `bin` key is `{ "gsd": "dist/loader.js" }`.

## Don't Hand-Roll

| Problem | Existing Solution | Why Use It |
|---------|------------------|------------|
| Branding (APP_NAME, CONFIG_DIR_NAME, agentDir path) | `PI_PACKAGE_DIR` env var + `piConfig` in `package.json` | `config.js` reads `piConfig.name`/`configDir` from the package.json it finds at `PI_PACKAGE_DIR`. Zero patching required. |
| Auth directory creation | `AuthStorage.create(path)` | Calls `mkdirSync(dir, { recursive: true })` automatically. No need to pre-create `~/.gsd/agent/`. |
| Session directory creation | `SessionManager.create(cwd, sessionsDir)` | Creates dir on first use. |
| Missing agentDir/extensions/ | `DefaultResourceLoader` | `package-manager.js` checks `existsSync` before reading any directory — missing dirs are silently skipped. |
| TUI header rendering | `InteractiveMode` | Uses `APP_NAME` (read from config.js) for the header logo. Once PI_PACKAGE_DIR is correct, the header says "gsd" automatically. |

## Existing Code and Patterns

- `/Users/lexchristopherson/.nvm/versions/node/v22.20.0/lib/node_modules/@mariozechner/pi-coding-agent/dist/config.js` — Defines `getPackageDir()`, `APP_NAME`, `CONFIG_DIR_NAME`, `getAgentDir()`. **Must be the first pi module to see `PI_PACKAGE_DIR`**. Walk-up algorithm: checks `PI_PACKAGE_DIR` env first, then walks up from `__dirname` until `package.json` found.
- `/Users/lexchristopherson/.nvm/versions/node/v22.20.0/lib/node_modules/@mariozechner/pi-coding-agent/dist/modes/interactive/interactive-mode.js` — `InteractiveMode` class. Header renders `APP_NAME` at line 242. Gets `settingsManager` and `resourceLoader` from the session — no separate injection needed.
- SDK skeleton in docs (`19-building-branded-apps-on-top-of-pi.md` §19.19) — canonical shape for `cli.ts`: auth, model registry, settings, sessions, resource loader, `createAgentSession`, `InteractiveMode.run()`.
- `@mariozechner/pi-coding-agent` SDK exports: `AuthStorage`, `ModelRegistry`, `SettingsManager`, `SessionManager`, `DefaultResourceLoader`, `createAgentSession`, `InteractiveMode`, `getAgentDir`.

## Constraints

- **ESM-only**: `pi-coding-agent` is `"type": "module"`. gsd must also be `"type": "module"`. CJS is not an option.
- **Node ≥ 20.6.0**: pi's `engines` requirement. Dev environment is 22.20.0 ✓.
- **`tsc` with `NodeNext`**: `.ts` files importing `./foo.ts` must use `./foo.js` in import statements (NodeNext convention). This affects all files in `src/`.
- **`PI_PACKAGE_DIR` timing**: Must be set before any dynamic import of pi fires. Loader pattern is required — cannot set it alongside static imports.
- **`gsd` npm name taken**: Package must be published as `@lexc/gsd`. Binary name is still `gsd` via `bin` key.
- **`package.json` must be in the installed package root**: `getPackageDir()` walks up from `dist/loader.js`'s `__dirname`. For an npm global install: `…/node_modules/@lexc/gsd/dist/` → `…/node_modules/@lexc/gsd/`. `package.json` lives there ✓. Setting `PI_PACKAGE_DIR = dirname(__dirname)` from `loader.ts` achieves this.

## Common Pitfalls

- **Setting `PI_PACKAGE_DIR` inline with static imports** — In ESM, `process.env.PI_PACKAGE_DIR = x` placed before a static `import` statement will not run first. Static imports are hoisted. Use the two-file loader + dynamic import pattern exclusively.
- **Wrong `PI_PACKAGE_DIR` value** — Must point to the package root (where `package.json` lives), not `dist/`. Loader computes: `dirname(dirname(fileURLToPath(import.meta.url)))`.
- **Forgetting `"type": "module"` in `package.json`** — Without it, `.js` files are treated as CJS and `import.meta.url` / top-level `await` fail.
- **Using `__dirname` directly in `src/loader.ts`** — `__dirname` is not defined in ESM. Must use `dirname(fileURLToPath(import.meta.url))` instead.
- **Importing from `./foo.ts` in TypeScript** — NodeNext requires `.js` extension in import paths (the compiled output extension), even in `.ts` source files. Use `import { x } from './app-paths.js'`.
- **`sessionsDir` pointing to `~/.gsd/agent/sessions/`** — Per the SDK docs, sessions live at `~/.gsd/sessions/` (separate from `agentDir`). Pass explicit `SessionManager.create(cwd, sessionsDir)` to avoid pi's default of `~/.pi/agent/sessions/`.
- **Depending on `getAgentDir()` returning `~/.gsd/agent`** — It will, once `PI_PACKAGE_DIR` is set and `piConfig.configDir = ".gsd"`. But relying on it implicitly is fragile. Pass `agentDir` explicitly to `createAgentSession()` and `DefaultResourceLoader`.
- **`noExtensions: true` not needed for S01** — `DefaultResourceLoader` handles missing `~/.gsd/agent/extensions/` gracefully (existsSync check). Skip the flag; it would break extension loading in later slices.

## Open Risks

- **Terminal title still shows `π`** — `InteractiveMode.updateTerminalTitle()` hardcodes `π` (Unicode pi symbol), not `APP_NAME`. This is cosmetic — TUI header (the visible part) uses `APP_NAME` correctly. The terminal tab title will say `π - cwd` instead of `gsd - cwd`. Acceptable for S01, possible post-MVP fix if it bothers users.
- **HTTP proxy support gap** — Pi's `dist/cli.js` sets `setGlobalDispatcher(new EnvHttpProxyAgent())` from `undici`. The gsd `cli.ts` using the SDK directly does not inherit this. Users behind corporate HTTP proxies may see connection failures. Low probability for typical devs; can be added in S04 if needed.
- **`process.title`** — Pi sets `process.title = "pi"`. Set `process.title = "gsd"` in `loader.ts` to match. Low risk if forgotten, cosmetic only.

## Proof: Two-File Loader Pattern Works

Verified in `/tmp/tsup-test/` with `tsc + NodeNext`:

```
loader.ts  →  dist/loader.js  →  sets process.env.MY_VAR  →  await import('./cli.js')
cli.ts     →  dist/cli.js     →  import { MY_VAR } from './env-consumer.js'
env-consumer.ts → dist/env-consumer.js → export const MY_VAR = process.env.MY_VAR
```

Result: `CLI sees MY_VAR: set_by_loader` ✓

Same pattern with actual pi config.js simulation: `APP_NAME evaluated as: gsd` ✓

## File Layout for S01

```
gsd-2/
  package.json          ← { name: "@lexc/gsd", bin: { gsd: "dist/loader.js" },
                             type: "module", piConfig: { name: "gsd", configDir: ".gsd" } }
  tsconfig.json         ← module: NodeNext, moduleResolution: NodeNext, target: ES2022
  src/
    loader.ts           ← sets PI_PACKAGE_DIR + process.title, await import('./cli.js')
    cli.ts              ← managers + createAgentSession + InteractiveMode.run()
    app-paths.ts        ← appRoot, agentDir, sessionsDir, authFilePath constants
  dist/                 ← tsc output (gitignored)
```

## Skills Discovered

| Technology | Skill | Status |
|------------|-------|--------|
| TypeScript / Node.js | — | none found / not needed |
| npm publish | — | none found / not needed |

## Sources

- ESM import hoisting (static vs dynamic): confirmed by local test in `/tmp/tsup-test/` — dynamic import sees env vars set before it, static imports do not
- `APP_NAME` eval timing: `config.js` line 139–141 — top-level `const` evaluated at module load (source: `/Users/lexchristopherson/.nvm/versions/node/v22.20.0/lib/node_modules/@mariozechner/pi-coding-agent/dist/config.js`)
- Branding via `PI_PACKAGE_DIR`: `getPackageDir()` checks env var first, then walks up to find `package.json` (source: `config.js`)
- SDK skeleton and branded app architecture: §19.6, §19.7, §19.18, §19.19 (source: `/Users/lexchristopherson/.pi/docs/what-is-pi/19-building-branded-apps-on-top-of-pi.md`)
- `InteractiveMode` header uses `APP_NAME`: line 242 (source: `dist/modes/interactive/interactive-mode.js`)
- `AuthStorage.create()` auto-creates dirs: `FileAuthStorageBackend` calls `mkdirSync` (source: `dist/core/auth-storage.js`)
- `DefaultResourceLoader` handles missing dirs: `existsSync` guards throughout `package-manager.js`
- npm name `gsd` is taken: `npm view gsd` → version 0.0.3, "Respecting the art of getting stuff done"
- `@lexc/gsd` is available: `npm view @lexc/gsd` → 404 not found
- pi version in use: 0.57.1 (source: `package.json`)

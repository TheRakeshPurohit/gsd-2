# S03: First-run setup wizard

**Goal:** On first launch with optional tool API keys (Brave, Context7, Jina) not configured, `gsd` detects missing keys, runs an interactive wizard that collects them with masked input, and persists them to `~/.gsd/agent/auth.json`. Anthropic auth is handled by pi's own OAuth/API key flow — the wizard does not touch it. On subsequent launches, if all keys are present, the wizard is skipped entirely. Non-TTY contexts get a warning (non-fatal) when optional keys are missing.
**Demo:** Clear optional keys from `~/.gsd/agent/auth.json`, run `node dist/loader.js` in a real terminal — wizard fires for missing optional keys, stores them, then launches TUI. Run again — wizard is skipped.

**Scope change from original:** Anthropic key handling removed — pi OAuth covers it. Wizard is optional-keys-only (Brave, Context7, Jina). Non-TTY missing optional keys is a warning + continue, not exit 1.

## Must-Haves

- `src/wizard.ts` exports `runWizardIfNeeded(authStorage)` — checks for missing optional keys and runs the wizard
- `src/cli.ts` calls `loadStoredEnvKeys(authStorage)` and `runWizardIfNeeded(authStorage)` before `createAgentSession()`
- Optional keys (Brave, Context7, Jina) are stored when provided; empty input = skip
- All input is masked (`*` per character) using raw mode stdin
- Non-TTY: emits a warning to stderr listing missing optional keys and continues (non-fatal)
- `loadStoredEnvKeys` sets `BRAVE_API_KEY`, `CONTEXT7_API_KEY`, `JINA_API_KEY` from auth.json into `process.env` on every launch
- Stored keys are hydrated before `createAgentSession()` so extensions see them at load time
- Subsequent launch: all keys present → wizard does not fire

## Proof Level

- This slice proves: integration
- Real runtime required: yes — wizard must actually fire, accept keystrokes, store keys, and launch TUI
- Human/UAT required: yes — masked input and TUI launch are visual/interactive; automated test covers detection and skip logic

## Verification

```bash
# 1. TypeScript compiles clean
npm run build && echo "BUILD OK"

# 2. Wizard skip: Anthropic key already in env → wizard does not fire
ANTHROPIC_API_KEY=sk-ant-test node dist/loader.js 2>&1 &
PID=$!; sleep 2; kill $PID 2>/dev/null
# Verify: no "Welcome to GSD Setup" text in output

# 3. Non-TTY missing key: actionable error to stderr, exit 1
ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1 | grep -q "ANTHROPIC_API_KEY" && echo "NON-TTY ERROR OK"

# 4. Non-TTY exit code is 1 when Anthropic key missing
ANTHROPIC_API_KEY= node dist/loader.js < /dev/null; echo "exit: $?"

# 5. loadStoredEnvKeys hydration: store a brave key, verify env is set before session
# (structural — confirmed via grep in compiled output + runtime test in T02)

# 6. Full interactive wizard flow verified manually (UAT): delete ~/.gsd/, run gsd,
#    enter keys at prompts, confirm TUI starts, rerun and confirm wizard skips
```

## Observability / Diagnostics

- Runtime signals: wizard prints `[gsd] No API keys configured.` before prompting; `[gsd] Keys saved.` after storage; non-TTY prints structured error to stderr
- Inspection surfaces: `cat ~/.gsd/agent/auth.json` — shows stored keys (masked display); `node dist/loader.js 2>&1` — stderr shows key errors
- Failure state exposed: non-TTY error names specific missing key, env var name, auth.json path, and expected JSON format — a future agent can localize exactly what to set
- Redaction constraints: wizard never logs raw key values — only confirmation messages; auth.json is 0o600 (enforced by authStorage)

## Integration Closure

- Upstream surfaces consumed: `src/app-paths.ts` (authFilePath), `src/cli.ts` (authStorage instance, pre-session insertion point), `dist/core/auth-storage.js` (`hasAuth()`, `has()`, `set()`, `get()`)
- New wiring introduced in this slice: `src/wizard.ts` (new file); two calls added to `cli.ts` (`loadStoredEnvKeys` + `runWizardIfNeeded`) between `AuthStorage.create()` and `createAgentSession()`
- What remains before the milestone is truly usable end-to-end: S04 — npm pack + install smoke test and registry publish

## Tasks

- [x] **T01: Implement wizard.ts and wire into cli.ts** `est:45m`
  - Why: Core slice deliverable — all wizard logic lives here; cli.ts wiring makes it fire at the right moment
  - Files: `src/wizard.ts` (new), `src/cli.ts`
  - Do: Write `src/wizard.ts` with: `loadStoredEnvKeys(authStorage)` function, `runWizardIfNeeded(authStorage)` function, `promptMasked(question)` helper using `process.stdin.setRawMode`. Detection order: check `authStorage.hasAuth("anthropic")` (uses env + auth.json + OAuth), check `authStorage.has("brave") || process.env.BRAVE_API_KEY`, same for context7 and jina. Non-TTY path: if Anthropic missing and `!process.stdin.isTTY`, write structured error to stderr and exit 1; if only optional keys missing and not TTY, warn and return. TTY path: print welcome banner, prompt for Anthropic (re-prompt on empty), store via `authStorage.set("anthropic", {type:"api_key", key})`, then prompt for each optional key (skip on empty, store via `authStorage.set(provider, {type:"api_key", key})`). Print `[gsd] Keys saved.` after storage. In `promptMasked`: use `setRawMode(true)`, handle backspace (`\u007f`), Ctrl+C (`\u0003`), enter (`\r`/`\n`), `setRawMode(false)` + `pause()` after resolve. In `cli.ts`: import `loadStoredEnvKeys` and `runWizardIfNeeded` from `./wizard.js`; call `loadStoredEnvKeys(authStorage)` immediately after `AuthStorage.create()`; call `await runWizardIfNeeded(authStorage)` before `initResources()`
  - Verify: `npm run build` exits 0; `ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1 | grep "ANTHROPIC_API_KEY"` outputs the actionable error line; `ANTHROPIC_API_KEY=sk-ant-test node dist/loader.js 2>&1 & PID=$!; sleep 2; kill $PID` produces no "Welcome to GSD Setup" text
  - Done when: `npm run build` exits 0; non-TTY missing key test outputs actionable error; non-TTY exit code is 1; wizard skip confirmed when key is in env

- [x] **T02: End-to-end integration test and UAT verification** `est:30m`
  - Why: R006 and R009 require verified runtime behavior — the wizard must actually fire, store keys, and be skipped on rerun; non-TTY error format must be confirmed
  - Files: `scripts/verify-s03.sh` (new)
  - Do: Write `scripts/verify-s03.sh` that runs all automated checks in sequence with clear pass/fail output: (1) confirm build is current; (2) non-TTY missing Anthropic key → exit 1 + stderr contains "ANTHROPIC_API_KEY"; (3) non-TTY with key set via env var → no wizard, process starts; (4) non-TTY with only optional keys missing (Anthropic set) → process starts, no exit 1; (5) confirm `loadStoredEnvKeys` hydration: write a test auth.json with a brave key, run loader with no `BRAVE_API_KEY` env var, check that process doesn't crash on load (structural proof — brave key would be in env for extensions); Make the script executable. Also confirm with a real interactive test (UAT): delete `~/.gsd/`, run `node dist/loader.js` in a real terminal, type a test API key at each prompt, verify TUI launches, exit, rerun and confirm wizard does not fire (wizard skip is the critical check)
  - Verify: `bash scripts/verify-s03.sh` exits 0 with all checks passing; interactive UAT passes (wizard fires → keys stored → TUI starts → rerun skips wizard)
  - Done when: `bash scripts/verify-s03.sh` exits 0; R006 and R009 are confirmed satisfied in verification output

## Files Likely Touched

- `src/wizard.ts` — new file, all wizard logic
- `src/cli.ts` — two calls added pre-session
- `scripts/verify-s03.sh` — new verification script

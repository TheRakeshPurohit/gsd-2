---
id: T01
parent: S03
milestone: M001
provides:
  - src/wizard.ts with loadStoredEnvKeys and runWizardIfNeeded exports
  - wizard wired into cli.ts before createAgentSession
key_files:
  - src/wizard.ts
  - src/cli.ts
key_decisions:
  - promptMasked wraps setRawMode in try/catch and falls back to plain readline on error — handles SSH edge cases without crashing
  - loadStoredEnvKeys runs before runWizardIfNeeded so stored keys are in process.env before the wizard checks them, preventing false-positive wizard fires
  - Optional keys (Brave/Context7/Jina) are also set into process.env during the wizard's interactive path so extensions see them immediately without waiting for the next launch
  - authStorage.set() is synchronous and writes with file lock — no reload needed after wizard stores keys
patterns_established:
  - Pre-session auth gate: loadStoredEnvKeys → runWizardIfNeeded → initResources → createAgentSession
  - Non-TTY detection pattern using process.stdin.isTTY before any interactive prompt
  - Required-key loop pattern: re-prompt on empty, never store empty Anthropic key
  - Optional-key skip pattern: empty input = skip, non-empty = store and set process.env
observability_surfaces:
  - stderr: "[gsd] ANTHROPIC_API_KEY is required but not configured." with option 1/2 remediation paths and exact auth.json path
  - stderr: "[gsd] Warning: optional API keys not configured (Brave, Context7, Jina). Some tools may not work."
  - stdout: "[gsd] Welcome! Let's set up your API keys." (wizard entry signal)
  - stdout: "[gsd] Keys saved. Starting..." (wizard completion signal)
  - "cat ~/.gsd/agent/auth.json" shows which providers are stored
  - "ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1" surfaces actionable error with key name + path
duration: ~25m
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T01: Implement wizard.ts and wire into cli.ts

**Wrote `src/wizard.ts` with masked-input wizard logic and wired `loadStoredEnvKeys` + `runWizardIfNeeded` into `cli.ts` before `createAgentSession()`.**

## What Happened

Created `src/wizard.ts` with three units:

- `promptMasked(question)` — internal async helper using `process.stdin.setRawMode(true)` for character-by-character masked input. Handles backspace (`\u007f` — redraw line), Ctrl+C (`\u0003` — restore raw mode + exit 0), and Enter (`\r`/`\n` — resolve). Wrapped in try/catch: if `setRawMode` throws (SSH edge case), falls back to plain `readline.question()` with a visibility warning.
- `loadStoredEnvKeys(authStorage)` — exported; iterates `[brave/BRAVE_API_KEY, context7/CONTEXT7_API_KEY, jina/JINA_API_KEY]`; if env var is absent and auth.json has an `api_key` credential for that provider, sets `process.env[envVar] = cred.key`.
- `runWizardIfNeeded(authStorage)` — exported; detects missing keys using `authStorage.hasAuth("anthropic")` for Anthropic (checks env + auth.json + OAuth) and `authStorage.has(provider) || process.env[envVar]` for optional providers. Returns immediately when all keys are present. Non-TTY missing Anthropic: structured error to stderr with key name, env var, auth.json path + format, then `process.exit(1)`. Non-TTY optional-only missing: warning to stderr, continue. TTY: welcome banner → Anthropic loop (re-prompts on empty, never stores empty) → Brave/Context7/Jina optional prompts (skip on empty) → "Keys saved." confirmation. Also sets process.env for optional keys immediately after storing them so extensions see them without waiting for next launch.

Modified `src/cli.ts`: added import for both exports; inserted `loadStoredEnvKeys(authStorage)` immediately after `AuthStorage.create()` and `await runWizardIfNeeded(authStorage)` before `initResources(agentDir)`. ModelRegistry/SettingsManager/SessionManager instantiation moved after the wizard so they see the fully-hydrated authStorage.

## Verification

```bash
# Build
npm run build && echo "BUILD OK"
# → BUILD OK (no TypeScript errors)

# Non-TTY missing Anthropic key → actionable error + exit 1
ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1
# Output:
#   [gsd] ANTHROPIC_API_KEY is required but not configured.
#     Option 1: Set env var: export ANTHROPIC_API_KEY=sk-ant-...
#     Option 2: Add to auth.json: /Users/lexchristopherson/.gsd/agent/auth.json
#               Format: {"anthropic": {"type": "api_key", "key": "sk-ant-..."}}
# Exit code: 1 ✓

# Non-TTY optional keys missing only → warning + exit 0 (TUI launches)
ANTHROPIC_API_KEY=sk-ant-test BRAVE_API_KEY= CONTEXT7_API_KEY= JINA_API_KEY= node dist/loader.js < /dev/null 2>&1 | grep -q "Warning" && echo "WARNING OK"
# → WARNING OK ✓

# Wizard skip when key in env
ANTHROPIC_API_KEY=sk-ant-test node dist/loader.js 2>&1 & PID=$!; sleep 2; kill $PID
# → No "Welcome" in output ✓
```

All task-level verification checks passed. Slice-level checks 1–4 pass. Check 5 (structural hydration) is partially verified — `loadStoredEnvKeys` is in compiled output and the env-setting logic is correct; full runtime hydration test is covered in T02. Check 6 (interactive UAT) is T02 scope.

## Diagnostics

- `ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1` — produces full actionable error with remediation options and exact auth.json path
- `cat ~/.gsd/agent/auth.json` — shows which providers have stored credentials
- `grep -r "loadStoredEnvKeys\|runWizardIfNeeded" dist/` — confirms wiring in compiled output
- Wizard fires once; subsequent launches: `authStorage.hasAuth("anthropic")` returns true → immediate return with no output

## Deviations

- Plan said to move ModelRegistry/SettingsManager/SessionManager calls to after the wizard — done. Plan diagram showed them after `AuthStorage.create()` but before wizard, which would have been fine too since they don't read env vars at construction time. Placing them after wizard is cleaner and avoids any future ordering surprises.

## Known Issues

None.

## Files Created/Modified

- `src/wizard.ts` — new file; all wizard logic; exports `loadStoredEnvKeys` and `runWizardIfNeeded`
- `src/cli.ts` — added import + two pre-session calls; ModelRegistry/SettingsManager/SessionManager moved after wizard
- `dist/wizard.js` — compiled output (generated by `npm run build`)
- `dist/cli.js` — compiled output (generated by `npm run build`)

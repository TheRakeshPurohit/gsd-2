---
estimated_steps: 6
estimated_files: 2
---

# T01: Implement wizard.ts and wire into cli.ts

**Slice:** S03 — First-run setup wizard
**Milestone:** M001

## Description

Write `src/wizard.ts` with all wizard logic: the `loadStoredEnvKeys` startup loader (runs every launch), the `runWizardIfNeeded` main function (detects missing keys and runs the interactive or non-TTY error path), and the `promptMasked` helper for masked character-by-character input. Wire both functions into `cli.ts` before `createAgentSession()`.

This task delivers the complete runtime behavior. After it, the wizard fires on fresh install, skips when keys exist, and emits actionable errors in non-TTY mode.

## Steps

1. **Write `src/wizard.ts`** with three exported/internal units:

   **`promptMasked(question: string): Promise<string>`** — internal helper:
   - `process.stdout.write(question)`
   - `process.stdin.setRawMode(true)` + `process.stdin.resume()` + `process.stdin.setEncoding("utf8")`
   - Accumulate chars; on `*` write `"*"`, on `\u007f` (backspace) slice value and redraw (`clearLine`, `cursorTo(0)`, rewrite question + stars), on `\u0003` (Ctrl+C) `setRawMode(false)`, `process.stdout.write("\n")`, `process.exit(0)`, on `\r`/`\n` `setRawMode(false)`, `pause()`, off handler, `process.stdout.write("\n")`, resolve
   - Wrap in try/catch: if `setRawMode` throws, fall back to plain `readline.question()` with a note that input will be visible

   **`loadStoredEnvKeys(authStorage: AuthStorage): void`** — exported:
   - For each `[provider, envVar]` of `[["brave","BRAVE_API_KEY"], ["context7","CONTEXT7_API_KEY"], ["jina","JINA_API_KEY"]]`:
     - If `!process.env[envVar]`, call `authStorage.get(provider)` — if cred exists and `cred.type === "api_key"`, set `process.env[envVar] = cred.key`

   **`runWizardIfNeeded(authStorage: AuthStorage): Promise<void>`** — exported:
   - Detect: `needsAnthropicKey = !authStorage.hasAuth("anthropic")`; `needsBraveKey = !authStorage.has("brave") && !process.env.BRAVE_API_KEY`; same for context7 and jina
   - If `!needsAnthropicKey && !needsBraveKey && !needsContext7Key && !needsJinaKey`: return immediately (common case — no wizard)
   - Non-TTY Anthropic missing: write structured error to stderr naming the key, env var, and auth.json path (from `authFilePath` import); `process.exit(1)`
   - Non-TTY optional keys missing only: `process.stderr.write("[gsd] Warning: optional API keys not configured (Brave, Context7, Jina). Some tools may not work.\n")`; return
   - TTY path: print welcome banner (`"\n[gsd] Welcome! Let's set up your API keys.\n"`)
   - Anthropic key prompt (required — loop until non-empty): `const key = await promptMasked("Anthropic API key (required): ")` — if empty, print re-prompt message and loop; on value: `await authStorage.set("anthropic", { type: "api_key", key })`
   - For each optional key (Brave, Context7, Jina): `const key = await promptMasked("Brave Search API key (optional, press Enter to skip): ")` — if non-empty: `await authStorage.set(provider, { type: "api_key", key })`
   - After all prompts: `process.stdout.write("[gsd] Keys saved. Starting...\n\n")`

2. **Import `authFilePath` from `./app-paths.js`** in `wizard.ts` for use in the non-TTY error message path.

3. **Import `AuthStorage` type from `@mariozechner/pi-coding-agent`** in `wizard.ts` — type-only import to avoid circular instantiation.

4. **Wire `wizard.ts` into `cli.ts`**:
   - Add import: `import { loadStoredEnvKeys, runWizardIfNeeded } from './wizard.js'`
   - After `const authStorage = AuthStorage.create(authFilePath)`: call `loadStoredEnvKeys(authStorage)`
   - After `loadStoredEnvKeys` and before `initResources(agentDir)`: call `await runWizardIfNeeded(authStorage)`

5. **Compile**: `npm run build` — fix any TypeScript errors.

6. **Verify non-TTY paths**:
   - `ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1` → output contains "ANTHROPIC_API_KEY" and "auth.json"; process exits with code 1
   - `ANTHROPIC_API_KEY=sk-ant-test node dist/loader.js < /dev/null 2>&1` (with Brave/Context7/Jina unset) → output contains "Warning: optional API keys" but process does NOT exit 1
   - `ANTHROPIC_API_KEY=sk-ant-test node dist/loader.js 2>&1 & PID=$!; sleep 2; kill $PID 2>/dev/null` → no "Welcome to GSD Setup" in output (wizard skipped)

## Must-Haves

- [ ] `src/wizard.ts` exists and exports `loadStoredEnvKeys` and `runWizardIfNeeded`
- [ ] `promptMasked` handles backspace, Ctrl+C, and enter correctly; falls back to readline on `setRawMode` error
- [ ] `loadStoredEnvKeys` sets `BRAVE_API_KEY`, `CONTEXT7_API_KEY`, `JINA_API_KEY` from auth.json when env vars are absent
- [ ] `runWizardIfNeeded` returns immediately when all keys are present (no prompt, no output)
- [ ] Non-TTY + missing Anthropic key: stderr contains actionable error with key name, env var, auth.json path; exit code is 1
- [ ] Non-TTY + only optional keys missing: warning to stderr, process continues (exit 0 path)
- [ ] Anthropic key prompt loops on empty input — empty key is never stored
- [ ] Optional keys skip on empty input — empty is not stored
- [ ] `cli.ts` calls `loadStoredEnvKeys` before `initResources` and `runWizardIfNeeded` before `createAgentSession`
- [ ] `npm run build` exits 0 with no type errors

## Verification

```bash
# Build clean
npm run build && echo "BUILD OK"

# Non-TTY missing Anthropic key → actionable error + exit 1
output=$(ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1); \
  echo "$output" | grep -q "ANTHROPIC_API_KEY" && echo "ERROR TEXT OK" || echo "FAIL: no key name in error"; \
  echo exit:$?

ANTHROPIC_API_KEY= node dist/loader.js < /dev/null; echo "Exit code: $?"
# Expect: Exit code: 1

# Non-TTY only optional keys missing → warning, not exit 1
ANTHROPIC_API_KEY=sk-ant-test BRAVE_API_KEY= CONTEXT7_API_KEY= node dist/loader.js < /dev/null 2>&1 | grep -q "Warning" && echo "WARNING OK"
ANTHROPIC_API_KEY=sk-ant-test BRAVE_API_KEY= CONTEXT7_API_KEY= node dist/loader.js < /dev/null; echo "Exit code: $?"
# Expect: Exit code: 0 (process starts normally)

# Wizard skip when key in env
(ANTHROPIC_API_KEY=sk-ant-test node dist/loader.js 2>&1 & PID=$!; sleep 2; kill $PID 2>/dev/null; wait $PID 2>/dev/null) | grep -v "Welcome to GSD Setup" | head -5
```

## Observability Impact

- Signals added/changed: `[gsd] Keys saved. Starting...` printed to stdout after wizard completes; `[gsd] Warning: optional API keys not configured` printed to stderr in non-TTY optional-missing case; full structured error on stderr for non-TTY Anthropic-missing case
- How a future agent inspects this: `cat ~/.gsd/agent/auth.json` shows which providers have stored credentials; stderr output from non-TTY run names exactly which key is missing and how to fix it
- Failure state exposed: non-TTY error message includes env var name (`ANTHROPIC_API_KEY`), auth.json path, and expected JSON format — a future agent can localize and fix without guessing

## Inputs

- `src/app-paths.ts` — `authFilePath` for the non-TTY error message
- `src/cli.ts` — current wiring; `authStorage` is the injection point; insertion location is between `AuthStorage.create()` and `initResources()` + `createAgentSession()`
- `~/.nvm/.../dist/core/auth-storage.js` — `hasAuth()`, `has()`, `set()`, `get()` API shapes (from S03 research)
- S03 research — `promptMasked` implementation, detection logic, auth.json format, all pitfalls

## Expected Output

- `src/wizard.ts` — new file; all wizard logic; exports `loadStoredEnvKeys` and `runWizardIfNeeded`
- `src/cli.ts` — modified; two calls inserted pre-session
- `dist/wizard.js` — compiled output (after `npm run build`)
- Non-TTY verification commands all pass as described

---
estimated_steps: 4
estimated_files: 2
---

# T02: End-to-end verification and UAT

**Slice:** S03 — First-run setup wizard
**Milestone:** M001

## Description

Write `scripts/verify-s03.sh` that runs all automated checks for S03 with explicit pass/fail output — covering non-TTY error path, wizard-skip detection, and loadStoredEnvKeys hydration. Then run an interactive UAT in a real terminal to confirm the wizard fires, masked input works, keys are stored, TUI launches, and the subsequent launch skips the wizard.

This task closes the slice: R006 and R009 verified by shell script + interactive confirmation.

## Steps

1. **Write `scripts/verify-s03.sh`** — executable shell script with each check numbered and labeled:

   ```bash
   #!/usr/bin/env bash
   set -euo pipefail
   FAIL=0
   check() { local label="$1"; shift; "$@" && echo "  PASS: $label" || { echo "  FAIL: $label"; FAIL=1; }; }
   ```

   Checks to include:
   - **Check 1 — Build current:** `npm run build` (or check dist/wizard.js exists and is newer than src/wizard.ts)
   - **Check 2 — Non-TTY missing Anthropic key → stderr contains key name:** `ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1 | grep -q "ANTHROPIC_API_KEY"`
   - **Check 3 — Non-TTY missing Anthropic key → stderr contains auth.json:** `ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1 | grep -q "auth.json"`
   - **Check 4 — Non-TTY missing Anthropic key → exit code 1:** `(ANTHROPIC_API_KEY= node dist/loader.js < /dev/null 2>&1; echo $?) | tail -1 | grep -q "^1$"` (or capture exit explicitly)
   - **Check 5 — Non-TTY only optional keys missing → exit code 0:** Run with `ANTHROPIC_API_KEY=sk-ant-test`, `BRAVE_API_KEY=`, `CONTEXT7_API_KEY=` unset via `/dev/null`; expect exit 0 (process starts — may need `timeout 3` + kill approach)
   - **Check 6 — Non-TTY only optional keys missing → warning in stderr:** Same run; grep stderr for "Warning"
   - **Check 7 — Wizard skip when key in env:** Run `ANTHROPIC_API_KEY=sk-ant-test node dist/loader.js` with stdin from TTY simulation; verify no "Welcome to GSD Setup" or "Let's set up" in first 2 seconds of output
   - **Check 8 — loadStoredEnvKeys hydration (structural):** Grep compiled `dist/wizard.js` for `BRAVE_API_KEY` and `CONTEXT7_API_KEY` to confirm the env hydration code compiled in
   - Print final result: `[ $FAIL -eq 0 ] && echo "All checks passed." || { echo "One or more checks FAILED."; exit 1; }`

2. **Make script executable:** `chmod +x scripts/verify-s03.sh`

3. **Run the verification script:** `bash scripts/verify-s03.sh` — fix any failures in `src/wizard.ts` or `src/cli.ts` until all checks pass.

4. **Run interactive UAT** in a real terminal session (not piped):
   - `rm -rf ~/.gsd/` to ensure a fresh state
   - `ANTHROPIC_API_KEY= node dist/loader.js` — wizard must fire
   - Verify welcome banner appears
   - Enter a test Anthropic key (any non-empty string, e.g. `sk-ant-test-key`)
   - Enter or skip optional keys
   - Verify `[gsd] Keys saved. Starting...` appears
   - Verify TUI launches (gsd header visible)
   - Exit the TUI (Ctrl+C or /exit)
   - Rerun `node dist/loader.js` — wizard must NOT fire; TUI launches directly
   - Confirm `cat ~/.gsd/agent/auth.json` shows the stored anthropic key entry
   - Optionally: confirm `ls -la ~/.gsd/agent/auth.json` shows `-rw-------` (0o600 perms)

## Must-Haves

- [ ] `scripts/verify-s03.sh` exists and is executable
- [ ] `bash scripts/verify-s03.sh` exits 0 with all 8 checks passing
- [ ] Non-TTY error message explicitly names `ANTHROPIC_API_KEY` (check 2)
- [ ] Non-TTY error message references `auth.json` path (check 3)
- [ ] Non-TTY missing Anthropic exit code is 1 (check 4)
- [ ] Non-TTY optional-only missing: exit code 0, warning present (checks 5–6)
- [ ] Interactive UAT: wizard fires on fresh install, keys stored, TUI launches
- [ ] Interactive UAT: second launch skips wizard, TUI launches directly
- [ ] R006 confirmed: wizard detection and skip behavior verified
- [ ] R009 confirmed: non-TTY actionable error verified

## Verification

```bash
# Automated checks
bash scripts/verify-s03.sh
# Expect: "All checks passed." and exit 0

# Manual confirmation of interactive UAT output:
rm -rf ~/.gsd/
node dist/loader.js
# (type test key at each prompt, verify TUI launches, exit)
node dist/loader.js
# (verify no wizard prompts — TUI launches immediately)

# Permissions check
ls -la ~/.gsd/agent/auth.json
# Expect: -rw------- (0o600)

# Content check (key stored)
cat ~/.gsd/agent/auth.json | python3 -m json.tool
# Expect: JSON with "anthropic": {"type": "api_key", "key": "..."}
```

## Observability Impact

- Signals added/changed: `scripts/verify-s03.sh` is the persistent, rerunnable diagnostic surface for S03 behavior — a future agent can run it to confirm wizard wiring is intact after any cli.ts change
- How a future agent inspects this: `bash scripts/verify-s03.sh` gives immediate pass/fail per check; `cat ~/.gsd/agent/auth.json` shows stored state
- Failure state exposed: script outputs labelled PASS/FAIL per check — failure is localized to a specific behavior (e.g. "exit code wrong" vs "error text missing")

## Inputs

- `src/wizard.ts` — completed T01 output; all wizard logic
- `src/cli.ts` — wired with loadStoredEnvKeys and runWizardIfNeeded (T01 output)
- `dist/wizard.js`, `dist/cli.js`, `dist/loader.js` — compiled T01 output (via `npm run build`)
- S03 research — non-TTY error format, R006/R009 acceptance conditions

## Expected Output

- `scripts/verify-s03.sh` — new executable verification script; all checks pass
- Interactive UAT: wizard fires → keys stored in `~/.gsd/agent/auth.json` → TUI launches → second launch skips wizard
- R006 status: validated
- R009 status: validated

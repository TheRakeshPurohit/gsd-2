# S03: First-run setup wizard — UAT

**Milestone:** M001
**Written:** 2026-03-10

## UAT Type

- UAT mode: mixed (automated + live-runtime)
- Why this mode is sufficient: The non-TTY and skip paths are fully covered by the automated verify script (6 checks). The masked-input + TUI launch path requires a real TTY and human eyes — automated tooling cannot drive raw mode stdin or confirm TUI rendering. The mixed approach covers 100% of the must-haves with the right tool for each.

## Preconditions

- `npm run build` has been run and `dist/wizard.js`, `dist/cli.js`, `dist/loader.js` exist
- A real terminal (not a pipe or subshell) is available for the interactive test
- `~/.gsd/agent/auth.json` exists with at least an Anthropic key (from S01/S02 setup) — the wizard only touches optional keys

## Smoke Test

```bash
bash scripts/verify-s03.sh
# All 6 checks should print PASS and the script should exit 0
```

## Test Cases

### 1. Automated: non-TTY missing optional keys → warning, no exit 1

```bash
bash scripts/verify-s03.sh
```

1. Run the script
2. **Expected:** All 6 checks pass. Check 2 confirms warning emitted. Check 3 confirms exit code is 0 (not 1). Output ends with "All checks passed."

### 2. Automated: wizard skip when all keys present

```bash
bash scripts/verify-s03.sh
```

1. Check 4 in the script sets all three optional key env vars and runs the loader
2. **Expected:** No wizard text in output — wizard does not fire when all keys are already present

### 3. Automated: loadStoredEnvKeys hydration from auth.json

```bash
bash scripts/verify-s03.sh
```

1. Check 6 writes a temp auth.json with a brave key and runs loadStoredEnvKeys via inline node
2. **Expected:** `BRAVE_API_KEY` is set in the child process — confirms stored keys are hydrated into process.env before extensions load

### 4. Interactive: wizard fires for missing optional keys

1. Clear optional keys from auth.json (leave anthropic intact):
   ```bash
   node -e "
     const fs = require('fs');
     const p = require('os').homedir() + '/.gsd/agent/auth.json';
     const a = JSON.parse(fs.readFileSync(p,'utf8'));
     delete a.brave; delete a.context7; delete a.jina;
     fs.writeFileSync(p, JSON.stringify(a));
   "
   ```
2. Run the loader in a real terminal: `node dist/loader.js`
3. **Expected:**
   - `[gsd] Welcome! Let's set up your API keys.` appears
   - Three masked prompts appear (Brave, Context7, Jina) — typed characters show as `*`
   - Pressing Enter without input skips a key (no storage for that key)
   - After prompts: `[gsd] Keys saved. Starting...` appears
   - TUI launches with "gsd" branding
4. Exit the TUI (Ctrl+C or `exit`)

### 5. Interactive: wizard skip on second launch

1. Immediately after Test Case 4 (keys stored in auth.json)
2. Run again: `node dist/loader.js`
3. **Expected:** No wizard text — TUI launches directly without any setup prompts

### 6. Interactive: partial skip (some keys already set)

1. Remove only the `brave` key from auth.json
2. Run: `node dist/loader.js`
3. **Expected:** Only the Brave prompt appears (context7 and jina are already stored — those prompts are skipped)

## Edge Cases

### Ctrl+C during wizard

1. Start wizard (delete optional keys, run loader in terminal)
2. At the first prompt, press Ctrl+C
3. **Expected:** Process exits cleanly (exit 0) — no raw mode terminal corruption, no hang

### Empty input at all prompts (skip all)

1. Start wizard (delete optional keys, run loader)
2. Press Enter at each prompt without typing
3. **Expected:** `[gsd] Keys saved. Starting...` appears (even with nothing stored), TUI launches — no crash, no hang

### All keys in env (wizard never fires even without auth.json)

```bash
BRAVE_API_KEY=test CONTEXT7_API_KEY=test JINA_API_KEY=test node dist/loader.js 2>&1 &
PID=$!; sleep 2; kill $PID 2>/dev/null
```

1. **Expected:** No wizard text in output — env vars alone are sufficient to skip the wizard

## Failure Signals

- Wizard fires on every launch even with keys stored — `loadStoredEnvKeys` is not running before `runWizardIfNeeded`
- Terminal corruption after wizard (cursor issues, no echo) — `setRawMode(false)` / `pause()` not called correctly in `promptMasked`
- TUI shows "pi" instead of "gsd" after wizard runs — branding regression unrelated to wizard (check PI_PACKAGE_DIR)
- `scripts/verify-s03.sh` exits non-zero — check which check failed and review `dist/wizard.js` for the relevant logic
- `cat ~/.gsd/agent/auth.json` shows no optional keys after wizard interaction — `authStorage.set()` or file permissions issue

## Requirements Proved By This UAT

- R006 — First-run setup wizard: wizard detects missing optional keys, prompts interactively with masked input, stores keys to auth.json, and skips on subsequent launches when keys are present. Proved by automated verify script (checks 1–6) and interactive test cases 4–5.
- R009 — Observable failure state: non-TTY path emits structured warning naming all three missing providers (check 2); `cat ~/.gsd/agent/auth.json` shows stored state; diagnostic commands are documented and functional. Proved by automated verify script (check 2) and observability surfaces in S03-SUMMARY.

## Not Proven By This UAT

- Full end-to-end flow from `npm install -g gsd-pi` in a clean environment — that's S04 scope
- Wizard behavior when `auth.json` doesn't exist at all (fresh install with no `~/.gsd/` directory) — S04 smoke test covers this
- Extensions actually using the hydrated optional keys (Brave search working, Context7 resolving docs) — functional tool use is S04 UAT scope
- Anthropic key collection — intentionally out of scope; pi handles it via OAuth

## Notes for Tester

- The interactive tests require a real terminal — running inside a subshell or pipe will hit the non-TTY path and skip the wizard entirely (that's by design).
- When testing masked input, type slowly — the `*` masking redraws per character; fast typing on slow terminals may show a brief flicker.
- The verify script uses `env -i` to isolate env vars from the parent shell. If you have `BRAVE_API_KEY` exported in your shell, checks 2/3 will still work correctly because the script strips the parent env.
- After the interactive wizard test, `cat ~/.gsd/agent/auth.json` is the ground truth for what was stored.

---
id: S03
parent: M001
milestone: M001
provides:
  - src/wizard.ts — loadStoredEnvKeys + runWizardIfNeeded exports; optional-keys-only wizard (Brave/Context7/Jina)
  - scripts/verify-s03.sh — 6-check automated verification script
  - cli.ts wired with pre-session auth gate: loadStoredEnvKeys → runWizardIfNeeded → initResources → createAgentSession
requires:
  - slice: S01
    provides: src/app-paths.ts (authFilePath), AuthStorage.create() in cli.ts
affects:
  - S04
key_files:
  - src/wizard.ts
  - src/cli.ts
  - scripts/verify-s03.sh
key_decisions:
  - D018 — Wizard injection point is pre-session (before createAgentSession), not via session_start event hook — ensures env is fully hydrated before session starts
  - D019 — S03 verification strategy: shell script for automated non-TTY/skip checks + interactive UAT for masked input; no test framework
  - D020 — Wizard scope is optional tool keys only (Brave/Context7/Jina); Anthropic auth is pi's responsibility via OAuth
  - promptMasked wraps setRawMode in try/catch and falls back to plain readline on error (SSH edge case resilience)
  - loadStoredEnvKeys runs before runWizardIfNeeded so stored keys are in process.env before wizard checks them — prevents false-positive wizard fires
  - Optional keys also set into process.env during the interactive wizard path so extensions see them immediately on same launch
patterns_established:
  - Pre-session auth gate: loadStoredEnvKeys → runWizardIfNeeded → initResources → createAgentSession
  - Non-TTY detection pattern using process.stdin.isTTY before any interactive prompt
  - Optional-key skip pattern: empty input = skip, non-empty = store + set process.env
  - env -i + background kill pattern in verify scripts for macOS (no GNU timeout)
observability_surfaces:
  - stderr warning on non-TTY missing optional keys: "[gsd] Warning: optional tool API keys not configured (Brave Search, Context7, Jina). Some tools may not work."
  - stdout wizard entry: "[gsd] Welcome! Let's set up your API keys."
  - stdout wizard completion: "[gsd] Keys saved. Starting..."
  - cat ~/.gsd/agent/auth.json — shows which optional providers have stored credentials
  - BRAVE_API_KEY= CONTEXT7_API_KEY= JINA_API_KEY= node dist/loader.js < /dev/null 2>&1 — surfaces warning with no exit 1
drill_down_paths:
  - .gsd/milestones/M001/slices/S03/tasks/T01-SUMMARY.md
  - .gsd/milestones/M001/slices/S03/tasks/T02-SUMMARY.md
duration: ~45m total (T01 ~25m, T02 ~20m)
verification_result: passed
completed_at: 2026-03-10
---

# S03: First-run setup wizard

**Optional-key wizard (Brave/Context7/Jina) with masked TTY input, non-TTY warning path, and env hydration from auth.json — wired into cli.ts as a pre-session auth gate.**

## What Happened

**T01** created `src/wizard.ts` with three units and wired them into `cli.ts`:

- `promptMasked(question)` — internal async helper using `process.stdin.setRawMode(true)` for character-by-character masked input (`*` per character). Handles backspace (redraw line), Ctrl+C (restore raw mode + exit 0), and Enter (resolve). Falls back to plain `readline.question()` with a visibility warning if `setRawMode` throws (SSH/non-TTY edge case).
- `loadStoredEnvKeys(authStorage)` — iterates `[brave/BRAVE_API_KEY, context7/CONTEXT7_API_KEY, jina/JINA_API_KEY]`; reads `auth.json` credential for each provider; sets `process.env[envVar]` if the env var is absent. Runs on every launch so extensions always see stored keys.
- `runWizardIfNeeded(authStorage)` — checks each optional provider via `authStorage.has(provider) || process.env[envVar]`. Returns immediately if all present. Non-TTY missing: warning to stderr, continue (exit 0). TTY missing: welcome banner → masked prompts → skip on empty / store + set env on non-empty → "Keys saved." confirmation.

`cli.ts` modified to insert `loadStoredEnvKeys(authStorage)` immediately after `AuthStorage.create()` and `await runWizardIfNeeded(authStorage)` before `initResources()`. `ModelRegistry`/`SettingsManager`/`SessionManager` moved after the wizard for clean ordering.

**T02** discovered a scope issue: the original T01 plan included Anthropic required-key logic, which caused the verify script to hang (parent shell's exported `ANTHROPIC_API_KEY` inherited by child). Root cause: pi already handles Anthropic auth via OAuth/API key flow — the GSD wizard collecting it was redundant and broke the script. `src/wizard.ts` was rewritten to optional-keys-only scope. `scripts/verify-s03.sh` was rewritten with 6 checks using `env -i` isolation and background kill pattern (macOS has no GNU timeout).

## Verification

All 6 automated checks pass:

```
=== S03 Verification ===

--- Build ---
  PASS: 1 — dist/wizard.js, dist/cli.js, dist/loader.js exist

--- Non-TTY optional-key warning path ---
  PASS: 2 — Non-TTY missing optional keys → stderr warning emitted
  PASS: 3 — Non-TTY missing optional keys → does NOT exit 1

--- Wizard skip when all keys present ---
  PASS: 4 — All optional keys in env → wizard does not fire

--- loadStoredEnvKeys hydration ---
  PASS: 5 — dist/wizard.js contains all three optional key env var names
  PASS: 6 — loadStoredEnvKeys hydrates BRAVE_API_KEY from auth.json

=== Results ===
All checks passed.
```

Interactive UAT (per T02): cleared optional keys from auth.json, ran `node dist/loader.js` in a real terminal, wizard fired with masked prompts, keys stored, TUI launched. Rerun confirmed wizard skip.

## Requirements Advanced

- R006 — Wizard detects missing optional keys, prompts interactively, stores to auth.json; subsequent launches skip when all keys present
- R009 — Non-TTY missing optional keys emits structured warning naming all three missing providers; observability surfaces confirmed (auth.json, stderr warning, wizard entry/completion signals)

## Requirements Validated

- R006 — First-run setup wizard: verified via automated script (6/6 pass) + interactive UAT (wizard fires, stores keys, TUI launches, rerun skips). Validated.
- R009 — Observable failure state: non-TTY warning names missing providers; `cat ~/.gsd/agent/auth.json` shows stored state; extension load failure surface from S02 remains intact. Validated (optional-key scope).

## New Requirements Surfaced

- none

## Requirements Invalidated or Re-scoped

- R006 — Original spec included Anthropic required-key collection; actual implementation is optional-keys-only (Brave/Context7/Jina). Anthropic auth delegated to pi's OAuth/API key flow. R006 is now satisfied by the optional-key wizard — scope narrowed, requirement still met.
- R009 — Original spec implied exit 1 + actionable error for missing Anthropic key in non-TTY. Rescoped: non-TTY missing optional keys is a warning + continue (exit 0). The requirement's spirit (observable, actionable failure state) is satisfied within the optional-key scope.

## Deviations

- **Anthropic key logic removed from wizard** (T02): the original plan specified a required-key loop for Anthropic with exit 1 on non-TTY. Removed because pi already handles Anthropic auth via OAuth and its own "No models available" message — collecting it in the GSD wizard was redundant and caused the verify script to hang.
- **ModelRegistry/SettingsManager/SessionManager moved after wizard** (T01): plan showed them before wizard. Moving them after is cleaner — avoids any future env-ordering surprises if managers ever read env vars at construction time.

## Known Limitations

- Interactive UAT (masked input + TUI launch) is not automated — requires a real TTY. The verify script covers all non-interactive assertions but cannot test masked keystroke handling.
- `promptMasked` fallback to `readline.question()` (SSH edge case) shows a visibility warning but does not mask input — key is briefly visible. This is acceptable for an optional-key wizard.

## Follow-ups

- S04 should confirm that wizard fires correctly on a clean `npm install -g gsd-pi` install (no existing `~/.gsd/agent/auth.json`), covering the real first-run path.
- Consider whether Jina API key is still relevant if Jina usage has changed in the search-the-web extension.

## Files Created/Modified

- `src/wizard.ts` — new file; optional-keys-only wizard; exports `loadStoredEnvKeys` and `runWizardIfNeeded`
- `src/cli.ts` — added import + pre-session calls; ModelRegistry/SettingsManager/SessionManager moved after wizard
- `scripts/verify-s03.sh` — new file; 6 automated checks; all pass
- `dist/wizard.js`, `dist/cli.js` — compiled output

## Forward Intelligence

### What the next slice should know
- The wizard only handles optional tool keys (Brave/Context7/Jina). Anthropic key collection is entirely pi's territory — do not add Anthropic prompting to the wizard.
- `loadStoredEnvKeys` runs on every launch from `cli.ts`. Any extension that reads `BRAVE_API_KEY`, `CONTEXT7_API_KEY`, or `JINA_API_KEY` from `process.env` will have them set automatically if they're in `auth.json`.
- The wizard fires before `initResources()` and `createAgentSession()` — env is fully hydrated before extensions load.

### What's fragile
- `promptMasked` uses `setRawMode` — requires a real TTY. SSH sessions with unusual terminal configurations may fall back to unmasked readline. Acceptable for now but worth noting.
- `auth.json` is written by `authStorage.set()` with file locking. If the file is corrupted or permissions are wrong, `loadStoredEnvKeys` will silently skip hydration (no crash, but keys won't be set).

### Authoritative diagnostics
- `bash scripts/verify-s03.sh` — first place to check if wizard behavior regresses; 6 labeled pass/fail checks
- `BRAVE_API_KEY= CONTEXT7_API_KEY= JINA_API_KEY= node dist/loader.js < /dev/null 2>&1` — shows exact non-TTY warning text
- `cat ~/.gsd/agent/auth.json` — ground truth for what optional keys are stored

### What assumptions changed
- Original assumption: GSD wizard should collect Anthropic key (required). Actual: pi handles Anthropic via OAuth — GSD wizard collecting it is redundant and interferes with verify automation.
- Original assumption: non-TTY missing Anthropic key should exit 1. Actual: all optional keys missing is a warning + continue, consistent with them being optional.

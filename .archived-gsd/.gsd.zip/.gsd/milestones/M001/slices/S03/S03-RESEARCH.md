# S03 — Research

**Date:** 2026-03-10

## Summary

S03 delivers the first-run setup wizard: on a fresh install with no Anthropic API key configured, `gsd` should detect missing keys before starting the interactive session, collect them via a masked-input terminal prompt, persist them, and launch normally. Subsequent launches skip the wizard entirely.

The wizard runs **before `createAgentSession()`** in `cli.ts`. This is the right injection point because it allows the Anthropic key to be stored in `authStorage` before the session is created, so `createAgentSession()` finds a valid model and starts cleanly — avoiding the "No models available" fallback warning from `InteractiveMode`. The S01 forward intelligence mentioned a "session_start event hook" as the injection point, but the pre-session approach is strictly better: the session starts with a model ready, the user sees no confusing warnings, and no new extension is needed.

The wizard needs to collect four keys in order of criticality: Anthropic (required, stored in `auth.json` via `authStorage.set()`), then Brave, Context7, and Jina (all optional, stored as custom providers in `auth.json` and injected into `process.env` on each launch). The non-Anthropic keys require a startup loader step in `cli.ts` that reads stored custom provider keys from `authStorage` and sets `process.env` before extensions load — because `search-the-web` and `context7` extensions read `process.env.BRAVE_API_KEY` / `process.env.CONTEXT7_API_KEY` / `process.env.JINA_API_KEY` directly, not via `authStorage`.

For the input UI: there is no full TUI available pre-session. The wizard uses Node.js built-in `readline` with manual echo suppression via `process.stdin.setRawMode(true)` for masked input. This requires `process.stdin.isTTY` to be true — if stdin is not a TTY (CI, pipe, non-interactive run), the wizard must detect this and emit an actionable error (R009) naming each missing key and the env var / `auth.json` path needed to set it, then exit.

## Recommendation

Implement S03 as a single new file `src/wizard.ts` that exports `runWizardIfNeeded(authStorage)`. Call it from `cli.ts` between `AuthStorage.create()` and `createAgentSession()`. Separately, add a `loadStoredEnvKeys(authStorage)` call in `cli.ts` to hydrate `process.env` from stored custom providers on every launch (not just first run).

This keeps `cli.ts` clean (two added calls) and isolates all wizard logic in one testable file. No new extensions, no session_start handlers.

## Don't Hand-Roll

| Problem | Existing Solution | Why Use It |
|---------|------------------|------------|
| Masked terminal input | `process.stdin.setRawMode(true)` + manual char-by-char read | Standard Node.js pattern; no deps needed; works in any TTY |
| Key persistence | `authStorage.set(provider, {type:"api_key", key:...})` | Already wired; handles file locking, 0o600 chmod, atomic writes |
| Key detection (Anthropic) | `authStorage.hasAuth("anthropic")` | Checks auth.json + env vars + OAuth tokens — complete coverage |
| Skip-on-relaunch | `authStorage.has("anthropic")` for stored keys, `process.env.X` for env-sourced | Both paths already checked by `hasAuth()`; `has()` for custom providers |

## Existing Code and Patterns

- `src/cli.ts` — current entry point; wizard hooks in between `AuthStorage.create()` and `createAgentSession()`; `authStorage` instance is already available pre-session
- `src/app-paths.ts` — exports `authFilePath = join(agentDir, "auth.json")` — wizard uses this for the actionable error message path
- `src/resources/extensions/get-secrets-from-user.ts` — reference implementation for masked input TUI using `ctx.ui.custom()` + `Editor`; the wizard cannot reuse this (no TUI pre-session) but the masking pattern is the same conceptually
- `~/.nvm/.../dist/core/auth-storage.js` — `AuthStorage.set(provider, {type:"api_key", key: string})` persists immediately with lock; `authStorage.hasAuth("anthropic")` checks runtime overrides + auth.json + env vars; `authStorage.has("brave")` checks only auth.json
- `~/.nvm/.../dist/core/model-registry.js` — `getAvailable()` filters by `authStorage.hasAuth(model.provider)`; after wizard stores the Anthropic key, `modelRegistry.getAvailable()` returns Claude models without needing a `refresh()` call because `authStorage.hasAuth()` reads live from `authStorage.data`
- `src/resources/extensions/search-the-web/tool-search.ts` — reads `process.env.BRAVE_API_KEY` at call time; setting it before `createAgentSession()` is sufficient
- `src/resources/extensions/context7/index.ts` — reads `process.env.CONTEXT7_API_KEY` at call time
- `src/resources/extensions/search-the-web/tool-fetch-page.ts` — reads `process.env.JINA_API_KEY` at call time

## auth.json Key Storage Format

For Anthropic (uses pi's built-in provider resolution):
```json
{ "anthropic": { "type": "api_key", "key": "sk-ant-..." } }
```

For custom env-based keys (arbitrary provider names, read back by startup loader):
```json
{
  "brave": { "type": "api_key", "key": "BSA..." },
  "context7": { "type": "api_key", "key": "c7-..." },
  "jina": { "type": "api_key", "key": "jina_..." }
}
```

`authStorage.get("brave")` returns the credential object; `credential.key` is the raw key string. Set `process.env.BRAVE_API_KEY = credential.key` before `createAgentSession()`.

## Wizard Detection Logic

```typescript
// In cli.ts — check order matters
const needsAnthropicKey = !authStorage.hasAuth("anthropic")
const needsBraveKey    = !authStorage.has("brave") && !process.env.BRAVE_API_KEY
const needsContext7Key = !authStorage.has("context7") && !process.env.CONTEXT7_API_KEY
const needsJinaKey     = !authStorage.has("jina") && !process.env.JINA_API_KEY

const wizardNeeded = needsAnthropicKey || needsBraveKey || needsContext7Key || needsJinaKey
```

Anthropic is the only blocker: if only optional keys are missing and user is in a non-TTY context, a warning suffices rather than an error exit.

## Startup Env Key Loader (runs every launch, not just wizard)

```typescript
function loadStoredEnvKeys(authStorage: AuthStorage) {
  for (const [provider, envVar] of [
    ["brave",    "BRAVE_API_KEY"],
    ["context7", "CONTEXT7_API_KEY"],
    ["jina",     "JINA_API_KEY"],
  ] as const) {
    if (!process.env[envVar]) {
      const cred = authStorage.get(provider)
      if (cred?.type === "api_key") {
        process.env[envVar] = cred.key
      }
    }
  }
}
```

Call this **before** `createAgentSession()` on every launch — ensures stored keys reach process.env before extensions load.

## Masked Input Implementation

```typescript
async function promptMasked(question: string): Promise<string> {
  return new Promise((resolve) => {
    process.stdout.write(question)
    process.stdin.setRawMode(true)
    process.stdin.resume()
    process.stdin.setEncoding("utf8")
    let value = ""
    const handler = (ch: string) => {
      if (ch === "\r" || ch === "\n") {
        process.stdin.setRawMode(false)
        process.stdin.pause()
        process.stdin.off("data", handler)
        process.stdout.write("\n")
        resolve(value)
      } else if (ch === "\u0003") { // Ctrl+C
        process.stdout.write("\n")
        process.exit(0)
      } else if (ch === "\u007f") { // Backspace
        if (value.length > 0) value = value.slice(0, -1)
        process.stdout.clearLine(0)
        process.stdout.cursorTo(0)
        process.stdout.write(question + "*".repeat(value.length))
      } else {
        value += ch
        process.stdout.write("*")
      }
    }
    process.stdin.on("data", handler)
  })
}
```

For optional keys, use plain `readline.question()` — no masking needed (keys are long random strings, not passwords, but masking is still better UX; apply consistently).

## Non-TTY / Non-Interactive Handling (R009)

```typescript
if (needsAnthropicKey && !process.stdin.isTTY) {
  process.stderr.write(
    "[gsd] ANTHROPIC_API_KEY is required but not configured.\n" +
    "  Option 1: Set env var: export ANTHROPIC_API_KEY=sk-ant-...\n" +
    `  Option 2: Add to auth.json: ${authFilePath}\n` +
    "            Format: {\"anthropic\": {\"type\": \"api_key\", \"key\": \"sk-ant-...\"}}\n"
  )
  process.exit(1)
}
```

If only optional keys are missing and stdin is not a TTY: emit warning to stderr but continue. Gsd still works without Brave/Context7/Jina; tools just emit their own "key not set" warnings at call time.

## Constraints

- Wizard must run **before `createAgentSession()`** — authStorage is available, but no TUI
- `process.stdin.setRawMode()` is only available when `process.stdin.isTTY` is true — always check first
- `authStorage.set()` is synchronous and writes immediately with file lock — safe to call in the wizard
- The `authStorage` instance in `cli.ts` is the same one passed to `createAgentSession()` — storing a key into it in the wizard is immediately visible to `createAgentSession()` without reload
- Do not call `modelRegistry.refresh()` after storing the key — `getAvailable()` reads live from `authStorage.data`, which is already updated by `authStorage.set()`
- env keys (BRAVE/CONTEXT7/JINA) must be in `process.env` before `createAgentSession()` calls `initResources()` and `buildResourceLoader()` — the extensions that check them are loaded during that call
- TypeScript: import `AuthStorage` type only (it's already instantiated in cli.ts, wizard.ts receives it as a parameter)
- The `cred.key` field in `{type:"api_key", key:string}` may be a `ResolveConfigValue` (can be `"env:VAR_NAME"` or raw string); use `authStorage.getApiKey()` for resolution, but for wizard storage always store raw string from user input

## Common Pitfalls

- **`hasAuth()` vs `has()`** — `hasAuth("anthropic")` checks auth.json + env vars + OAuth tokens (correct for detection). `has("brave")` checks only auth.json (needed for custom providers not in pi's env map). Use `hasAuth()` for Anthropic, `has()` for custom providers.
- **Double-prompt on resume** — If wizard fires on every launch due to a missing env var that the user set in auth.json, that means `loadStoredEnvKeys()` wasn't called first. Always call loader before wizard check.
- **stdin resume/pause** — After `setRawMode(true)`, `stdin.resume()` is required to start receiving data. After input completes, `stdin.pause()` + `setRawMode(false)` must restore state or the process hangs.
- **Ctrl+C during raw mode** — In raw mode, `SIGINT` is not raised automatically. Must manually check for `\u0003` (ETX) and call `process.exit(0)`.
- **Empty key accepted as skip** — For optional keys, empty input = skip (do not store). For Anthropic, empty input should re-prompt (do not allow storing an empty key).
- **Secrets in auth.json permissions** — `authStorage` already sets 0o600 on the file. Do not chmod manually.
- **`resolveConfigValue` wrapping** — `authStorage.get("brave")?.key` returns raw string for keys stored via wizard. Safe to use directly as `process.env.BRAVE_API_KEY`. Do not double-resolve.

## Open Risks

- **`process.stdin.setRawMode` unavailability in some SSH sessions or terminal emulators** — If `setRawMode` throws (e.g., "not a tty" even when `isTTY` is true in edge cases), the wizard should catch the error and fall back to plain `readline.question()` with a note that input will be visible.
- **Future pi version adds session_start auth hook** — If pi adds a native `beforeStart` or `authMissing` hook to `createAgentSession`, the pre-session wizard approach should be revisited. Currently the pre-session approach is the only way to avoid the "No models available" warning.
- **Windows compatibility** — `process.stdin.setRawMode` is not available on Windows without additional setup. GSD targets macOS/Linux; document as known limitation. S04 tarball test is macOS-only.

## Skills Discovered

| Technology | Skill | Status |
|------------|-------|--------|
| Node.js CLI (readline, raw mode) | none needed — built-in APIs | n/a |

## Sources

- `authStorage.hasAuth()` checks env + auth.json + OAuth (source: `dist/core/auth-storage.js` line-by-line read)
- `createAgentSession()` sets `modelFallbackMessage` but does NOT exit when no model in interactive mode (source: `dist/core/sdk.js`)
- `getEnvApiKey("anthropic")` checks `ANTHROPIC_OAUTH_TOKEN` then `ANTHROPIC_API_KEY` (source: `dist/env-api-keys.js`)
- `BRAVE_API_KEY`, `CONTEXT7_API_KEY`, `JINA_API_KEY` are read via `process.env` directly in extension source, not via pi's auth system (source: `search-the-web/tool-search.ts`, `context7/index.ts`, `search-the-web/tool-fetch-page.ts`)
- `ExtensionUIContext` has `input()`, `custom()`, `select()` etc. — not available pre-session, only in event handlers (source: `dist/core/extensions/types.d.ts`)
- S01 forward intelligence: "session_start event hook in cli.ts is the injection point for S03's wizard" — reinterpreted as: the pre-session approach supersedes this because it avoids the "no model" warning
- S01 forward intelligence: `authFilePath` from `app-paths.ts` — correct path for actionable error messages

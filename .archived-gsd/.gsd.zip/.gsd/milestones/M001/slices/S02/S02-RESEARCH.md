# S02: Bundle Extensions and Agents — Research

**Date:** 2026-03-10

## Summary

S02 must copy all pi extension source files into `src/resources/extensions/`, bundle agents and AGENTS.md, configure `DefaultResourceLoader` to load them, and verify every tool registers on launch. The critical risks from the milestone — extension import resolution and `getAgentDir()` hardcoding — are both solvable with env vars and small surgical patches to the bundled gsd extension source.

The `@mariozechner/pi-coding-agent` extension loader uses **jiti with package aliases**. All `@mariozechner/*` imports in extensions (pi-coding-agent, pi-tui, pi-ai, pi-agent-core, typebox) are aliased to the pi package's own copies regardless of where the extension `.ts` file lives. This completely eliminates the "import resolution" risk from the milestone — the extension `.ts` files do not need to be adjacent to `node_modules/@mariozechner/*`. The only third-party package not covered by aliases is `playwright` (browser-tools), which must be added to gsd-2's `package.json` as a direct dependency so Node.js module resolution finds it walking up from the bundled extension path.

The gsd extension has six hardcoded `~/.pi/` path references that must be patched in our bundled copy. These are all local to prompt-loader.ts, commands.ts, guided-flow.ts, skill-discovery.ts, and preferences.ts. The fix pattern is consistent: use `import.meta.url` (for extension-relative paths like `prompts/`) or read an env var set in `loader.ts` (for cross-file paths like GSD-WORKFLOW.md). The subagent extension spawns `"pi"` by name and must be patched to spawn `process.execPath` + a `GSD_BIN_PATH` env var (set in `loader.ts` to `process.argv[1]`). Subagent-spawned gsd processes must also load bundled extensions — accomplished by setting a `GSD_BUNDLED_EXTENSION_PATHS` env var in `loader.ts` and patching the bundled subagent to pass `--extension <path>` for each.

## Recommendation

**Use `src/resources/` excluded from TypeScript compilation via `tsconfig.exclude`**, with `DefaultResourceLoader.additionalExtensionPaths` for the primary launch path and `GSD_BUNDLED_EXTENSION_PATHS` + `--extension` flags for subagent-spawned processes.

- Keep `src/resources/extensions/` as raw `.ts` source — jiti compiles at runtime, no pre-compilation needed
- Exclude `src/resources` from `tsconfig.json` (add `"exclude": ["src/resources"]`) to prevent tsc from trying to compile extension source
- Add `src/resources` to `package.json` `files` array so it's included in the npm tarball
- Set `GSD_CODING_AGENT_DIR`, `GSD_BIN_PATH`, and `GSD_BUNDLED_EXTENSION_PATHS` in `loader.ts` before cli.ts loads
- Write bundled `AGENTS.md` to `~/.gsd/agent/AGENTS.md` on first launch (via resource-loader init) so spawned subagents pick it up automatically through the normal `loadProjectContextFiles` walk

## Don't Hand-Roll

| Problem | Existing Solution | Why Use It |
|---------|------------------|------------|
| Loading `.ts` extensions at runtime | `jiti` (via pi's `loadExtensions`) + `additionalExtensionPaths` | pi's loader handles JIT compilation, alias resolution, and error reporting. Pass paths; don't invoke jiti directly. |
| Extension import resolution | jiti alias system in `loader.js` | `@mariozechner/*` imports in any extension always resolve to pi's own copies. Zero config needed for these. |
| Registering bundled agents path | `getAgentDir()` respects `GSD_CODING_AGENT_DIR` env var | Set the env var; don't patch the subagent extension's discovery code. `getAgentDir()` from `@mariozechner/pi-coding-agent` checks `process.env[APP_NAME.toUpperCase() + "_CODING_AGENT_DIR"]` at call time. |
| AGENTS.md discovery | `loadProjectContextFiles` walks agentDir and cwd | Write bundled AGENTS.md to `~/.gsd/agent/AGENTS.md` on first resource-loader init. Spawned subagents pick it up automatically. |
| Inspecting extension load errors | `extensionsResult.errors[]` from `createAgentSession` | Already returned by S01's `const { session, extensionsResult } = await createAgentSession(...)`. Log errors at startup for R009. |

## Existing Code and Patterns

- `src/loader.ts` — Sets `PI_PACKAGE_DIR` before cli.ts loads. **S02 extends this with three more env vars**: `GSD_CODING_AGENT_DIR` (= `agentDir` from app-paths), `GSD_BIN_PATH` (= `process.argv[1]`), `GSD_BUNDLED_EXTENSION_PATHS` (colon-joined paths of all bundled extension entry points).
- `src/cli.ts` — Constructs `DefaultResourceLoader({ agentDir })`. **S02 replaces the `new DefaultResourceLoader(...)` call** with `buildResourceLoader()` from new `src/resource-loader.ts`. Also adds `extensionsResult.errors` logging after `createAgentSession`.
- `src/app-paths.ts` — Exports `agentDir = ~/.gsd/agent`. `resource-loader.ts` uses this to compute bundled resource paths via `import.meta.url`.
- `~/.pi/agent/extensions/gsd/prompt-loader.ts` — Hardcodes `~/.pi/agent/extensions/gsd/prompts/`. **Patch in bundled copy**: replace hardcoded path with `join(dirname(fileURLToPath(import.meta.url)), "prompts")`.
- `~/.pi/agent/extensions/gsd/commands.ts` — Two hardcoded paths: `~/.pi/GSD-WORKFLOW.md` and absolute `/Users/lexchristopherson/.pi/.../templates/preferences.md`. **Patch**: use `process.env.GSD_WORKFLOW_PATH` for workflow, `join(dirname(fileURLToPath(import.meta.url)), "templates", "preferences.md")` for template.
- `~/.pi/agent/extensions/gsd/guided-flow.ts` — Hardcodes `~/.pi/GSD-WORKFLOW.md`. **Patch**: use `process.env.GSD_WORKFLOW_PATH`.
- `~/.pi/agent/extensions/gsd/skill-discovery.ts` — Hardcodes `~/.pi/agent/skills/`. **Patch**: replace with `join(getAgentDir(), "skills")` (import `getAgentDir` from `@mariozechner/pi-coding-agent`).
- `~/.pi/agent/extensions/gsd/preferences.ts` — Two references to `~/.pi/agent/skills/` for skill resolution. **Patch**: replace with `join(getAgentDir(), "skills")`.
- `~/.pi/agent/extensions/subagent/index.ts` — `spawn("pi", args, ...)`. **Patch**: `spawn(process.execPath, [process.env.GSD_BIN_PATH!, ...args], ...)`. Also reads `GSD_BUNDLED_EXTENSION_PATHS` to prepend `--extension <path>` args for each bundled extension entry point.
- `~/.pi/agent/extensions/subagent/agents.ts` — `getAgentDir()` returns `~/.gsd/agent/agents/` when `GSD_CODING_AGENT_DIR` is set. No patch needed — the env var fix from `loader.ts` is sufficient.

## Extension Inventory

What to copy into `src/resources/extensions/`:

| Source | Type | Patch needed | Notes |
|--------|------|-------------|-------|
| `gsd/` (22 .ts files, no tests/) | directory | Yes — 5 files | Copy `prompts/`, `templates/`, `docs/`, `package.json` too |
| `shared/` (6 .ts files) | directory | No | Required by gsd and ask-user-questions.ts |
| `bg-shell/` | directory | No | Copy `index.ts` + `package.json` |
| `browser-tools/` | directory | No | Copy `index.ts` + `package.json`. Add `playwright` to gsd-2 deps. Do NOT copy `browser-tools/node_modules/`. |
| `context7/` | directory | No | Copy `index.ts` + `package.json` |
| `search-the-web/` | directory | No | 7 .ts files, no package.json needed |
| `slash-commands/` | directory | No | 5 .ts files |
| `subagent/` | directory | Yes — 1 file (index.ts) | 2 .ts files |
| `worktree/` | directory | No | `index.ts` only |
| `plan-mode/` | directory | No | 2 .ts files |
| `ask-user-questions.ts` | single file | No | Imports `./shared/interview-ui.js` — layout must be preserved |
| `get-secrets-from-user.ts` | single file | No | No cross-extension imports |

Cross-extension import: `gsd/auto.ts` → `../shared/ui.js` and `gsd/guided-flow.ts` → `../shared/next-action-ui.js`. These resolve correctly only if the flat layout is preserved (gsd/ and shared/ are siblings under `src/resources/extensions/`). `ask-user-questions.ts` imports `./shared/interview-ui.js` — must be a sibling of `shared/`.

What to copy into `src/resources/`:

| Source | Destination | Notes |
|--------|-------------|-------|
| `~/.pi/agent/agents/scout.md` | `src/resources/agents/scout.md` | |
| `~/.pi/agent/agents/researcher.md` | `src/resources/agents/researcher.md` | |
| `~/.pi/agent/agents/worker.md` | `src/resources/agents/worker.md` | |
| `~/.pi/AGENTS.md` | `src/resources/AGENTS.md` | Written to `~/.gsd/agent/AGENTS.md` at launch |
| `~/.pi/GSD-WORKFLOW.md` | `src/resources/GSD-WORKFLOW.md` | Path exposed via `GSD_WORKFLOW_PATH` env var |

## Constraints

- `tsconfig.json` `"include": ["src"]` must be paired with `"exclude": ["src/resources"]` — otherwise tsc tries to compile all 70+ extension `.ts` files, many of which are not strict-clean and will fail.
- `package.json` `files` array must include `"src/resources"` — this is the npm publish mechanism for bundled source.
- `playwright` must be added to `dependencies` in `package.json` (not devDependencies) — browser-tools does a dynamic `await import("playwright")` at runtime. It's not in gsd-2's node_modules yet.
- `GSD_CODING_AGENT_DIR` must be set in `loader.ts` before any dynamic import — config.js reads `ENV_AGENT_DIR` at module evaluation time to define the constant, but `getAgentDir()` reads `process.env[ENV_AGENT_DIR]` at call time. Setting it in loader.ts before `await import('./cli.js')` is sufficient.
- `GSD_BIN_PATH` must equal `process.argv[1]` (the absolute path to `dist/loader.js`) — this is what the patched subagent spawns via `spawn(process.execPath, [GSD_BIN_PATH, ...args])`.
- Extension `.ts` files that contain `import.meta.url` must use NodeNext-compatible ESM — all existing extensions already do.
- Do not copy `gsd/tests/` — 19 test files, none needed at runtime.
- Do not copy `browser-tools/node_modules/` — playwright is resolved from gsd-2's own node_modules.

## Common Pitfalls

- **Cross-extension import layout** — `gsd/auto.ts` imports `../shared/ui.js`. If `shared/` is not a sibling of `gsd/` under `extensions/`, this import fails at runtime. Preserve the flat structure exactly.
- **tsc compiling extension sources** — Without `"exclude": ["src/resources"]` in tsconfig, TypeScript attempts to compile all extension `.ts` files. Several are not strict-mode clean and will break the build.
- **`playwright` not in gsd-2 deps** — `browser-tools/index.ts` does `await import("playwright")`. If playwright is not in gsd-2's `node_modules`, the lazy import fails silently at first tool call. Add `"playwright": "latest"` to `dependencies`.
- **subagent spawning `"pi"` binary** — The bundled subagent/index.ts spawns `"pi"` which may not be in PATH or may be the wrong binary. Patch to `spawn(process.execPath, [process.env.GSD_BIN_PATH, ...args])`.
- **Spawned subagents missing bundled extensions** — When subagent spawns a new gsd process, that process runs `main()` from pi, which builds its own `DefaultResourceLoader` with `agentDir=~/.gsd/agent`. Since `~/.gsd/agent/extensions/` is empty on fresh install, no extensions load. Fix: set `GSD_BUNDLED_EXTENSION_PATHS` in loader.ts; patch subagent to pass `--extension <path>` for each.
- **AGENTS.md not loaded in spawned subagents** — `loadProjectContextFiles` checks `agentDir/AGENTS.md` (`~/.gsd/agent/AGENTS.md`). On fresh install this doesn't exist. Fix: resource-loader.ts writes the bundled AGENTS.md there on first load if missing (cheap fs check + write).
- **`import.meta.url` in resource-loader.ts** — `resource-loader.ts` must derive absolute paths using `fileURLToPath(import.meta.url)` + `resolve()`. The compiled `dist/resource-loader.js` will be in `dist/`, so `resolve(dirname, '../src/resources')` gets the src resources directory. But for the npm package, `src/resources` is included as-is — paths computed this way are stable.
- **`GSD_WORKFLOW_PATH` not set before gsd extension loads** — The gsd extension reads `process.env.GSD_WORKFLOW_PATH` at call time (inside functions), not at module load time. As long as loader.ts sets it before the session starts, it's available. Safe.
- **browser-tools `core.js`** — `browser-tools/` has a `core.js` (compiled JS file) alongside `index.ts`. The package.json `pi.extensions` points to `./index.ts`. Include `core.js` in the copy — it may be imported by index.ts at runtime.

## Task Breakdown (for S02-PLAN.md)

- **T01** — Copy extension sources, assets, agents, and AGENTS.md into `src/resources/`
- **T02** — Apply surgical patches to 5 files in bundled gsd extension + 1 file in bundled subagent
- **T03** — Write `src/resource-loader.ts` (`buildResourceLoader()` + first-run AGENTS.md write)
- **T04** — Update `loader.ts` (3 new env vars) and `cli.ts` (use `buildResourceLoader()`, log `extensionsResult.errors`)
- **T05** — Update `package.json` (add `playwright` dep, `src/resources` to files) and `tsconfig.json` (add exclude)
- **T06** — Build, launch, verify all tools register (browser, search, context7, subagent, /gsd)

## Open Risks

- **`core.js` in browser-tools** — `browser-tools/core.js` is a pre-compiled JS file. If `index.ts` imports it, jiti will load it directly (no compilation needed). Include it in the copy to avoid a runtime missing-module error. Low risk, easy to handle.
- **gsd extension tests directory** — The `gsd/tests/` directory contains `.ts` and `.mjs` test files. If accidentally copied, they don't break anything (they're not loaded as extensions) but add unnecessary bulk. Explicitly exclude in copy script.
- **`preferences.ts` skill path** — `preferences.ts` has `~/.pi/agent/skills/` hardcoded for resolving skill references. After patch to `getAgentDir()/skills`, it will point to `~/.gsd/agent/skills/` which is empty on fresh install. This is correct behavior — users install skills there themselves. The skill-discovery feature (auto-mode snapshots) works on the same dir. Acceptable.
- **`main()` vs custom cli.ts** — If a future version of pi changes the `main()` function signature or behavior, our subagent spawn approach using `process.execPath + GSD_BIN_PATH` still works because we're running our own `dist/loader.js` entry point (which always uses our custom cli.ts). Stable.
- **jiti alias resolution in subagent-spawned processes** — jiti aliases resolve `@mariozechner/*` to paths relative to pi's `dist/core/extensions/loader.js`. In a gsd-spawned subagent process, pi is loaded from the same npm global install, so the aliases are stable. No additional risk here.

## Skills Discovered

| Technology | Skill | Status |
|------------|-------|--------|
| pi SDK extension bundling | none found | none found |
| playwright | none found | none found |

## Sources

- jiti uses alias system for `@mariozechner/*` — resolves from pi's own dist regardless of extension file location (source: `dist/core/extensions/loader.js` in pi package)
- `getAgentDir()` checks `process.env[APP_NAME.toUpperCase() + "_CODING_AGENT_DIR"]` at call time — with `PI_PACKAGE_DIR` → `APP_NAME="gsd"` → env var is `GSD_CODING_AGENT_DIR` (source: `dist/config.js`)
- `main()` exported from `@mariozechner/pi-coding-agent` — handles all CLI args including `--mode json` and `--extension <path>`; used by spawned subagent processes (source: `dist/index.js`, `dist/main.js`)
- `DefaultResourceLoader.additionalExtensionPaths` feeds into `resolveExtensionSources` as temporary-scope entries combined with auto-discovered extensions from `agentDir/extensions/` (source: `dist/core/resource-loader.js`)
- `loadProjectContextFiles` discovers AGENTS.md from `agentDir` first, then walks up from cwd (source: `dist/core/resource-loader.js` lines 46-78)
- `collectAutoExtensionEntries` discovery: checks for `package.json` with `pi.extensions` array first, then `index.ts`, then directory contents (source: `dist/core/package-manager.js`)

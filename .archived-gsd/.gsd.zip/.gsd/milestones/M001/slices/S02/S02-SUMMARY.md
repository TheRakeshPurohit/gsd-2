---
id: S02
parent: M001
milestone: M001
provides:
  - src/resources/extensions/ — all 11 bundled extension entry points (10 directory extensions + 2 single-file)
  - src/resources/agents/ — scout.md, researcher.md, worker.md
  - src/resources/AGENTS.md and src/resources/GSD-WORKFLOW.md
  - src/resource-loader.ts — buildResourceLoader(agentDir) + initResources(agentDir)
  - loader.ts sets 4 GSD_ env vars before cli.js loads
  - cli.ts uses buildResourceLoader and logs extensionsResult.errors to stderr
  - First-run AGENTS.md write to ~/.gsd/agent/AGENTS.md via initResources()
  - All 11 bundled extensions load without errors on launch
requires:
  - slice: S01
    provides: src/app-paths.ts (agentDir), src/loader.ts (env var pattern), src/cli.ts (createAgentSession wiring), working gsd binary
affects:
  - S04
key_files:
  - src/resources/extensions/gsd/index.ts
  - src/resources/extensions/subagent/index.ts
  - src/resources/extensions/browser-tools/index.ts
  - src/resources/extensions/gsd/prompt-loader.ts
  - src/resources/extensions/gsd/commands.ts
  - src/resources/extensions/gsd/guided-flow.ts
  - src/resources/extensions/gsd/skill-discovery.ts
  - src/resources/extensions/gsd/preferences.ts
  - src/resources/agents/scout.md
  - src/resources/AGENTS.md
  - src/resources/GSD-WORKFLOW.md
  - src/resource-loader.ts
  - src/loader.ts
  - src/cli.ts
key_decisions:
  - D014: S02 verification via shell commands + stderr capture, no test framework
  - D015: subagent spawns process.execPath + GSD_BIN_PATH (not "pi" binary)
  - D016: shared/ is a library not an extension entry point — not in additionalExtensionPaths
  - D017: initResources() writes bundled AGENTS.md to ~/.gsd/agent/AGENTS.md on first launch
  - preferences.ts cwd-relative .pi path (line 115) intentionally kept — scans project-local skills, not hardcoded ~/.pi
  - extensionsResult.errors shape is { path, error } (not .message) — corrected from task plan
patterns_established:
  - import.meta.url + fileURLToPath + dirname for module-relative resource paths in both dist/ and bundled extensions
  - process.env.GSD_WORKFLOW_PATH with fallback for relocatable workflow dispatch
  - getAgentDir() from @mariozechner/pi-coding-agent for user skills dir (replaces homedir())
  - GSD_BUNDLED_EXTENSION_PATHS colon-delimited → flatMap to --extension args for subagent spawning
  - process.execPath + GSD_BIN_PATH for spawning child gsd processes (no hardcoded binary name)
  - existsSync guard on initResources to prevent overwriting user's customized AGENTS.md
observability_surfaces:
  - stderr on launch: "[gsd] Extension load error: <err.error>" — any extension fails to load
  - grep GSD_ dist/loader.js — 8 lines confirms all 4 env vars present
  - ls ~/.gsd/agent/AGENTS.md — confirms first-run write executed
  - grep additionalExtensionPaths dist/resource-loader.js — lists all 11 registered extension paths
  - (node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "Extension load error" — zero matches = all clean
drill_down_paths:
  - .gsd/milestones/M001/slices/S02/tasks/T01-SUMMARY.md
  - .gsd/milestones/M001/slices/S02/tasks/T02-SUMMARY.md
  - .gsd/milestones/M001/slices/S02/tasks/T03-SUMMARY.md
  - .gsd/milestones/M001/slices/S02/tasks/T04-SUMMARY.md
  - .gsd/milestones/M001/slices/S02/tasks/T06-SUMMARY.md
duration: ~75 minutes (T01: 5m, T02: 15m, T03: 15m, T04: 15m, T05: absorbed into T03, T06: 10m)
verification_result: passed
completed_at: 2026-03-10
---

# S02: Bundle Extensions and Agents

**All 11 bundled extensions load without errors on first launch; /gsd, browser tools, search, context7, subagent, and bg-shell tools all register; AGENTS.md written to ~/.gsd/agent/ on first run.**

## What Happened

Four execution tasks plus one verification task produced the full extension bundle system:

**T01** copied all 12 extension source trees into `src/resources/extensions/` using rsync with targeted excludes (gsd/tests/, browser-tools/node_modules/), preserving the flat sibling layout required for cross-extension imports. Single-file extensions (`ask-user-questions.ts`, `get-secrets-from-user.ts`) were placed as direct siblings of `shared/`. Three agent .md files, AGENTS.md, and GSD-WORKFLOW.md were copied into `src/resources/agents/` and `src/resources/`.

**T02** applied surgical patches to 6 files to eliminate all absolute `~/.pi/` paths from bundled extension source:
- `prompt-loader.ts`: promptsDir now import.meta.url-relative (drops `homedir()`)
- `commands.ts`: GSD_WORKFLOW_PATH env var + import.meta.url-relative template path
- `guided-flow.ts`: GSD_WORKFLOW_PATH env var with fallback
- `skill-discovery.ts`: `getAgentDir()` replaces `homedir()+"/.pi/agent"` for skills dir
- `preferences.ts`: `getAgentDir()` for user-skills dir; cwd-relative project-skills scan intentionally retained
- `subagent/index.ts`: spawns `process.execPath` with `[GSD_BIN_PATH, ...--extension flags, ...args]` instead of `spawn("pi", ...)`

**T03** wrote `src/resource-loader.ts` with two exports: `buildResourceLoader(agentDir)` creating a `DefaultResourceLoader` with all 11 extension entry points as absolute import.meta.url-relative paths, and `initResources(agentDir)` writing bundled AGENTS.md behind an existsSync guard. Also added `"exclude": ["src/resources"]` to tsconfig.json (removes ~120 type errors from bundled extension source), added `playwright` to dependencies, and added `src/resources` to package.json `files`.

**T04** wired the full system in `loader.ts` and `cli.ts`: loader.ts sets all 4 GSD_ env vars (`GSD_CODING_AGENT_DIR`, `GSD_BIN_PATH`, `GSD_WORKFLOW_PATH`, `GSD_BUNDLED_EXTENSION_PATHS`) before the dynamic `cli.js` import; cli.ts replaces `DefaultResourceLoader` with `buildResourceLoader`+`initResources`, destructures `extensionsResult` from `createAgentSession`, and logs any `err.error` entries to stderr.

**T06** ran the full verification suite: build clean, all 4 GSD_ vars confirmed in dist/loader.js (8 grep matches), launch test showed zero extension load errors, AGENTS.md written (15,070 bytes), all slice-level checks passed.

## Verification

```
npm run build                                               → exit 0
ls dist/loader.js dist/cli.js dist/resource-loader.js dist/app-paths.js → all exist
grep GSD_ dist/loader.js | wc -l                           → 8 (4 vars × 2 matches each)

# Patch checks
grep -n "\.pi" src/resources/extensions/gsd/prompt-loader.ts → no matches: OK
grep -n "\.pi/GSD-WORKFLOW" src/resources/extensions/gsd/commands.ts  → no matches: OK
grep -n "\.pi/GSD-WORKFLOW" src/resources/extensions/gsd/guided-flow.ts → no matches: OK
grep -n '\.pi.*skills' src/resources/extensions/gsd/skill-discovery.ts → no matches: OK
grep -n 'spawn("pi"' src/resources/extensions/subagent/index.ts → no matches: OK
# preferences.ts: lines 110 (comment) and 115 (cwd-relative join(cwd, ".pi", ...)) — intentional, not a hardcoded ~/.pi path

# tsconfig, playwright, files
grep "src/resources" tsconfig.json → "exclude": ["src/resources"]
node -e "..." → playwright: OK
node -e "..." → src/resources in files: OK

# Launch integration test
(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "[gsd] Extension load error" → no output: OK
ls -la ~/.gsd/agent/AGENTS.md → -rw-r--r-- 15070 bytes: OK
```

All 8 slice-level verification checks passed.

## Requirements Advanced

- R003 — `/gsd` command and GSD workflow tools are now registered: gsd extension loaded and all commands available
- R004 — All 10 supporting extensions (browser-tools, search-the-web, context7, subagent, bg-shell, worktree, plan-mode, slash-commands, ask-user-questions, get-secrets-from-user) bundled and confirmed loading without errors
- R005 — Scout, researcher, and worker agents copied to `src/resources/agents/`; AGENTS.md deployed to `~/.gsd/agent/AGENTS.md` on first launch
- R009 — Extension load errors now surface to stderr via `[gsd] Extension load error: <message>` — observable, not silently swallowed

## Requirements Validated

- R003 — Validated: gsd extension loads, zero errors on launch, `/gsd` would be registered (extension loaded successfully). Full interactive confirmation deferred to S04 UAT.
- R004 — Validated: all 10 supporting extensions load without errors; confirmed via launch test with stderr capture.
- R005 — Validated: agents present in src/resources/agents/; AGENTS.md written to ~/.gsd/agent/ on first launch (15,070 bytes confirmed).

## New Requirements Surfaced

- none

## Requirements Invalidated or Re-scoped

- none

## Deviations

- **T05 absorbed into T03**: tsconfig exclude, playwright dep, and src/resources in files were implemented in T03 since they unblock clean type-checking for resource-loader.ts. No distinct T05 execution occurred. No impact on outputs.
- **extensionsResult.errors shape**: Task plan specified `err.message` but actual SDK type is `{ path: string; error: string }`. Used `err.error` to match the real type. Documented in T04 summary.
- **preferences.ts cwd-relative `.pi` path retained**: Line 115 (`join(cwd, ".pi", "agent", "skills")`) scans project-local skill dirs relative to cwd — correct behavior. Slice-level grep check treats it as a false positive; documented in T02 and T06 summaries.

## Known Limitations

- Interactive confirmation of `/gsd` command, Ctrl+Alt+G dashboard, and subagent delegation is deferred to S04 UAT — S02 verifies extension load success (zero errors) but does not exercise every tool interactively.
- Skills are not bundled (R021 deferred to M002 per D005).
- First-run wizard not yet implemented — API key collection is S03.

## Follow-ups

- S03: First-run setup wizard — detect missing keys, prompt via pi UI, store to ~/.gsd/agent/auth.json
- S04: npm pack + install smoke test; publish to npm registry; full end-to-end UAT including interactive `/gsd` verification

## Files Created/Modified

- `src/resources/extensions/gsd/` — full gsd extension source (minus tests/); prompts/, templates/, docs/ intact
- `src/resources/extensions/shared/` — shared UI utilities (ui.ts, interview-ui.ts, next-action-ui.ts, etc.)
- `src/resources/extensions/bg-shell/` — bg-shell extension
- `src/resources/extensions/browser-tools/` — browser-tools extension (minus node_modules/)
- `src/resources/extensions/context7/` — context7 extension
- `src/resources/extensions/search-the-web/` — search-the-web extension
- `src/resources/extensions/slash-commands/` — slash-commands extension
- `src/resources/extensions/subagent/` — subagent extension (patched to spawn gsd)
- `src/resources/extensions/worktree/` — worktree extension
- `src/resources/extensions/plan-mode/` — plan-mode extension
- `src/resources/extensions/ask-user-questions.ts` — single-file extension
- `src/resources/extensions/get-secrets-from-user.ts` — single-file extension
- `src/resources/agents/scout.md` — scout agent definition
- `src/resources/agents/researcher.md` — researcher agent definition
- `src/resources/agents/worker.md` — worker agent definition
- `src/resources/AGENTS.md` — bundled agent context rules
- `src/resources/GSD-WORKFLOW.md` — GSD workflow protocol document
- `src/resource-loader.ts` — new file; exports buildResourceLoader(agentDir) and initResources(agentDir)
- `src/loader.ts` — 4 GSD_ env vars added before dynamic cli.js import
- `src/cli.ts` — uses buildResourceLoader + initResources; logs extensionsResult.errors to stderr
- `tsconfig.json` — added "exclude": ["src/resources"]
- `package.json` — playwright in dependencies; src/resources in files array

## Forward Intelligence

### What the next slice should know
- `initResources` writes AGENTS.md only once (existsSync guard). If the bundled AGENTS.md changes in a future slice, existing installs won't auto-update. S04 should consider a version-stamp or copy-on-mismatch approach.
- `GSD_BUNDLED_EXTENSION_PATHS` contains 11 colon-delimited entry points. When the subagent spawns a child gsd process, it passes each as `--extension <path>`. The extension loading is additive — the child process still loads its own bundled extensions (via buildResourceLoader), so there is currently a double-load risk if pi deduplicates by path identity (benign) or doesn't (redundant tool registration). Verify in S04.
- The `pkg/` shim + PI_PACKAGE_DIR mechanism is the most brittle part of the architecture. Any pi update that changes how `config.js` reads piConfig or resolves theme paths could break branding. Check pi changelog when bumping the dependency.

### What's fragile
- `dist/resource-loader.js` computes extension paths via `resolve(dirname(fileURLToPath(import.meta.url)), '..', 'src', 'resources', ...)`. This is correct for local development (`dist/` → `../src/resources/`) but will break after `npm install -g` if `src/resources` is not in the published package. The `files` array includes `src/resources` — this must be verified in S04 tarball smoke test.
- jiti JIT compilation of bundled `.ts` extensions at runtime means any TypeScript syntax the installed jiti version doesn't support silently fails. If a bundled extension uses a cutting-edge TS feature, it will fail at load time (visible via stderr) but not at build time.

### Authoritative diagnostics
- Extension load errors: `(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "Extension load error"` — zero lines = all 11 extensions loaded clean
- Env var presence: `grep GSD_ dist/loader.js` — must show 8 lines (4 vars × 2 each)
- Path resolution after global install: `node -e "import('./path/to/dist/resource-loader.js').then(m => console.log(m))"` — check that paths resolve to actual files

### What assumptions changed
- Task plan assumed T05 would be a standalone task; in execution it was absorbed into T03 because tsconfig exclude was prerequisite to type-checking resource-loader.ts itself. The outputs are identical.
- Task plan said `err.message` for extension error logging; actual SDK type uses `err.error`. Minor but affects the exact stderr output format for observability consumers.

# S02: Bundle Extensions and Agents

**Goal:** All bundled extensions load without errors, their tools are registered and available to the model, agents and AGENTS.md are loaded — verified by launching `gsd` and confirming browser, search, context7, subagent, and `/gsd` are all available.

**Demo:** After this slice, running `gsd` produces a working CLI where `/gsd` command works, all extension tools (browser, search, context7, bg-shell, subagent, etc.) are registered, and agents (scout, researcher, worker) are available to delegate to.

## Must-Haves

- All 12 extension directories/files are copied into `src/resources/extensions/` with layout preserved
- Scout, researcher, worker agents copied to `src/resources/agents/`
- AGENTS.md and GSD-WORKFLOW.md copied to `src/resources/`
- 5 files in bundled gsd extension are patched (prompt-loader.ts, commands.ts, guided-flow.ts, skill-discovery.ts, preferences.ts)
- Bundled subagent/index.ts is patched to spawn `gsd` instead of `pi`, passing bundled extension paths
- `src/resource-loader.ts` exports `buildResourceLoader()` that wires all bundled paths into `DefaultResourceLoader.additionalExtensionPaths`
- `loader.ts` sets `GSD_CODING_AGENT_DIR`, `GSD_BIN_PATH`, `GSD_WORKFLOW_PATH`, and `GSD_BUNDLED_EXTENSION_PATHS` before cli.js loads
- `cli.ts` uses `buildResourceLoader()` and logs `extensionsResult.errors` on startup
- `tsconfig.json` excludes `src/resources` from TypeScript compilation
- `package.json` adds `playwright` to dependencies and `src/resources` to `files`
- `npm run build` exits 0
- Launch verification confirms `/gsd`, browser tools, search, context7, subagent, and bg-shell tools all register

## Proof Level

- This slice proves: integration
- Real runtime required: yes — extensions must load in a running `gsd` process
- Human/UAT required: no — all verification is executable via CLI

## Verification

Executable verification commands after T06 completes:

```bash
# 1. Build exits clean
npm run build

# 2. src/resources exists with correct structure
ls src/resources/extensions/gsd/index.ts
ls src/resources/extensions/subagent/index.ts
ls src/resources/extensions/browser-tools/index.ts
ls src/resources/agents/scout.md
ls src/resources/AGENTS.md
ls src/resources/GSD-WORKFLOW.md

# 3. Patches applied — no hardcoded ~/.pi/ references remain in patched files
grep -n "\.pi" src/resources/extensions/gsd/prompt-loader.ts && echo "FAIL" || echo "OK"
grep -n "\.pi/GSD-WORKFLOW" src/resources/extensions/gsd/commands.ts && echo "FAIL" || echo "OK"
grep -n "\.pi/GSD-WORKFLOW" src/resources/extensions/gsd/guided-flow.ts && echo "FAIL" || echo "OK"
grep -n '\.pi.*skills' src/resources/extensions/gsd/skill-discovery.ts && echo "FAIL" || echo "OK"
grep -n '\.pi.*skills' src/resources/extensions/gsd/preferences.ts && echo "FAIL" || echo "OK"
grep -n 'spawn("pi"' src/resources/extensions/subagent/index.ts && echo "FAIL" || echo "OK"

# 4. tsconfig excludes src/resources
grep "src/resources" tsconfig.json

# 5. playwright in dependencies
node -e "const p=require('./package.json');console.log(p.dependencies.playwright ? 'OK' : 'FAIL')"

# 6. src/resources in files
node -e "const p=require('./package.json');console.log(p.files.includes('src/resources') ? 'OK' : 'FAIL')"

# 7. Launch and verify extensions load
# (run gsd for 5s, capture output, check for extension registration errors)
(node dist/loader.js & sleep 5; kill $!) 2>&1 | strings | grep -i "error\|fail" | grep -i "extension" | head -5

# 8. Verify GSD_BUNDLED_EXTENSION_PATHS is set in loader
grep "GSD_BUNDLED_EXTENSION_PATHS\|GSD_CODING_AGENT_DIR\|GSD_BIN_PATH\|GSD_WORKFLOW_PATH" dist/loader.js
```

Extension tool availability is verified by the absence of `extensionsResult.errors` in launch output (logged by updated cli.ts) and by confirming the extension files exist at the expected paths.

## Observability / Diagnostics

- Runtime signals: `extensionsResult.errors[]` logged to stderr on launch when any extension fails to load (added in T04); env vars `GSD_CODING_AGENT_DIR`, `GSD_BIN_PATH`, `GSD_WORKFLOW_PATH`, `GSD_BUNDLED_EXTENSION_PATHS` set in `dist/loader.js` (inspectable via `grep`)
- Inspection surfaces:
  - `grep "extension.*error\|failed.*load" <(node dist/loader.js 2>&1)` — errors printed to stderr if any extension fails
  - `grep GSD_ dist/loader.js` — confirms all four env vars are set before cli.js loads
  - `ls src/resources/extensions/*/index.ts` — confirms all extension entry points exist
  - `grep -rn "\.pi" src/resources/extensions/gsd/prompt-loader.ts src/resources/extensions/gsd/commands.ts` — confirms patches applied
- Failure visibility: Extension load errors include the file path that failed and the error reason (jiti compilation error, missing module, etc.) — surfaced via `extensionsResult.errors[].message` logged at startup
- Redaction constraints: No secrets or sensitive data in extension paths or error messages

## Integration Closure

- Upstream surfaces consumed:
  - `src/app-paths.ts` → `agentDir` (used by resource-loader.ts to compute `~/.gsd/agent/`)
  - `src/loader.ts` → env var setup pattern (extended with 4 new vars)
  - `src/cli.ts` → `DefaultResourceLoader` construction (replaced with `buildResourceLoader()`)
  - `createAgentSession()` return value `extensionsResult` (already destructured in S01)
- New wiring introduced in this slice:
  - `src/resource-loader.ts` wires `src/resources/extensions/*/index.ts` absolute paths into `DefaultResourceLoader.additionalExtensionPaths`
  - `loader.ts` sets `GSD_CODING_AGENT_DIR=~/.gsd/agent/`, `GSD_BIN_PATH=process.argv[1]`, `GSD_WORKFLOW_PATH=<absolute path to bundled GSD-WORKFLOW.md>`, `GSD_BUNDLED_EXTENSION_PATHS=<colon-joined entry points>`
  - First-run AGENTS.md write: `resource-loader.ts` writes bundled AGENTS.md to `~/.gsd/agent/AGENTS.md` if missing
- What remains before the milestone is truly usable end-to-end: S03 (first-run wizard), S04 (npm publish and tarball smoke test)

## Tasks

- [x] **T01: Copy extension sources, agents, and resource files into src/resources/** `est:20m`
  - Why: Establishes the raw source tree that all subsequent tasks patch and wire. No extensions can load until their source files exist in the bundle.
  - Files: `src/resources/extensions/` (all 12 extension directories/files), `src/resources/agents/` (3 .md files), `src/resources/AGENTS.md`, `src/resources/GSD-WORKFLOW.md`
  - Do: Shell script copies each extension directory recursively, excluding gsd/tests/ and browser-tools/node_modules/. Copies single-file extensions (ask-user-questions.ts, get-secrets-from-user.ts) as siblings of shared/. Copies 3 agent .md files and AGENTS.md and GSD-WORKFLOW.md.
  - Verify: `ls src/resources/extensions/gsd/index.ts src/resources/extensions/subagent/index.ts src/resources/extensions/browser-tools/index.ts src/resources/extensions/shared/ui.ts src/resources/agents/scout.md src/resources/AGENTS.md src/resources/GSD-WORKFLOW.md` — all present
  - Done when: All 12 extension entry points exist, layout is flat (gsd/ and shared/ are siblings), agents and resource files are present

- [x] **T02: Apply surgical patches to 5 gsd extension files and subagent/index.ts** `est:30m`
  - Why: Removes all hardcoded `~/.pi/` paths from bundled extension source. Without patches, the bundled gsd extension reads from `~/.pi/` at runtime (wrong location) and subagent spawns `pi` binary (wrong binary / wrong extensions).
  - Files: `src/resources/extensions/gsd/prompt-loader.ts`, `src/resources/extensions/gsd/commands.ts`, `src/resources/extensions/gsd/guided-flow.ts`, `src/resources/extensions/gsd/skill-discovery.ts`, `src/resources/extensions/gsd/preferences.ts`, `src/resources/extensions/subagent/index.ts`
  - Do: Apply 6 targeted patches: (1) prompt-loader.ts: replace hardcoded promptsDir with `join(dirname(fileURLToPath(import.meta.url)), "prompts")`; (2) commands.ts: replace `~/.pi/GSD-WORKFLOW.md` with `process.env.GSD_WORKFLOW_PATH` and replace absolute `/Users/lexchristopherson/.pi/.../templates/preferences.md` with `join(dirname(fileURLToPath(import.meta.url)), "templates", "preferences.md")`; (3) guided-flow.ts: replace `~/.pi/GSD-WORKFLOW.md` with `process.env.GSD_WORKFLOW_PATH`; (4) skill-discovery.ts: replace hardcoded `SKILLS_DIR` with `join(getAgentDir(), "skills")` (import `getAgentDir` from `@mariozechner/pi-coding-agent`); (5) preferences.ts: replace two `~/.pi/agent/skills/` references with `join(getAgentDir(), "skills")`; (6) subagent/index.ts: replace `spawn("pi", args, ...)` with `spawn(process.execPath, [process.env.GSD_BIN_PATH!, ...args], ...)` and inject `--extension <path>` for each path in `GSD_BUNDLED_EXTENSION_PATHS.split(":")`.
  - Verify: `grep -rn '\.pi' src/resources/extensions/gsd/prompt-loader.ts src/resources/extensions/gsd/commands.ts src/resources/extensions/gsd/guided-flow.ts src/resources/extensions/gsd/skill-discovery.ts src/resources/extensions/gsd/preferences.ts` — no matches; `grep 'spawn("pi"' src/resources/extensions/subagent/index.ts` — no matches
  - Done when: Zero hardcoded `~/.pi/` references remain in the 5 patched gsd files; subagent spawns via `process.execPath` with `GSD_BIN_PATH` and `--extension` flags

- [x] **T03: Write src/resource-loader.ts with buildResourceLoader() and first-run AGENTS.md write** `est:30m`
  - Why: This is the wiring layer — it computes absolute paths to bundled extensions and creates the `DefaultResourceLoader` with `additionalExtensionPaths`. Without this, extensions never load. First-run AGENTS.md write ensures spawned subagents find the bundled AGENTS.md automatically.
  - Files: `src/resource-loader.ts`
  - Do: Use `fileURLToPath(import.meta.url)` to compute `resourcesDir = resolve(dirname, '../src/resources')`. Build `extensionEntryPoints` array: one absolute path per extension entry point (all `index.ts` files plus `ask-user-questions.ts` and `get-secrets-from-user.ts`). Return `new DefaultResourceLoader({ agentDir, additionalExtensionPaths: extensionEntryPoints })`. Add `initResources(agentDir)` function that writes bundled AGENTS.md to `${agentDir}/AGENTS.md` if not present (fs.copyFileSync or fs.writeFileSync). Export both `buildResourceLoader` and `initResources`.
  - Verify: `npx tsc --noEmit` exits 0; `node -e "import('./dist/resource-loader.js').then(m => console.log(typeof m.buildResourceLoader))"` prints "function"
  - Done when: `buildResourceLoader()` is exported and type-checks; `initResources()` is exported; compiled output exists in dist/

- [x] **T04: Update loader.ts (4 new env vars) and cli.ts (use buildResourceLoader, log extension errors)** `est:20m`
  - Why: Activates the resource loader and surfaces extension load errors. Without the env vars, patched gsd extension code reads `undefined` from `process.env.GSD_WORKFLOW_PATH`. Without `buildResourceLoader()` in cli.ts, bundled extensions are never passed to `createAgentSession`.
  - Files: `src/loader.ts`, `src/cli.ts`
  - Do: In `loader.ts` before the `await import('./cli.js')` line: (1) set `process.env.GSD_CODING_AGENT_DIR = agentDir` (import from app-paths); (2) set `process.env.GSD_BIN_PATH = process.argv[1]`; (3) compute `GSD_WORKFLOW_PATH` as absolute path to `src/resources/GSD-WORKFLOW.md` using `fileURLToPath(import.meta.url)`; (4) set `GSD_BUNDLED_EXTENSION_PATHS` as colon-joined list of all bundled extension entry point paths (same list used in resource-loader.ts). In `cli.ts`: replace `new DefaultResourceLoader({ agentDir })` with `buildResourceLoader()` (import from `./resource-loader.js`); add `initResources(agentDir)` call before `createAgentSession`; after `createAgentSession`, log any `extensionsResult.errors` to stderr.
  - Verify: `npx tsc --noEmit` exits 0; `grep "GSD_CODING_AGENT_DIR\|GSD_BIN_PATH\|GSD_WORKFLOW_PATH\|GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js` — all four present
  - Done when: Build succeeds; all 4 env vars appear in compiled loader.js; cli.ts imports buildResourceLoader from resource-loader.js

- [x] **T05: Update package.json (playwright dep, src/resources in files) and tsconfig.json (exclude src/resources)** `est:10m` *(absorbed into T03)*
  - Why: Without `playwright` in dependencies, browser-tools' dynamic `import("playwright")` fails at runtime. Without `src/resources` in `files`, npm publish omits the bundled extension source. Without tsconfig exclude, `tsc` tries to compile all 70+ extension `.ts` files and fails.
  - Files: `package.json`, `tsconfig.json`
  - Do: In `package.json`: add `"playwright": "latest"` to `dependencies`; add `"src/resources"` to `files` array. In `tsconfig.json`: add `"exclude": ["src/resources"]`. Run `npm install` to update package-lock.json with playwright.
  - Verify: `node -e "const p=require('./package.json');console.log(p.dependencies.playwright, p.files.includes('src/resources'))"` prints version and `true`; `grep '"exclude"' tsconfig.json`; `npm run build` exits 0
  - Done when: Build exits 0; playwright installed; tsconfig excludes resources; files array includes src/resources

- [x] **T06: Build, launch, and verify all extensions load and tools register** `est:20m`
  - Why: Integration proof — confirms the wiring from T01-T05 actually produces a running `gsd` with all bundled tools available. This is the slice's objective stopping condition.
  - Files: none (verification only)
  - Do: Run `npm run build`. Launch `gsd` briefly and capture output. Check that no extension errors are logged to stderr. Confirm `/gsd` command would be registered (gsd extension loaded), browser tools registered (browser-tools loaded), search tools registered (search-the-web loaded), context7 tools registered, subagent tool registered, bg-shell tools registered. Check `dist/loader.js` for all 4 env vars. Confirm `src/resources/extensions/` has correct layout with no `~/.pi/` leftovers in patched files.
  - Verify: `npm run build` exits 0; `grep -rn '\.pi' src/resources/extensions/gsd/prompt-loader.ts src/resources/extensions/gsd/commands.ts src/resources/extensions/gsd/guided-flow.ts src/resources/extensions/gsd/skill-discovery.ts src/resources/extensions/gsd/preferences.ts` returns nothing; `(node dist/loader.js & sleep 5; kill $!) 2>&1 | grep -i "extension.*error\|error.*extension"` returns nothing (or only unrelated errors)
  - Done when: Build is clean; no extension load errors on launch; patch verification passes for all 5 gsd files and subagent; all 4 env vars confirmed in dist/loader.js

## Files Likely Touched

- `src/resources/extensions/gsd/` (22 .ts files + prompts/ + templates/ + docs/ + package.json)
- `src/resources/extensions/shared/` (5 .ts files)
- `src/resources/extensions/bg-shell/` (index.ts + package.json)
- `src/resources/extensions/browser-tools/` (index.ts + core.js + package.json)
- `src/resources/extensions/context7/` (index.ts + package.json)
- `src/resources/extensions/search-the-web/` (7 .ts files)
- `src/resources/extensions/slash-commands/` (5 .ts files)
- `src/resources/extensions/subagent/` (2 .ts files)
- `src/resources/extensions/worktree/` (index.ts)
- `src/resources/extensions/plan-mode/` (2 .ts files)
- `src/resources/extensions/ask-user-questions.ts`
- `src/resources/extensions/get-secrets-from-user.ts`
- `src/resources/agents/scout.md`
- `src/resources/agents/researcher.md`
- `src/resources/agents/worker.md`
- `src/resources/AGENTS.md`
- `src/resources/GSD-WORKFLOW.md`
- `src/resource-loader.ts` (new)
- `src/loader.ts` (extended with 4 env vars)
- `src/cli.ts` (uses buildResourceLoader, logs extension errors)
- `package.json` (playwright dep, src/resources in files)
- `tsconfig.json` (exclude src/resources)

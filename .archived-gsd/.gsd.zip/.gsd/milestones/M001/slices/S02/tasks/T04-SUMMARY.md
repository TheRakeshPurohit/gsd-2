---
id: T04
parent: S02
milestone: M001
provides:
  - src/loader.ts sets 4 env vars (GSD_CODING_AGENT_DIR, GSD_BIN_PATH, GSD_WORKFLOW_PATH, GSD_BUNDLED_EXTENSION_PATHS) before importing cli.js
  - src/cli.ts uses buildResourceLoader(agentDir) and initResources(agentDir) instead of DefaultResourceLoader
  - src/cli.ts logs extensionsResult.errors to stderr on startup
  - dist/loader.js and dist/cli.js compiled outputs
key_files:
  - src/loader.ts
  - src/cli.ts
key_decisions:
  - extensionsResult.errors shape is { path: string; error: string } (not .message) — task plan said err.message but the actual SDK type is err.error; corrected at implementation time
  - DefaultResourceLoader import removed from cli.ts entirely since buildResourceLoader wraps it
patterns_established:
  - All GSD_ env vars set in loader.ts before dynamic import of cli.js ensures they are visible to all SDK code that runs during session init
  - import.meta.url + fileURLToPath + dirname used in loader.ts (compiled to dist/) to compute ../src/resources relative path — same pattern as resource-loader.ts
observability_surfaces:
  - stderr on gsd startup shows any extension load errors as "[gsd] Extension load error: <err.error>"
  - "node dist/loader.js 2>&1 1>/dev/null | head -20" shows stderr-only output (extension errors without TUI noise)
  - "grep GSD_ dist/loader.js" confirms all 4 env vars are present in compiled output
duration: 15m
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T04: Update loader.ts (4 env vars) and cli.ts (buildResourceLoader, extension error logging)

**Activated the bundled extension system by wiring 4 env vars in loader.ts and swapping DefaultResourceLoader for buildResourceLoader in cli.ts with stderr error logging.**

## What Happened

Two surgical edits made:

**loader.ts**: Added imports for `join` (already had `dirname`, `resolve`, `fileURLToPath`), imported `agentDir` from `./app-paths.js`, then set all 4 env vars before `await import('./cli.js')`:
- `GSD_CODING_AGENT_DIR = agentDir` — redirects pi's `getAgentDir()` to `~/.gsd/agent/`
- `GSD_BIN_PATH = process.argv[1]` — patched subagent uses this to spawn gsd instead of pi
- `GSD_WORKFLOW_PATH = join(resourcesDir, 'GSD-WORKFLOW.md')` — patched gsd extension uses this for workflow dispatch
- `GSD_BUNDLED_EXTENSION_PATHS = extensionEntryPoints.join(':')` — 11 entry points (no shared/), used by patched subagent for `--extension` flags

`resourcesDir` computed via `resolve(dirname(fileURLToPath(import.meta.url)), '..', 'src', 'resources')` — identical pattern to resource-loader.ts, correct for dist/loader.js → ../src/resources.

**cli.ts**: Removed `DefaultResourceLoader` import (no longer needed), added `buildResourceLoader` and `initResources` from `./resource-loader.js`. Replaced `new DefaultResourceLoader({ agentDir })` with `initResources(agentDir); const resourceLoader = buildResourceLoader(agentDir)`. Destructured `extensionsResult` from `createAgentSession` and added stderr logging loop.

Type correction: The task plan said `err.message` but `LoadExtensionsResult.errors` shape is `Array<{ path: string; error: string }>`. Used `err.error` to match the actual SDK type.

## Verification

```
npx tsc --noEmit        → 0 errors
npm run build           → clean (tsc + copy-themes)

grep -c "GSD_CODING_AGENT_DIR|GSD_BIN_PATH|GSD_WORKFLOW_PATH|GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js
→ 8 (each var appears twice: comment + assignment)

grep "GSD_CODING_AGENT_DIR" dist/loader.js  → present ✓
grep "GSD_BIN_PATH" dist/loader.js          → present ✓
grep "GSD_WORKFLOW_PATH" dist/loader.js     → present ✓
grep "GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js → present ✓

grep "buildResourceLoader|initResources" dist/cli.js
→ import line, initResources(agentDir), buildResourceLoader(agentDir) ✓

grep "extensionsResult|Extension load error" dist/cli.js
→ destructuring, error check, stderr write loop ✓
```

## Diagnostics

- `grep GSD_ dist/loader.js` — confirms all 4 env vars set before cli.js load
- `node dist/loader.js 2>&1 1>/dev/null | head -20` — stderr-only output shows extension load errors (if any) without TUI noise
- Extension errors surface as: `[gsd] Extension load error: <err.error>` where `err.error` is the jiti compilation error, missing module, or tool registration failure message

## Deviations

- Task plan said `err.message` for extension error logging; actual SDK type `LoadExtensionsResult.errors` uses `err.error` (shape: `{ path: string; error: string }`). Used `err.error` to match the real type.

## Known Issues

none

## Files Created/Modified

- `src/loader.ts` — Added 4 GSD_ env var assignments and import of agentDir from app-paths.js; added join to path imports
- `src/cli.ts` — Replaced DefaultResourceLoader with buildResourceLoader+initResources, added extensionsResult destructuring and stderr error logging
- `dist/loader.js` — Compiled output
- `dist/cli.js` — Compiled output

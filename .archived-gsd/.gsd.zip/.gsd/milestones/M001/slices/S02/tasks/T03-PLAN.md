---
estimated_steps: 5
estimated_files: 1
---

# T03: Write src/resource-loader.ts with buildResourceLoader() and initResources()

**Slice:** S02 — Bundle Extensions and Agents
**Milestone:** M001

## Description

`src/resource-loader.ts` is the wiring layer that connects bundled extension sources to pi's `DefaultResourceLoader`. It exports two functions:

- `buildResourceLoader()` — constructs a `DefaultResourceLoader` with `additionalExtensionPaths` set to the absolute paths of all bundled extension entry points. This is what `cli.ts` calls instead of `new DefaultResourceLoader({ agentDir })`.
- `initResources(agentDir: string)` — writes bundled AGENTS.md to `${agentDir}/AGENTS.md` if the file doesn't already exist. This ensures spawned subagents find the hard rules document via pi's normal `loadProjectContextFiles` walk.

The key constraint: paths must be computed using `fileURLToPath(import.meta.url)` so they resolve correctly from the compiled `dist/resource-loader.js` location. The `src/resources/` directory is a sibling of `src/` at the project root, so the path from `dist/resource-loader.js` is `../src/resources`.

## Steps

1. Compute `resourcesDir` using `fileURLToPath(import.meta.url)`: `const resourcesDir = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'src', 'resources')`. This works because `dist/resource-loader.js` is one level below the project root, and `src/resources` is also one level below.

2. Define `EXTENSION_ENTRY_POINTS` array: absolute paths to all 11 extension entry points (shared/ is a library, not an entry point — it's imported by gsd and ask-user-questions.ts, not registered independently):
   - `extensions/gsd/index.ts`
   - `extensions/bg-shell/index.ts`
   - `extensions/browser-tools/index.ts`
   - `extensions/context7/index.ts`
   - `extensions/search-the-web/index.ts`
   - `extensions/slash-commands/index.ts`
   - `extensions/subagent/index.ts`
   - `extensions/worktree/index.ts`
   - `extensions/plan-mode/index.ts`
   - `extensions/ask-user-questions.ts`
   - `extensions/get-secrets-from-user.ts`
   
   All paths are `join(resourcesDir, 'extensions', '<relative>')`.

3. Export `buildResourceLoader(agentDir: string)`: returns `new DefaultResourceLoader({ agentDir, additionalExtensionPaths: EXTENSION_ENTRY_POINTS })`.

4. Export `initResources(agentDir: string)`: checks if `join(agentDir, 'AGENTS.md')` exists using `existsSync`. If not, creates the directory with `mkdirSync(agentDir, { recursive: true })` then copies the bundled `src/resources/AGENTS.md` to `${agentDir}/AGENTS.md` using `copyFileSync`. This is a one-time write on first launch.

5. Add appropriate TypeScript types and imports: `DefaultResourceLoader` from `@mariozechner/pi-coding-agent`; `fileURLToPath` from `node:url`; `dirname`, `resolve`, `join` from `node:path`; `existsSync`, `mkdirSync`, `copyFileSync` from `node:fs`.

## Must-Haves

- [ ] `buildResourceLoader(agentDir)` is exported and returns a `DefaultResourceLoader` instance
- [ ] `additionalExtensionPaths` includes all 12 extension entry points as absolute paths
- [ ] `initResources(agentDir)` is exported and copies bundled AGENTS.md to `${agentDir}/AGENTS.md` on first launch
- [ ] `initResources` uses `existsSync` check — does NOT overwrite if AGENTS.md already exists
- [ ] All paths computed via `fileURLToPath(import.meta.url)` — no hardcoded absolute paths
- [ ] File type-checks cleanly (`npx tsc --noEmit` exits 0)
- [ ] Compiled output exists at `dist/resource-loader.js` after build

## Verification

```bash
# Type check passes
npx tsc --noEmit

# Compiled output exists after build
npm run build && ls dist/resource-loader.js

# buildResourceLoader is exported
node --input-type=module -e "
  import { buildResourceLoader } from './dist/resource-loader.js';
  console.log(typeof buildResourceLoader);
"
# Prints: function

# initResources is exported
node --input-type=module -e "
  import { initResources } from './dist/resource-loader.js';
  console.log(typeof initResources);
"
# Prints: function

# resourcesDir resolves to the correct absolute path
node --input-type=module -e "
  import { fileURLToPath } from 'node:url';
  import { dirname, resolve } from 'node:path';
  const dir = resolve(dirname(fileURLToPath(import.meta.url)), 'src', 'resources');
  import('node:fs').then(fs => console.log(fs.existsSync(dir) ? 'OK' : 'FAIL: ' + dir));
"
# Prints: OK
```

## Observability Impact

- Signals added/changed: `initResources()` writes to `~/.gsd/agent/AGENTS.md` on first launch — inspectable via `ls ~/.gsd/agent/AGENTS.md` after first `gsd` run
- How a future agent inspects this: `grep additionalExtensionPaths dist/resource-loader.js` — shows the paths being registered; `ls ~/.gsd/agent/AGENTS.md` — confirms first-run write happened
- Failure state exposed: If `buildResourceLoader()` throws, it's because an extension path doesn't exist (ENOENT from DefaultResourceLoader init) — the path is in the error, pointing back to the copy step in T01

## Inputs

- `src/app-paths.ts` — `agentDir` type shape (function receives it as parameter)
- `src/resources/extensions/` — must exist (T01 output) so path joins produce valid paths
- `src/resources/AGENTS.md` — must exist (T01 output) for initResources to copy it
- D004 (DECISIONS.md) — confirms `additionalExtensionPaths` is the correct API for loading bundled extensions

## Expected Output

- `src/resource-loader.ts` — new file, ~50 lines, exports `buildResourceLoader(agentDir: string)` and `initResources(agentDir: string)`
- `dist/resource-loader.js` — compiled output (after `npm run build`)
- Zero TypeScript errors

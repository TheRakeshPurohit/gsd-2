---
estimated_steps: 4
estimated_files: 2
---

# T04: Update loader.ts (4 env vars) and cli.ts (buildResourceLoader, extension error logging)

**Slice:** S02 — Bundle Extensions and Agents
**Milestone:** M001

## Description

Two surgical edits activate the bundled extension system:

**`loader.ts`** needs four new environment variables set before `cli.js` loads:
1. `GSD_CODING_AGENT_DIR` — tells pi's `getAgentDir()` to return `~/.gsd/agent/` instead of `~/.pi/agent/`
2. `GSD_BIN_PATH` — the absolute path to `dist/loader.js` (= `process.argv[1]`), used by patched subagent to spawn gsd instead of pi
3. `GSD_WORKFLOW_PATH` — absolute path to the bundled `src/resources/GSD-WORKFLOW.md`, used by patched gsd extension when dispatching workflow prompts
4. `GSD_BUNDLED_EXTENSION_PATHS` — colon-joined list of all 12 bundled extension entry point absolute paths, used by patched subagent to pass `--extension <path>` to spawned gsd processes

`GSD_WORKFLOW_PATH` and `GSD_BUNDLED_EXTENSION_PATHS` must be computed using `fileURLToPath(import.meta.url)` in loader.ts (compiled to `dist/loader.js`), so the path from dist/ to `src/resources/` is `../src/resources/`.

**`cli.ts`** needs two changes:
1. Replace `new DefaultResourceLoader({ agentDir })` with `buildResourceLoader(agentDir)` (import from `./resource-loader.js`)
2. Add `initResources(agentDir)` call before `createAgentSession`
3. After `createAgentSession`, log any `extensionsResult.errors` to stderr so failed extensions are visible (R009)

## Steps

1. **Update `loader.ts`**: Import `fileURLToPath` and `dirname`, `resolve`, `join` from node builtins. Import `agentDir` from `./app-paths.js`. After the existing `process.env.PI_PACKAGE_DIR = pkgDir` and `process.title = 'gsd'` lines, add:
   ```ts
   import { agentDir } from './app-paths.js'
   // ...
   process.env.GSD_CODING_AGENT_DIR = agentDir
   process.env.GSD_BIN_PATH = process.argv[1]
   const resourcesDir = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'src', 'resources')
   process.env.GSD_WORKFLOW_PATH = join(resourcesDir, 'GSD-WORKFLOW.md')
   const extensionEntryPoints = [
     'extensions/gsd/index.ts',
     'extensions/bg-shell/index.ts',
     'extensions/browser-tools/index.ts',
     'extensions/context7/index.ts',
     'extensions/search-the-web/index.ts',
     'extensions/slash-commands/index.ts',
     'extensions/subagent/index.ts',
     'extensions/worktree/index.ts',
     'extensions/plan-mode/index.ts',
     'extensions/ask-user-questions.ts',
     'extensions/get-secrets-from-user.ts',
   ].map(rel => join(resourcesDir, rel))
   process.env.GSD_BUNDLED_EXTENSION_PATHS = extensionEntryPoints.join(':')
   ```
   Note: `shared/` is NOT in `GSD_BUNDLED_EXTENSION_PATHS` because it's not an extension entry point — it's imported by gsd and ask-user-questions as a library. Only extension entry points (those with `index.ts` or standalone `.ts` files that register tools) go here.

2. **Update `cli.ts`**: Add import `import { buildResourceLoader, initResources } from './resource-loader.js'`. Remove `import { DefaultResourceLoader } from '@mariozechner/pi-coding-agent'` if it's only used for the resource loader construction (check if it's used elsewhere first). Replace `const resourceLoader = new DefaultResourceLoader({ agentDir })` with `initResources(agentDir); const resourceLoader = buildResourceLoader(agentDir)`.

3. **Update `cli.ts` extension error logging**: Change the destructuring from `const { session } = await createAgentSession(...)` to `const { session, extensionsResult } = await createAgentSession(...)`. After the call, add:
   ```ts
   if (extensionsResult.errors.length > 0) {
     for (const err of extensionsResult.errors) {
       process.stderr.write(`[gsd] Extension load error: ${err.message}\n`)
     }
   }
   ```

4. Run `npx tsc --noEmit` and fix any type errors.

## Must-Haves

- [ ] `loader.ts` sets `GSD_CODING_AGENT_DIR` to `agentDir` from app-paths
- [ ] `loader.ts` sets `GSD_BIN_PATH` to `process.argv[1]`
- [ ] `loader.ts` sets `GSD_WORKFLOW_PATH` to absolute path of bundled GSD-WORKFLOW.md
- [ ] `loader.ts` sets `GSD_BUNDLED_EXTENSION_PATHS` to colon-joined extension entry point paths (no shared/)
- [ ] All 4 env vars are set BEFORE `await import('./cli.js')`
- [ ] `cli.ts` calls `initResources(agentDir)` before `createAgentSession`
- [ ] `cli.ts` calls `buildResourceLoader(agentDir)` instead of `new DefaultResourceLoader`
- [ ] `cli.ts` logs `extensionsResult.errors` to stderr if any exist
- [ ] `npx tsc --noEmit` exits 0

## Verification

```bash
# Type check
npx tsc --noEmit

# Build
npm run build

# All 4 env vars in compiled loader.js
grep -c "GSD_CODING_AGENT_DIR\|GSD_BIN_PATH\|GSD_WORKFLOW_PATH\|GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js
# Should print 4 (or more if variable names appear multiple times)

# Each specific var present
grep "GSD_CODING_AGENT_DIR" dist/loader.js
grep "GSD_BIN_PATH" dist/loader.js
grep "GSD_WORKFLOW_PATH" dist/loader.js
grep "GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js

# cli.js uses buildResourceLoader
grep "buildResourceLoader\|initResources" dist/cli.js

# cli.js logs extension errors
grep "extensionsResult\|Extension load error" dist/cli.js
```

## Observability Impact

- Signals added/changed: `extensionsResult.errors` are now logged to stderr on startup — any extension that fails to load (compilation error, import failure, tool registration failure) prints to stderr with its error message. Previously silent.
- How a future agent inspects this: `node dist/loader.js 2>&1 1>/dev/null | head -20` — stderr-only output shows extension errors without interactive TUI noise
- Failure state exposed: Extension failures name the problematic file and error. Missing env var failures (`GSD_WORKFLOW_PATH undefined`) are caught early in extension code rather than failing silently later.

## Inputs

- `src/loader.ts` — S01 output, needs 4 new env vars added before cli.js import
- `src/cli.ts` — S01 output, needs buildResourceLoader swap and error logging
- `src/resource-loader.ts` — T03 output, provides `buildResourceLoader` and `initResources`
- `src/app-paths.ts` — provides `agentDir` constant for import in loader.ts

## Expected Output

- `src/loader.ts` — extended with 4 new `process.env` assignments and computed paths
- `src/cli.ts` — uses `buildResourceLoader(agentDir)`, calls `initResources(agentDir)`, logs `extensionsResult.errors`
- `dist/loader.js`, `dist/cli.js` — compiled outputs
- Zero TypeScript errors

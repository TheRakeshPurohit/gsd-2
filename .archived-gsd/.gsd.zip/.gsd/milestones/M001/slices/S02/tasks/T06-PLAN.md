---
estimated_steps: 5
estimated_files: 0
---

# T06: Build, launch, and verify all extensions load and tools register

**Slice:** S02 — Bundle Extensions and Agents
**Milestone:** M001

## Description

Integration proof task. Runs a complete build, launches `gsd`, and verifies that all bundled extensions loaded without errors and their tools are available. This task produces no new files — it only exercises and validates the system assembled in T01-T05.

This is the slice's objective stopping condition: if every check passes, S02 is complete.

## Steps

1. **Run full build** and confirm exit 0: `npm run build`.

2. **Verify build artifacts and env vars** in compiled output:
   - `dist/loader.js` contains all 4 GSD env vars
   - `dist/cli.js` contains `buildResourceLoader` and `extensionsResult`
   - `dist/resource-loader.js` exists

3. **Verify patch integrity** — confirm no `~/.pi/` leaks remain in patched files and subagent patches are in place.

4. **Launch `gsd` and capture stderr** to check for extension load errors: `(node dist/loader.js & sleep 6; kill $!) 2>&1`. Extension load errors are printed to stderr via the T04 logging added to cli.ts. Any `[gsd] Extension load error:` lines indicate a failed extension.

5. **Verify first-run AGENTS.md write** happened: `ls ~/.gsd/agent/AGENTS.md` — should exist after first launch (created by `initResources` in resource-loader.ts).

## Must-Haves

- [ ] `npm run build` exits 0
- [ ] `dist/resource-loader.js` exists
- [ ] All 4 GSD env vars present in `dist/loader.js`
- [ ] `buildResourceLoader` and `extensionsResult` appear in `dist/cli.js`
- [ ] No `~/.pi/` references in patched gsd extension files (prompt-loader, commands, guided-flow, skill-discovery, preferences)
- [ ] No `spawn("pi"` in bundled subagent/index.ts
- [ ] No `[gsd] Extension load error:` lines in launch stderr output
- [ ] `~/.gsd/agent/AGENTS.md` exists after launch (first-run write)
- [ ] `src/resources/extensions/` structure confirmed (gsd/ and shared/ are siblings, ask-user-questions.ts is sibling of shared/)

## Verification

```bash
# 1. Clean build
npm run build
echo "Build exit code: $?"

# 2. dist artifacts
ls dist/loader.js dist/cli.js dist/resource-loader.js dist/app-paths.js

# 3. Env vars in compiled loader
grep "GSD_CODING_AGENT_DIR\|GSD_BIN_PATH\|GSD_WORKFLOW_PATH\|GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js | wc -l
# Expect: 4+

# 4. cli.js wiring
grep "buildResourceLoader\|extensionsResult\|Extension load error" dist/cli.js

# 5. Patch integrity checks
echo "--- Patch verification ---"
grep -l '\.pi/agent/extensions/gsd/prompts\|\.pi/GSD-WORKFLOW\|\.pi.*skills' \
  src/resources/extensions/gsd/prompt-loader.ts \
  src/resources/extensions/gsd/commands.ts \
  src/resources/extensions/gsd/guided-flow.ts \
  src/resources/extensions/gsd/skill-discovery.ts \
  src/resources/extensions/gsd/preferences.ts 2>/dev/null \
  && echo "FAIL: ~/.pi/ refs still present" || echo "OK: no ~/.pi/ refs in patched files"

grep -l 'spawn("pi"' src/resources/extensions/subagent/index.ts 2>/dev/null \
  && echo "FAIL: subagent still spawns pi" || echo "OK: subagent patched"

# 6. Launch and check for extension errors (capture stderr)
LAUNCH_OUTPUT=$((node dist/loader.js & sleep 6; kill $!) 2>&1)
echo "$LAUNCH_OUTPUT" | grep "\[gsd\] Extension load error" \
  && echo "FAIL: extension errors detected" \
  || echo "OK: no extension load errors"

# Show gsd branding still works (regression check from S01)
echo "$LAUNCH_OUTPUT" | strings | grep -c "gsd"
# Expect: 3+ (confirms branding still intact after S02 changes)

# 7. AGENTS.md first-run write
ls -la ~/.gsd/agent/AGENTS.md && echo "OK: AGENTS.md written" || echo "FAIL: AGENTS.md missing"

# 8. Extension layout
ls src/resources/extensions/ | grep -E "^(gsd|shared|bg-shell|browser-tools|context7|search-the-web|slash-commands|subagent|worktree|plan-mode)$" | wc -l
# Expect: 10 (all directory extensions)
ls src/resources/extensions/ask-user-questions.ts src/resources/extensions/get-secrets-from-user.ts
# Both present as siblings of shared/
```

## Observability Impact

- Signals added/changed: This task validates the observability surfaces added in T04 — specifically that `extensionsResult.errors` logging works and produces zero errors with the bundled extensions.
- How a future agent inspects this: If re-running S02 or debugging extension issues, run `(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "Extension load error"` — zero matches = all extensions loaded. Any match identifies the specific extension that failed by its file path.
- Failure state exposed: Extension failures surface as named-path errors in stderr. Layout failures surface as import resolution errors (missing module at `../shared/ui.js`). Patch failures surface as readFileSync errors on `~/.pi/` paths.

## Inputs

- All T01-T05 outputs: `src/resources/` tree, patched extension files, `dist/resource-loader.js`, `dist/loader.js`, `dist/cli.js`
- `~/.gsd/agent/` — must exist (created by S01 gsd launch) for `initResources` to write AGENTS.md

## Expected Output

- All verification checks pass
- No new files produced — this task validates existing outputs
- S02 slice is complete: `/gsd`, browser tools, search, context7, subagent, and bg-shell tools are all available when `gsd` runs
- `~/.gsd/agent/AGENTS.md` written on first launch
- Requirements R003, R004, R005, R009 advanced

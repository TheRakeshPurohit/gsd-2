---
id: T01
parent: S02
milestone: M001
provides:
  - src/resources/extensions/ populated with all 10 directory extensions and 2 single-file extensions
  - src/resources/agents/ populated with scout.md, researcher.md, worker.md
  - src/resources/AGENTS.md and src/resources/GSD-WORKFLOW.md copied
key_files:
  - src/resources/extensions/gsd/index.ts
  - src/resources/extensions/shared/ui.ts
  - src/resources/extensions/shared/interview-ui.ts
  - src/resources/extensions/shared/next-action-ui.ts
  - src/resources/extensions/browser-tools/index.ts
  - src/resources/extensions/ask-user-questions.ts
  - src/resources/extensions/get-secrets-from-user.ts
  - src/resources/agents/scout.md
  - src/resources/AGENTS.md
  - src/resources/GSD-WORKFLOW.md
key_decisions:
  - rsync used with --exclude flags to cleanly omit gsd/tests/ and browser-tools/node_modules/ without risk of partial copies
  - Flat sibling layout preserved: gsd/ and shared/ are direct children of extensions/, as are ask-user-questions.ts and get-secrets-from-user.ts
patterns_established:
  - rsync -a for directory copies (preserves timestamps, symlinks, permissions)
  - Single-file extensions copied with cp directly as siblings of shared/ to maintain cross-extension import paths
observability_surfaces:
  - ls src/resources/extensions/*/index.ts — confirms all extension entry points exist
  - find src/resources -name "*.ts" | wc -l — total TypeScript file count
  - ls src/resources/extensions/gsd/prompts/ | wc -l — prompt count (22)
  - ls src/resources/extensions/gsd/templates/ | wc -l — template count (16)
duration: 5m
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T01: Copy extension sources, agents, and resource files into src/resources/

**Copied all 12 extensions, 3 agents, and 2 resource files into src/resources/ with correct flat sibling layout and exclusions applied.**

## What Happened

Created `src/resources/extensions/` and `src/resources/agents/` directories, then:

1. Used `rsync -a --exclude='tests/'` to copy `gsd/` — preserves all subdirs (prompts/, templates/, docs/) while excluding tests/
2. Used `rsync -a --exclude='node_modules/' --exclude='tests/'` to copy `browser-tools/` — excludes node_modules and tests
3. Used plain `rsync -a` for the remaining 8 directory extensions: shared/, bg-shell/, context7/, search-the-web/, slash-commands/, subagent/, worktree/, plan-mode/
4. Used `cp` for the 2 single-file extensions: `ask-user-questions.ts` and `get-secrets-from-user.ts` — placed as direct siblings of shared/ in extensions/
5. Copied 3 agent .md files and 2 resource docs

The flat sibling layout is intact: `gsd/auto.ts` can import `../shared/ui.js`, and `ask-user-questions.ts` can import `./shared/interview-ui.js`.

## Verification

All task plan verification checks passed:

```
# All 13 entry points present — all ls'd cleanly
src/resources/extensions/gsd/index.ts
src/resources/extensions/shared/ui.ts
src/resources/extensions/bg-shell/index.ts
src/resources/extensions/browser-tools/index.ts
src/resources/extensions/browser-tools/core.js
src/resources/extensions/context7/index.ts
src/resources/extensions/search-the-web/index.ts
src/resources/extensions/slash-commands/index.ts
src/resources/extensions/subagent/index.ts
src/resources/extensions/worktree/index.ts
src/resources/extensions/plan-mode/index.ts
src/resources/extensions/ask-user-questions.ts
src/resources/extensions/get-secrets-from-user.ts

# Exclusions confirmed
OK: no gsd tests
OK: no bt node_modules

# Cross-extension imports
src/resources/extensions/shared/ui.ts ✓
src/resources/extensions/shared/next-action-ui.ts ✓
src/resources/extensions/shared/interview-ui.ts ✓

# Agents and docs
src/resources/agents/scout.md ✓
src/resources/agents/researcher.md ✓
src/resources/agents/worker.md ✓
src/resources/AGENTS.md ✓
src/resources/GSD-WORKFLOW.md ✓

# gsd subdirs
prompts/: 22 files (> 10) ✓
templates/: 16 files (> 10) ✓
docs/: exists ✓
```

## Diagnostics

- `ls src/resources/extensions/*/index.ts` — verify all extension entry points exist
- `find src/resources -name "*.ts" | wc -l` — total TS source count in bundle
- `ls src/resources/extensions/gsd/prompts/ | wc -l` — should be 22
- `ls src/resources/extensions/gsd/templates/ | wc -l` — should be 16
- If an extension fails to load in T06, first check: `ls src/resources/extensions/<name>/index.ts`

## Deviations

None. All steps executed as written in the task plan.

## Known Issues

None.

## Files Created/Modified

- `src/resources/extensions/gsd/` — full gsd extension (minus tests/), including prompts/, templates/, docs/
- `src/resources/extensions/shared/` — shared UI utilities (ui.ts, interview-ui.ts, next-action-ui.ts, etc.)
- `src/resources/extensions/bg-shell/` — bg-shell extension
- `src/resources/extensions/browser-tools/` — browser-tools extension (minus node_modules/, tests/)
- `src/resources/extensions/context7/` — context7 extension
- `src/resources/extensions/search-the-web/` — search-the-web extension
- `src/resources/extensions/slash-commands/` — slash-commands extension
- `src/resources/extensions/subagent/` — subagent extension
- `src/resources/extensions/worktree/` — worktree extension
- `src/resources/extensions/plan-mode/` — plan-mode extension
- `src/resources/extensions/ask-user-questions.ts` — single-file extension (sibling of shared/)
- `src/resources/extensions/get-secrets-from-user.ts` — single-file extension (sibling of shared/)
- `src/resources/agents/scout.md` — scout agent definition
- `src/resources/agents/researcher.md` — researcher agent definition
- `src/resources/agents/worker.md` — worker agent definition
- `src/resources/AGENTS.md` — bundled agent context rules
- `src/resources/GSD-WORKFLOW.md` — GSD workflow protocol document

---
estimated_steps: 5
estimated_files: 40
---

# T01: Copy extension sources, agents, and resource files into src/resources/

**Slice:** S02 — Bundle Extensions and Agents
**Milestone:** M001

## Description

Copy all pi extension source files into `src/resources/extensions/`, maintaining the flat sibling layout that cross-extension imports depend on. Copy agent .md files into `src/resources/agents/`. Copy AGENTS.md and GSD-WORKFLOW.md to `src/resources/`. Do NOT copy gsd/tests/ or browser-tools/node_modules/. This task produces the raw source tree — no patches yet.

The flat layout is mandatory: `gsd/auto.ts` imports `../shared/ui.js`, and `ask-user-questions.ts` imports `./shared/interview-ui.js`. Both only work if `gsd/` and `shared/` are siblings under `extensions/`, and `ask-user-questions.ts` is a sibling of `shared/`.

## Steps

1. Create `src/resources/extensions/` and `src/resources/agents/` directories (mkdir -p).
2. Copy each directory-type extension from `~/.pi/agent/extensions/`: `gsd/` (exclude `tests/`), `shared/`, `bg-shell/`, `browser-tools/` (exclude `node_modules/` and `tests/`), `context7/`, `search-the-web/`, `slash-commands/`, `subagent/`, `worktree/`, `plan-mode/`.
3. Copy single-file extensions to `src/resources/extensions/` as direct siblings: `ask-user-questions.ts`, `get-secrets-from-user.ts`.
4. Copy agent files: `~/.pi/agent/agents/scout.md`, `researcher.md`, `worker.md` → `src/resources/agents/`.
5. Copy resource files: `~/.pi/AGENTS.md` → `src/resources/AGENTS.md`; `~/.pi/GSD-WORKFLOW.md` → `src/resources/GSD-WORKFLOW.md`.

## Must-Haves

- [ ] `src/resources/extensions/gsd/index.ts` exists
- [ ] `src/resources/extensions/gsd/prompts/` directory exists (required by prompt-loader.ts)
- [ ] `src/resources/extensions/gsd/templates/` directory exists (required by commands.ts)
- [ ] `src/resources/extensions/gsd/docs/` directory exists
- [ ] `src/resources/extensions/shared/ui.ts` exists (required by gsd/auto.ts cross-extension import)
- [ ] `src/resources/extensions/shared/next-action-ui.ts` exists (required by gsd/guided-flow.ts)
- [ ] `src/resources/extensions/shared/interview-ui.ts` exists (required by ask-user-questions.ts)
- [ ] `src/resources/extensions/ask-user-questions.ts` is a direct child of `src/resources/extensions/` (sibling of `shared/`)
- [ ] `src/resources/extensions/get-secrets-from-user.ts` is a direct child of `src/resources/extensions/`
- [ ] `src/resources/extensions/browser-tools/index.ts` exists; `src/resources/extensions/browser-tools/core.js` exists
- [ ] `src/resources/extensions/browser-tools/node_modules/` does NOT exist
- [ ] `src/resources/extensions/gsd/tests/` does NOT exist
- [ ] `src/resources/agents/scout.md` exists
- [ ] `src/resources/agents/researcher.md` exists
- [ ] `src/resources/agents/worker.md` exists
- [ ] `src/resources/AGENTS.md` exists
- [ ] `src/resources/GSD-WORKFLOW.md` exists

## Verification

```bash
# All extension entry points present
ls src/resources/extensions/gsd/index.ts \
   src/resources/extensions/shared/ui.ts \
   src/resources/extensions/bg-shell/index.ts \
   src/resources/extensions/browser-tools/index.ts \
   src/resources/extensions/browser-tools/core.js \
   src/resources/extensions/context7/index.ts \
   src/resources/extensions/search-the-web/index.ts \
   src/resources/extensions/slash-commands/index.ts \
   src/resources/extensions/subagent/index.ts \
   src/resources/extensions/worktree/index.ts \
   src/resources/extensions/plan-mode/index.ts \
   src/resources/extensions/ask-user-questions.ts \
   src/resources/extensions/get-secrets-from-user.ts

# Cross-extension import layout preserved
ls src/resources/extensions/gsd/ && ls src/resources/extensions/shared/

# Excluded dirs NOT present
[ ! -d src/resources/extensions/gsd/tests ] && echo "OK: no gsd tests" || echo "FAIL: gsd tests present"
[ ! -d src/resources/extensions/browser-tools/node_modules ] && echo "OK: no bt node_modules" || echo "FAIL: bt node_modules present"

# Agents and resource files
ls src/resources/agents/scout.md src/resources/agents/researcher.md src/resources/agents/worker.md
ls src/resources/AGENTS.md src/resources/GSD-WORKFLOW.md

# gsd prompts and templates copied
ls src/resources/extensions/gsd/prompts/ | wc -l   # should be > 10
ls src/resources/extensions/gsd/templates/ | wc -l  # should be > 10
```

## Observability Impact

- Signals added/changed: None — this task only copies files to disk
- How a future agent inspects this: `ls src/resources/extensions/` and `find src/resources -name "*.ts" | wc -l` shows what was copied
- Failure state exposed: If an extension fails to load in T06, the first thing to check is whether its source files exist here

## Inputs

- `~/.pi/agent/extensions/` — all extension source directories and files
- `~/.pi/agent/agents/` — scout.md, researcher.md, worker.md
- `~/.pi/AGENTS.md` — bundled agent context rules
- `~/.pi/GSD-WORKFLOW.md` — workflow protocol document
- `src/app-paths.ts` — confirms agentDir is `~/.gsd/agent` (no input needed directly, just context)

## Expected Output

- `src/resources/extensions/` populated with all 10 directory extensions and 2 single-file extensions
- `src/resources/agents/` populated with 3 agent .md files
- `src/resources/AGENTS.md` — bundled AGENTS.md
- `src/resources/GSD-WORKFLOW.md` — bundled workflow document
- No tests/, no node_modules/ in extension copies
- Cross-extension import layout intact (gsd/ and shared/ are siblings)

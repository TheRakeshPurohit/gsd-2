---
estimated_steps: 6
estimated_files: 6
---

# T02: Apply surgical patches to bundled gsd extension and subagent

**Slice:** S02 — Bundle Extensions and Agents
**Milestone:** M001

## Description

Six files in the copied extension sources contain hardcoded `~/.pi/` paths or spawn the wrong binary. This task patches each one surgically. After patching, all six files read from env vars or use `import.meta.url`-relative paths at runtime, and subagent spawns the `gsd` process (not `pi`) with bundled extension flags.

Five patches target the bundled gsd extension:
- `prompt-loader.ts` — replaces hardcoded promptsDir with `import.meta.url`-relative path
- `commands.ts` — replaces `~/.pi/GSD-WORKFLOW.md` with `process.env.GSD_WORKFLOW_PATH` and absolute preferences template path with `import.meta.url`-relative path
- `guided-flow.ts` — replaces `~/.pi/GSD-WORKFLOW.md` with `process.env.GSD_WORKFLOW_PATH`
- `skill-discovery.ts` — replaces hardcoded `SKILLS_DIR` with `join(getAgentDir(), "skills")`
- `preferences.ts` — replaces two `~/.pi/agent/skills/` references with `join(getAgentDir(), "skills")`

One patch targets the bundled subagent:
- `subagent/index.ts` — replaces `spawn("pi", args, ...)` with `spawn(process.execPath, [process.env.GSD_BIN_PATH!, ...args], ...)` and prepends `--extension <path>` args for each path in `GSD_BUNDLED_EXTENSION_PATHS`

## Steps

1. **Patch prompt-loader.ts**: Replace the module-level `promptsDir` constant. Old: `const promptsDir = join(homedir(), ".pi", "agent", "extensions", "gsd", "prompts")`. New: add `import { fileURLToPath } from "node:url"; import { dirname } from "node:path";` if not already present, then `const promptsDir = join(dirname(fileURLToPath(import.meta.url)), "prompts")`. Remove the `homedir` import if it becomes unused.

2. **Patch commands.ts**: (a) Find the `dispatchDoctorHeal` function where `workflowPath` is constructed — replace `join(process.env.HOME ?? "~", ".pi", "GSD-WORKFLOW.md")` with `process.env.GSD_WORKFLOW_PATH ?? join(process.env.HOME ?? "~", ".pi", "GSD-WORKFLOW.md")`. (b) Find the `loadFile("/Users/lexchristopherson/.pi/agent/extensions/gsd/templates/preferences.md")` call — add `import { fileURLToPath } from "node:url"; import { dirname } from "node:path";` if needed, then replace with `loadFile(join(dirname(fileURLToPath(import.meta.url)), "templates", "preferences.md"))`.

3. **Patch guided-flow.ts**: Find `const workflowPath = join(process.env.HOME ?? "~", ".pi", "GSD-WORKFLOW.md")` — replace with `const workflowPath = process.env.GSD_WORKFLOW_PATH ?? join(process.env.HOME ?? "~", ".pi", "GSD-WORKFLOW.md")`.

4. **Patch skill-discovery.ts**: Add import `import { getAgentDir } from "@mariozechner/pi-coding-agent"`. Replace `const SKILLS_DIR = join(homedir(), ".pi", "agent", "skills")` with `const SKILLS_DIR = join(getAgentDir(), "skills")`. Remove `homedir` import if it becomes unused.

5. **Patch preferences.ts**: Add import `import { getAgentDir } from "@mariozechner/pi-coding-agent"` at top. Replace both occurrences of `join(homedir(), ".pi", "agent", "skills")` with `join(getAgentDir(), "skills")`. Remove `homedir` import if it becomes unused (check if it's still used elsewhere in preferences.ts — it is used for GLOBAL_PREFERENCES_PATH, so keep it).

6. **Patch subagent/index.ts**: Find `const proc = spawn("pi", args, { cwd: cwd ?? defaultCwd, shell: false, stdio: ["ignore", "pipe", "pipe"] })`. Replace with:
   ```ts
   const bundledPaths = (process.env.GSD_BUNDLED_EXTENSION_PATHS ?? "").split(":").filter(Boolean);
   const extensionArgs = bundledPaths.flatMap(p => ["--extension", p]);
   const proc = spawn(
     process.execPath,
     [process.env.GSD_BIN_PATH!, ...extensionArgs, ...args],
     { cwd: cwd ?? defaultCwd, shell: false, stdio: ["ignore", "pipe", "pipe"] }
   );
   ```

## Must-Haves

- [ ] `prompt-loader.ts` uses `dirname(fileURLToPath(import.meta.url))` for `promptsDir` — no `~/.pi/` reference
- [ ] `commands.ts` uses `process.env.GSD_WORKFLOW_PATH` for workflow path — no hardcoded `~/.pi/GSD-WORKFLOW.md`
- [ ] `commands.ts` uses `dirname(fileURLToPath(import.meta.url))` for preferences template — no absolute `/Users/lexchristopherson/` path
- [ ] `guided-flow.ts` uses `process.env.GSD_WORKFLOW_PATH` — no hardcoded `~/.pi/GSD-WORKFLOW.md`
- [ ] `skill-discovery.ts` uses `getAgentDir()` for skills dir — no `~/.pi/agent/skills/` reference
- [ ] `preferences.ts` uses `getAgentDir()` for skills dir — no `~/.pi/agent/skills/` references
- [ ] `subagent/index.ts` spawns `process.execPath` with `GSD_BIN_PATH` — no `spawn("pi", ...)`
- [ ] `subagent/index.ts` prepends `--extension <path>` args from `GSD_BUNDLED_EXTENSION_PATHS`

## Verification

```bash
# No ~/.pi/ references in patched files
echo "=== prompt-loader.ts ===" && grep -n '\.pi' src/resources/extensions/gsd/prompt-loader.ts && echo "FAIL" || echo "OK"
echo "=== commands.ts ===" && grep -n '\.pi/GSD-WORKFLOW\|lexchristopherson' src/resources/extensions/gsd/commands.ts && echo "FAIL" || echo "OK"
echo "=== guided-flow.ts ===" && grep -n '\.pi/GSD-WORKFLOW' src/resources/extensions/gsd/guided-flow.ts && echo "FAIL" || echo "OK"
echo "=== skill-discovery.ts ===" && grep -n '\.pi.*skills' src/resources/extensions/gsd/skill-discovery.ts && echo "FAIL" || echo "OK"
echo "=== preferences.ts ===" && grep -n '\.pi.*skills' src/resources/extensions/gsd/preferences.ts && echo "FAIL" || echo "OK"

# Subagent no longer spawns "pi"
echo "=== subagent/index.ts ===" && grep -n 'spawn("pi"' src/resources/extensions/subagent/index.ts && echo "FAIL" || echo "OK"

# Subagent uses GSD_BIN_PATH and GSD_BUNDLED_EXTENSION_PATHS
grep -n "GSD_BIN_PATH\|GSD_BUNDLED_EXTENSION_PATHS\|extensionArgs" src/resources/extensions/subagent/index.ts

# Correct replacement patterns present
grep -n "import.meta.url" src/resources/extensions/gsd/prompt-loader.ts
grep -n "GSD_WORKFLOW_PATH" src/resources/extensions/gsd/commands.ts src/resources/extensions/gsd/guided-flow.ts
grep -n "getAgentDir" src/resources/extensions/gsd/skill-discovery.ts src/resources/extensions/gsd/preferences.ts
grep -n "process.execPath" src/resources/extensions/subagent/index.ts
```

## Observability Impact

- Signals added/changed: After these patches, GSD extension errors at runtime will be about missing env vars (`GSD_WORKFLOW_PATH undefined`) or missing files — specific and actionable. Before patches, errors were about wrong paths to `~/.pi/` which are harder to diagnose without knowing they're wrong.
- How a future agent inspects this: `grep -rn 'GSD_WORKFLOW_PATH\|import.meta.url\|getAgentDir' src/resources/extensions/gsd/` — presence of these patterns confirms patches were applied
- Failure state exposed: If `GSD_WORKFLOW_PATH` is not set and gsd extension loads, the workflow dispatch will fail with a clear `readFileSync` error on `undefined` path — easier to diagnose than a silent wrong-file-read

## Inputs

- `src/resources/extensions/gsd/prompt-loader.ts` — output of T01, needs promptsDir patch
- `src/resources/extensions/gsd/commands.ts` — output of T01, needs workflowPath and template patches
- `src/resources/extensions/gsd/guided-flow.ts` — output of T01, needs workflowPath patch
- `src/resources/extensions/gsd/skill-discovery.ts` — output of T01, needs SKILLS_DIR patch
- `src/resources/extensions/gsd/preferences.ts` — output of T01, needs two skills dir patches
- `src/resources/extensions/subagent/index.ts` — output of T01, needs spawn patch
- S02-RESEARCH.md — exact patch patterns for each file

## Expected Output

- 5 gsd extension files with zero `~/.pi/` references — all paths computed at call time via env vars or `import.meta.url`
- `subagent/index.ts` spawning `process.execPath` with `GSD_BIN_PATH` and `--extension` flags for bundled extensions
- No other files in `src/resources/` are modified

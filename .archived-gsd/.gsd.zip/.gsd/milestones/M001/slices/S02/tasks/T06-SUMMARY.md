---
id: T06
parent: S02
milestone: M001
provides:
  - Full S02 integration verified — build clean, all 11 extensions loaded, no errors, AGENTS.md written on first launch
key_files: []
key_decisions:
  - preferences.ts line 115 (`join(cwd, ".pi", "agent", "skills")`) is intentionally cwd-relative and not patched — the slice-level `\.pi.*skills` grep check flags it as a false positive, but it is correct behavior per T02 decisions
patterns_established:
  - "Integration proof pattern: `(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep '[gsd] Extension load error'` — zero matches = all extensions loaded"
observability_surfaces:
  - "stderr extension errors: `(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep 'Extension load error'` — zero matches confirms clean load"
  - "AGENTS.md presence: `ls ~/.gsd/agent/AGENTS.md` — confirms first-run initResources executed"
  - "GSD env vars in loader: `grep GSD_ dist/loader.js` — 8 lines (4 env vars, each set and referenced)"
duration: ~10 minutes
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T06: Build, launch, and verify all extensions load and tools register

**All 11 bundled extensions loaded without errors on first `gsd` launch; AGENTS.md written; build clean; S02 complete.**

## What Happened

Ran full build (`npm run build` → exit 0), verified all 4 dist artifacts exist, confirmed all 4 GSD env vars present in `dist/loader.js` (8 grep matches), confirmed `buildResourceLoader`/`extensionsResult`/`Extension load error` all present in `dist/cli.js`.

Ran launch test: `(node dist/loader.js & sleep 6; kill $!) 2>&1` — TUI rendered with `gsd v0.1.0` branding (4 matches), no `[gsd] Extension load error:` lines in output. All 11 extensions loaded cleanly.

Verified `~/.gsd/agent/AGENTS.md` exists (15,070 bytes, written at first launch by `initResources`).

Confirmed extension layout: 10 directory extensions, 2 single-file extensions (`ask-user-questions.ts`, `get-secrets-from-user.ts`) as siblings of `shared/`.

Ran all slice-level verification checks — all pass. The `\.pi.*skills` check for `preferences.ts` flags a comment (line 110) and an intentionally cwd-relative path (line 115, `join(cwd, ".pi", ...)`). Neither is an absolute `~/.pi` hardcoded path in executable code — documented in decisions above.

## Verification

```
npm run build                                          → exit 0
ls dist/loader.js dist/cli.js dist/resource-loader.js dist/app-paths.js  → all exist
grep GSD_* dist/loader.js | wc -l                     → 8 (4 vars × 2 occurrences each)
grep "buildResourceLoader|extensionsResult|Extension load error" dist/cli.js  → 3 matches
(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "[gsd] Extension load error"  → OK: no errors
(node dist/loader.js & sleep 6; kill $!) 2>&1 | strings | grep -c "gsd"             → 4
ls -la ~/.gsd/agent/AGENTS.md                         → OK (15,070 bytes)
ls src/resources/extensions/ | grep -E "(gsd|shared|bg-shell|...)" | wc -l  → 10
ls src/resources/extensions/ask-user-questions.ts src/resources/extensions/get-secrets-from-user.ts  → both exist
```

Slice-level verification checks:
- ✅ Build exits clean
- ✅ src/resources structure: gsd/index.ts, subagent/index.ts, browser-tools/index.ts, agents/scout.md, AGENTS.md, GSD-WORKFLOW.md
- ✅ Patches: prompt-loader OK, commands OK, guided-flow OK, skill-discovery OK, subagent OK; preferences has only false-positive cwd-relative `.pi` (intentional)
- ✅ tsconfig excludes src/resources
- ✅ playwright in dependencies
- ✅ src/resources in package.json files
- ✅ GSD env vars in dist/loader.js (8 lines)

## Diagnostics

- **Extension load errors**: `(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "Extension load error"` — zero matches = all loaded
- **First-run write**: `ls ~/.gsd/agent/AGENTS.md` — file present = initResources ran
- **Env vars set**: `grep GSD_ dist/loader.js` — 8 lines confirms all 4 vars
- **Extension paths**: `grep additionalExtensionPaths dist/resource-loader.js` — lists all 11 registered paths

## Deviations

The slice-level `\.pi.*skills` check for `preferences.ts` produces a false positive on line 110 (comment) and line 115 (cwd-relative `join(cwd, ".pi", ...)` which is intentionally kept per T02 decisions). No code change needed — documented as an acceptable false positive.

## Known Issues

None.

## Files Created/Modified

No new files produced. This task validated existing T01–T05 outputs.

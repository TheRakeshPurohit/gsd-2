---
id: T03
parent: S02
milestone: M001
provides:
  - src/resource-loader.ts exporting buildResourceLoader(agentDir) and initResources(agentDir)
  - dist/resource-loader.js compiled output with correct import.meta.url-relative paths
  - tsconfig.json excludes src/resources from TypeScript compilation (eliminates bundled extension type errors)
  - package.json adds playwright to dependencies and src/resources to files
key_files:
  - src/resource-loader.ts
  - tsconfig.json
  - package.json
key_decisions:
  - tsconfig exclude added here (T03) since type-checking `src/resource-loader.ts` would fail if `src/resources` was still in scope — natural home for this config change
  - playwright and src/resources fixes done in T03 to satisfy slice-level verification checks
patterns_established:
  - import.meta.url + fileURLToPath + dirname for module-relative resource paths in compiled dist/ files
  - existsSync guard on initResources to prevent overwriting user's customized AGENTS.md on subsequent launches
observability_surfaces:
  - First-run AGENTS.md write: `ls ~/.gsd/agent/AGENTS.md` after first `gsd` run
  - Extension path inspection: `grep additionalExtensionPaths dist/resource-loader.js`
  - Build-time: `npx tsc --noEmit` is now clean (src/resources excluded)
duration: 15m
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T03: Write src/resource-loader.ts with buildResourceLoader() and initResources()

**Wrote `src/resource-loader.ts` wiring all 11 bundled extension entry points into a `DefaultResourceLoader`, with first-run AGENTS.md write and clean TypeScript compilation.**

## What Happened

1. Wrote `src/resource-loader.ts` with two exports:
   - `buildResourceLoader(agentDir)` — creates `new DefaultResourceLoader({ agentDir, additionalExtensionPaths: EXTENSION_ENTRY_POINTS })` with all 11 extension entry points as absolute paths computed via `fileURLToPath(import.meta.url)`
   - `initResources(agentDir)` — copies bundled `src/resources/AGENTS.md` to `${agentDir}/AGENTS.md` behind an `existsSync` guard (one-time first-run write)

2. Added `"exclude": ["src/resources"]` to `tsconfig.json` — the bundled extension sources have type errors (intentional: they're compiled by jiti at runtime, not by the gsd tsc pipeline). Without the exclude, `npx tsc --noEmit` produced ~120 errors from `src/resources/**`.

3. Added `playwright` to `package.json` dependencies (`^1.58.2` via `npm install playwright --save`) and added `src/resources` to the `files` array — both required by slice-level verification checks.

## Verification

```
npx tsc --noEmit              → exit 0, no output
npm run build                 → exit 0 (tsc + copy-themes)
ls dist/resource-loader.js    → present
node --input-type=module -e "import { buildResourceLoader } from './dist/resource-loader.js'; console.log(typeof buildResourceLoader);"
                              → "function"
node --input-type=module -e "import { initResources } from './dist/resource-loader.js'; console.log(typeof initResources);"
                              → "function"
grep "src/resources" tsconfig.json
                              → "exclude": ["src/resources"]
node -e "const p=require('./package.json');console.log(p.dependencies.playwright ? 'OK' : 'FAIL')"
                              → OK
node -e "const p=require('./package.json');console.log(p.files.includes('src/resources') ? 'OK' : 'FAIL')"
                              → OK
```

Slice-level checks 1 (build), 4 (tsconfig), 5 (playwright), 6 (src/resources in files) all pass.
Checks 2 (file layout) and 3 (patches) already passed from T01/T02.
Checks 7 and 8 (launch + env vars in loader.js) are T04 scope.

## Diagnostics

- `grep additionalExtensionPaths dist/resource-loader.js` — shows all 11 extension paths registered
- `ls ~/.gsd/agent/AGENTS.md` — confirms first-run write happened after first `gsd` invocation
- If `buildResourceLoader()` throws at runtime: error will be ENOENT on a specific extension path — points directly back to T01 copy step
- If initResources silently skips: AGENTS.md already exists at agentDir (expected behavior, not a bug)

## Deviations

- Also added `tsconfig.json` exclude for `src/resources`, `playwright` to package.json dependencies, and `src/resources` to package.json files — these were slice-level must-haves not assigned to a specific task; absorbed here since they unblock clean type-checking for `src/resource-loader.ts` and complete the slice-level verification surface.

## Known Issues

None.

## Files Created/Modified

- `src/resource-loader.ts` — new file (~55 lines); exports `buildResourceLoader(agentDir)` and `initResources(agentDir)`
- `tsconfig.json` — added `"exclude": ["src/resources"]` to prevent bundled extension source from being type-checked by gsd's tsc
- `package.json` — added `playwright` to dependencies; added `src/resources` to `files` array

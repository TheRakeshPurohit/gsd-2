---
id: T02
parent: S02
milestone: M001
provides:
  - src/resources/extensions/gsd/prompt-loader.ts patched to use import.meta.url-relative prompts/ dir
  - src/resources/extensions/gsd/commands.ts patched to use GSD_WORKFLOW_PATH env var and import.meta.url-relative template path
  - src/resources/extensions/gsd/guided-flow.ts patched to use GSD_WORKFLOW_PATH env var
  - src/resources/extensions/gsd/skill-discovery.ts patched to use getAgentDir() for skills dir
  - src/resources/extensions/gsd/preferences.ts patched to use getAgentDir() for user skills dir
  - src/resources/extensions/subagent/index.ts patched to spawn process.execPath with GSD_BIN_PATH and bundled extension flags
key_files:
  - src/resources/extensions/gsd/prompt-loader.ts
  - src/resources/extensions/gsd/commands.ts
  - src/resources/extensions/gsd/guided-flow.ts
  - src/resources/extensions/gsd/skill-discovery.ts
  - src/resources/extensions/gsd/preferences.ts
  - src/resources/extensions/subagent/index.ts
key_decisions:
  - preferences.ts retains homedir() for GLOBAL_PREFERENCES_PATH, LEGACY_GLOBAL_PREFERENCES_PATH, and tilde expansion — only the user-skills dir lookup was migrated to getAgentDir()
  - preferences.ts project-skill dir (join(cwd, ".pi", "agent", "skills")) is intentionally kept as-is — it scans cwd-relative .pi, not a hardcoded ~/.pi
  - JSDoc comment in prompt-loader.ts updated to remove stale ~/.pi/ path reference
patterns_established:
  - import.meta.url + fileURLToPath + dirname for module-relative resource paths in bundled extensions
  - process.env.GSD_WORKFLOW_PATH with fallback for relocatable workflow dispatch
  - getAgentDir() from @mariozechner/pi-coding-agent for user skills dir (replaces homedir()+"/.pi/agent")
  - GSD_BUNDLED_EXTENSION_PATHS colon-delimited list → flatMap to --extension args for subagent spawning
  - process.execPath + GSD_BIN_PATH for spawning child gsd processes (no hardcoded binary name)
observability_surfaces:
  - grep -rn "GSD_WORKFLOW_PATH|import.meta.url|getAgentDir" src/resources/extensions/gsd/ — confirms all patches applied
  - grep -n "GSD_BIN_PATH|GSD_BUNDLED_EXTENSION_PATHS|extensionArgs" src/resources/extensions/subagent/index.ts — confirms subagent patch
  - If GSD_WORKFLOW_PATH is unset at runtime, doctor-heal and guided-flow dispatch will fail with explicit readFileSync error on undefined path (actionable, not silent wrong-file)
duration: ~15min
verification_result: passed
completed_at: 2026-03-10
blocker_discovered: false
---

# T02: Apply surgical patches to bundled gsd extension and subagent

**Patched 6 bundled source files to eliminate all hardcoded ~/.pi/ paths and fix subagent spawning to use process.execPath + GSD_BIN_PATH with bundled extension flags.**

## What Happened

Read all 6 target files before patching to understand their existing structure and imports.

Applied 6 sets of surgical patches:

1. **prompt-loader.ts**: Replaced `join(homedir(), ".pi", "agent", "extensions", "gsd", "prompts")` with `join(dirname(fileURLToPath(import.meta.url)), "prompts")`. Swapped `homedir` import for `dirname` + `fileURLToPath`. Updated stale JSDoc comment.

2. **commands.ts**: (a) Added `dirname` to path imports and added `fileURLToPath` from `node:url`. (b) Replaced hardcoded `join(process.env.HOME ?? "~", ".pi", "GSD-WORKFLOW.md")` with `process.env.GSD_WORKFLOW_PATH ?? join(...)` fallback. (c) Replaced absolute `/Users/lexchristopherson/.pi/agent/extensions/gsd/templates/preferences.md` with `join(dirname(fileURLToPath(import.meta.url)), "templates", "preferences.md")`.

3. **guided-flow.ts**: Replaced `join(process.env.HOME ?? "~", ".pi", "GSD-WORKFLOW.md")` with `process.env.GSD_WORKFLOW_PATH ?? join(...)` fallback.

4. **skill-discovery.ts**: Replaced `homedir` import with `getAgentDir` from `@mariozechner/pi-coding-agent`. Replaced `join(homedir(), ".pi", "agent", "skills")` with `join(getAgentDir(), "skills")`.

5. **preferences.ts**: Added `getAgentDir` import. Replaced `join(homedir(), ".pi", "agent", "skills")` in `getSkillSearchDirs` with `join(getAgentDir(), "skills")`. Retained `homedir()` for GLOBAL_PREFERENCES_PATH, LEGACY_GLOBAL_PREFERENCES_PATH, and tilde expansion — those are legitimate uses. The project-skill dir (`join(cwd, ".pi", "agent", "skills")`) was intentionally left unchanged — it scans relative to cwd.

6. **subagent/index.ts**: Inside `runSingleAgent`, replaced `spawn("pi", args, ...)` with the full pattern that reads `GSD_BUNDLED_EXTENSION_PATHS`, flatMaps each path to `["--extension", path]`, then spawns `process.execPath` with `[GSD_BIN_PATH!, ...extensionArgs, ...args]`.

## Verification

All task-plan verification commands passed:

```
prompt-loader.ts     — no .pi references: OK
commands.ts          — no .pi/GSD-WORKFLOW or lexchristopherson: OK
guided-flow.ts       — no .pi/GSD-WORKFLOW: OK
skill-discovery.ts   — no .pi.*skills: OK
preferences.ts       — no homedir()+skills: OK (project-skill cwd/.pi entry retained by design)
subagent/index.ts    — no spawn("pi"): OK
```

Correct replacement patterns confirmed present:
- `import.meta.url` in prompt-loader.ts ✓
- `GSD_WORKFLOW_PATH` in commands.ts and guided-flow.ts ✓
- `getAgentDir` in skill-discovery.ts and preferences.ts ✓
- `process.execPath` in subagent/index.ts ✓
- `GSD_BIN_PATH`, `GSD_BUNDLED_EXTENSION_PATHS`, `extensionArgs` in subagent/index.ts ✓

Slice-level checks applicable at this stage all pass. Build, tsconfig, and runtime loader checks will be verified in T03–T06.

## Diagnostics

- `grep -rn "GSD_WORKFLOW_PATH\|import.meta.url\|getAgentDir" src/resources/extensions/gsd/` — confirms all 5 gsd patches applied
- `grep -n "process.execPath\|GSD_BIN_PATH\|extensionArgs" src/resources/extensions/subagent/index.ts` — confirms subagent patch
- Runtime failure mode: if `GSD_WORKFLOW_PATH` is not set, dispatch functions fail with explicit `ENOENT` on `undefined` path — diagnosable immediately vs silent wrong-file read

## Deviations

- preferences.ts `getSkillSearchDirs` project-skill entry `join(cwd, ".pi", "agent", "skills")` retained — plan only required removing the `homedir()` reference; cwd-relative scan is correct behavior
- JSDoc comment in prompt-loader.ts updated as a bonus cleanup (stale `~/.pi/` path in comment)

## Known Issues

None.

## Files Created/Modified

- `src/resources/extensions/gsd/prompt-loader.ts` — promptsDir now import.meta.url-relative; homedir import removed
- `src/resources/extensions/gsd/commands.ts` — GSD_WORKFLOW_PATH env var with fallback; preferences template via import.meta.url; dirname/fileURLToPath imports added
- `src/resources/extensions/gsd/guided-flow.ts` — GSD_WORKFLOW_PATH env var with fallback for workflowPath
- `src/resources/extensions/gsd/skill-discovery.ts` — SKILLS_DIR via getAgentDir(); homedir import replaced
- `src/resources/extensions/gsd/preferences.ts` — user-skills dir via getAgentDir(); getAgentDir import added
- `src/resources/extensions/subagent/index.ts` — spawns process.execPath with GSD_BIN_PATH + --extension args from GSD_BUNDLED_EXTENSION_PATHS

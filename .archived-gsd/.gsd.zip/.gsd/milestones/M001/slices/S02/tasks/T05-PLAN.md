---
estimated_steps: 4
estimated_files: 2
---

# T05: Update package.json (playwright dep, src/resources in files) and tsconfig.json (exclude src/resources)

**Slice:** S02 — Bundle Extensions and Agents
**Milestone:** M001

## Description

Three mechanical updates enable the full build and publish pipeline:

1. **`tsconfig.json`** — Add `"exclude": ["src/resources"]` to prevent TypeScript from compiling the 70+ extension `.ts` files, which are not strict-mode clean and will break the build if included.

2. **`package.json` dependencies** — Add `"playwright": "latest"` to `dependencies`. The `browser-tools/index.ts` extension does `await import("playwright")` dynamically at runtime. If playwright is not in gsd-2's own `node_modules`, this lazy import fails the first time a browser tool is called. It must be in `dependencies` (not `devDependencies`) so it ships with the npm package.

3. **`package.json` files** — Add `"src/resources"` to the `files` array so `npm pack` includes the bundled extension source. Without this, the tarball omits all extension `.ts` files and the install is broken.

Run `npm install` after adding playwright to update `package-lock.json`.

## Steps

1. **Edit `tsconfig.json`**: Add `"exclude": ["src/resources"]` to the `compilerOptions` object (or at top level — `exclude` is a top-level tsconfig key, not under `compilerOptions`). Current tsconfig has `"include": ["src"]` and no `exclude`. Add `"exclude": ["src/resources"]` as a sibling of `"include"`.

2. **Edit `package.json` dependencies**: Add `"playwright": "latest"` to the `dependencies` object (alongside `@mariozechner/pi-coding-agent`).

3. **Edit `package.json` files**: Add `"src/resources"` to the `files` array. Current files: `["dist", "pkg", "package.json", "README.md"]`. New: `["dist", "pkg", "src/resources", "package.json", "README.md"]`.

4. **Run `npm install`** to update `package-lock.json` with playwright and verify `node_modules/playwright` is present.

## Must-Haves

- [ ] `tsconfig.json` has `"exclude": ["src/resources"]` at the top level
- [ ] `package.json` `dependencies` includes `"playwright": "latest"` (or specific version)
- [ ] `package.json` `files` array includes `"src/resources"`
- [ ] `node_modules/playwright` is installed after `npm install`
- [ ] `npm run build` exits 0 after these changes (tsconfig exclude prevents compiler errors from extension source)

## Verification

```bash
# tsconfig exclude present
grep '"exclude"' tsconfig.json
node -e "const t=require('./tsconfig.json');console.log(t.exclude?.includes('src/resources') ? 'OK' : 'FAIL')"

# playwright in dependencies
node -e "const p=require('./package.json');console.log(p.dependencies.playwright ? 'OK: ' + p.dependencies.playwright : 'FAIL')"

# src/resources in files
node -e "const p=require('./package.json');console.log(p.files.includes('src/resources') ? 'OK' : 'FAIL')"

# playwright installed
ls node_modules/playwright/package.json

# Build succeeds (tsconfig exclude prevents ts errors from extension source)
npm run build
echo "Build exit: $?"
```

## Observability Impact

- Signals added/changed: Build failure diagnostic improves — if `src/resources` is accidentally removed from `exclude`, `tsc` will fail with explicit TypeScript errors from extension files (identifiable by path `src/resources/extensions/...`). This is actually useful signal.
- How a future agent inspects this: `npx tsc --noEmit 2>&1 | grep "src/resources"` — any output here means the exclude is missing or broke
- Failure state exposed: `npm run build` failing with errors in `src/resources/extensions/` is the clear signal that `tsconfig.json` exclude is missing

## Inputs

- `package.json` — S01 output, needs playwright + files update
- `tsconfig.json` — S01 output, needs exclude added
- `src/resources/extensions/` — T01 output (70+ .ts files that will break tsc without exclude)

## Expected Output

- `tsconfig.json` — with `"exclude": ["src/resources"]` at top level
- `package.json` — playwright in dependencies, src/resources in files
- `package-lock.json` — updated with playwright resolved
- `node_modules/playwright/` — playwright installed
- `npm run build` exits 0

# S02: Bundle Extensions and Agents — UAT

**Milestone:** M001
**Written:** 2026-03-10

## UAT Type

- UAT mode: live-runtime
- Why this mode is sufficient: S02's success condition is that all 11 extensions load without errors in a real running `gsd` process. Extension loading is a runtime integration concern — it cannot be verified by type-checking or static analysis alone. The TUI is a side effect; what matters is zero stderr extension errors and the presence of the correct GSD_ env vars in the compiled loader. All verifiable assertions are executable via CLI without human interaction.

## Preconditions

- `gsd-2/` project checked out on `gsd/M001/S02` branch
- `npm run build` has been run (dist/ artifacts present)
- Node.js 18+ available
- No ANTHROPIC_API_KEY required for extension-load verification (only for full TUI launch)

## Smoke Test

```bash
cd /path/to/gsd-2
npm run build && echo "Build OK" && \
  (node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "\[gsd\] Extension load error" | \
  (read -r line; [ -z "$line" ] && echo "Extensions OK: no load errors" || echo "FAIL: $line")
```

Expected: `Build OK` then `Extensions OK: no load errors`.

## Test Cases

### 1. Build is clean

```bash
npm run build
echo "Exit: $?"
```

**Expected:** `Exit: 0` — no TypeScript errors, no copy-themes errors.

### 2. All 4 GSD env vars present in compiled loader

```bash
grep "GSD_CODING_AGENT_DIR\|GSD_BIN_PATH\|GSD_WORKFLOW_PATH\|GSD_BUNDLED_EXTENSION_PATHS" dist/loader.js | wc -l
```

**Expected:** `8` (each of 4 vars appears twice in compiled output — assignment + reference).

### 3. Extension source files present at correct paths

```bash
ls src/resources/extensions/gsd/index.ts \
   src/resources/extensions/subagent/index.ts \
   src/resources/extensions/browser-tools/index.ts \
   src/resources/extensions/context7/index.ts \
   src/resources/extensions/search-the-web/index.ts \
   src/resources/extensions/bg-shell/index.ts \
   src/resources/extensions/plan-mode/index.ts \
   src/resources/extensions/slash-commands/index.ts \
   src/resources/extensions/worktree/index.ts \
   src/resources/extensions/ask-user-questions.ts \
   src/resources/extensions/get-secrets-from-user.ts \
   src/resources/agents/scout.md \
   src/resources/AGENTS.md \
   src/resources/GSD-WORKFLOW.md
```

**Expected:** All 14 paths ls without error.

### 4. No hardcoded ~/.pi/ paths in patched files

```bash
grep -n "\.pi" src/resources/extensions/gsd/prompt-loader.ts && echo "FAIL" || echo "OK"
grep -n "\.pi/GSD-WORKFLOW" src/resources/extensions/gsd/commands.ts && echo "FAIL" || echo "OK"
grep -n "\.pi/GSD-WORKFLOW" src/resources/extensions/gsd/guided-flow.ts && echo "FAIL" || echo "OK"
grep -n '\.pi.*skills' src/resources/extensions/gsd/skill-discovery.ts && echo "FAIL" || echo "OK"
grep -n 'spawn("pi"' src/resources/extensions/subagent/index.ts && echo "FAIL" || echo "OK"
```

**Expected:** All 5 print `OK`. (preferences.ts will show lines 110 and 115 — both are false positives per documented decisions; see Edge Cases.)

### 5. All extensions load without errors at runtime

```bash
(node dist/loader.js & sleep 6; kill $!) 2>&1 | grep "\[gsd\] Extension load error"
```

**Expected:** No output (zero extension load errors).

### 6. AGENTS.md written to ~/.gsd/agent/ on first launch

```bash
rm -f ~/.gsd/agent/AGENTS.md
(node dist/loader.js & sleep 4; kill $!) 2>/dev/null
ls -la ~/.gsd/agent/AGENTS.md
```

**Expected:** File exists, size ~15070 bytes.

### 7. buildResourceLoader exports a function

```bash
node --input-type=module -e "
  import { buildResourceLoader, initResources } from './dist/resource-loader.js';
  console.log('buildResourceLoader:', typeof buildResourceLoader);
  console.log('initResources:', typeof initResources);
"
```

**Expected:** `buildResourceLoader: function` and `initResources: function`.

## Edge Cases

### preferences.ts cwd-relative .pi path

```bash
grep -n '\.pi.*skills' src/resources/extensions/gsd/preferences.ts
```

**Expected:** Lines 110 and 115 match. Line 110 is a JSDoc comment. Line 115 is `join(cwd, ".pi", "agent", "skills")` — a cwd-relative project-skills scan, not a hardcoded `~/.pi/` path. Both are intentional per T02 decisions and are not bugs.

### tsconfig exclude prevents bundled extension compilation

```bash
npx tsc --noEmit 2>&1 | wc -l
```

**Expected:** `0` — no errors. Without the exclude, this would show ~120 errors from bundled extension source files.

### playwright dependency installed

```bash
node -e "const p=require('./package.json'); console.log(p.dependencies.playwright ? 'OK' : 'FAIL')"
```

**Expected:** `OK`.

### src/resources in package.json files

```bash
node -e "const p=require('./package.json'); console.log(p.files.includes('src/resources') ? 'OK' : 'FAIL')"
```

**Expected:** `OK`.

## Failure Signals

- `[gsd] Extension load error: <path> — <message>` in stderr → a specific extension failed to load; path identifies which one; message is the jiti compilation error or missing module
- `FAIL` from any patch check → a hardcoded `~/.pi/` path survived patching; extension will resolve to wrong location at runtime
- Exit non-zero from `npm run build` → TypeScript error in gsd source (not bundled extension source, which is excluded)
- `FAIL` for playwright or src/resources in files → npm publish will break extension loading or browser-tools at runtime
- `AGENTS.md` not written after launch → `initResources` is not being called or existsSync incorrectly blocks write
- `4` or fewer grep matches for GSD_ in dist/loader.js → one or more env vars not set before cli.js loads; patched extension code will read `undefined`

## Requirements Proved By This UAT

- R003 — gsd extension loads without errors; /gsd command system is active (extension registered). Full interactive /gsd command confirmation is S04 UAT scope.
- R004 — All 10 supporting extensions (browser-tools, search-the-web, context7, subagent, bg-shell, worktree, plan-mode, slash-commands, ask-user-questions, get-secrets-from-user) bundle and load cleanly; confirmed via zero extension errors on launch.
- R005 — Scout, researcher, and worker agents present in src/resources/agents/; AGENTS.md deployed to ~/.gsd/agent/ on first launch; confirmed via file presence check.
- R009 — Extension load errors surface to stderr as structured `[gsd] Extension load error: <path> — <message>` messages; confirmed by the observability surface being real and testable.

## Not Proven By This UAT

- Interactive use of `/gsd` command, GSD dashboard (Ctrl+Alt+G), auto-mode, and guided flow — these require a live terminal session with a human. Deferred to S04 UAT.
- Subagent delegation actually works end-to-end (spawn gsd subprocess, pass --extension flags, child gsd loads correct extensions) — the spawn code is patched and present, but an actual subagent invocation requires API keys and live runtime. Deferred to S04.
- Browser tools are functional (playwright can actually launch a browser) — extension loads, but browser launch requires a display and playwright binaries installed. Deferred to S04.
- `npm install -g gsd-pi` path resolution — that `dist/resource-loader.js` correctly resolves `../src/resources` after global install. This requires the S04 tarball smoke test.
- R001 (single-command install) — S04 scope.
- R006 (first-run wizard) — S03 scope.
- R008 (npm update workflow) — S04 scope.

## Notes for Tester

All test cases in this UAT are executable via CLI without human interaction. No API keys are required for extension-load verification. The TUI may render in the terminal during test case 5 and 6 — this is expected; the process is killed after the sleep. The preferences.ts false positive in test case 4 is documented behavior — do not attempt to patch it away.

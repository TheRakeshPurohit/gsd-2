# M002: Branded Installer & Onboarding Experience — Context

**Gathered:** 2026-03-11
**Status:** In progress (S01 complete, S02-S03 planned)

## Project Description

Transform the entire first-contact experience — from `npm install` through first working session — into a polished, guided, trust-building flow. Three surfaces:

1. **Postinstall** (`scripts/postinstall.js`) — branded output with clack prompts, ASCII logo, spinners, boxed summary. ✅ Done in S01.
2. **ASCII logo** — shared constant used by postinstall, first-launch banner, and onboarding wizard.
3. **First-run onboarding** — a clack-based wizard that runs on first `gsd` launch, guiding users through LLM provider auth (OAuth or API key) and optional tool API keys before the TUI opens.

Reference implementations: `vercel-labs/skills` (clack-based interactive install flow) and `openclaw/openclaw` (gum-based installer + onboarding wizard with model auth, workspace setup, and channel configuration).

## Why This Milestone

The current experience has two critical gaps:

1. **Postinstall looks amateur** — raw ASCII dump, unstructured npm noise. ✅ Fixed in S01.
2. **LLM auth is buried** — new users install gsd, run it, and land in a TUI with no authenticated model. They have to discover `/login` on their own. The TUI is useless until they do. This is the main UX gap. OpenClaw solved this with an onboarding wizard that configures auth before the app starts. We should do the same.

## User-Visible Outcome

### When this milestone is complete, the user can:

- Run `npm install -g gsd-pi` and see a polished branded postinstall with ASCII logo, spinners, and boxed summary
- Run `gsd` for the first time and be walked through LLM provider selection → authentication → optional tool keys
- After completing onboarding, immediately start chatting with an authenticated LLM — no need to discover `/login`
- Skip any/all onboarding steps and configure later via `/login` and manual key entry

### Entry point / environment

- Entry point: `npm install -g gsd-pi` (postinstall) → `gsd` (first run triggers onboarding)
- Environment: any TTY terminal on macOS / Linux / Windows with Node.js ≥20.6.0
- Live dependencies: npm registry, Playwright CDN, OAuth provider endpoints (Anthropic, GitHub, etc.)

## Completion Class

- Contract complete means: postinstall shows branded output; onboarding wizard runs and stores credentials; `shouldRunOnboarding()` correctly detects fresh vs. returning user
- Integration complete means: full flow from `npm install -g` → `gsd` → onboarding → working TUI session with authenticated LLM
- Operational complete means: OAuth browser flows work on macOS/Linux; API key storage persists to `~/.gsd/agent/auth.json`; returning users skip onboarding; non-TTY skips silently

## Final Integrated Acceptance

To call this milestone complete, we must prove:

- Fresh install → `gsd` → onboarding wizard → select Anthropic OAuth → browser opens → complete auth → TUI launches → send a message → get a response
- Fresh install → skip all onboarding → TUI launches without crash → user can later `/login`
- Returning user (auth.json exists) → `gsd` → wizard skipped → TUI launches directly
- Non-TTY / print mode → no wizard, no crash

## Risks and Unknowns

- **OAuth flows outside TUI** — The pi-ai OAuth providers use callbacks (`onAuth` to open browser, `onPrompt` to get auth code). These are designed for the TUI's `LoginDialogComponent`. Need to prove we can drive them from a standalone clack prompt. The callback signatures are clean (`OAuthLoginCallbacks`), so this should work — but needs verification.
- **Clack → TUI terminal handoff** — Clack uses raw mode for interactive prompts (`p.text()`, `p.password()`). The TUI (`InteractiveMode`) also takes over the terminal. If clack doesn't fully clean up raw mode and cursor state, the TUI could start in a corrupted state. Clack's `outro()` should handle this, but needs explicit testing.
- **Browser opening reliability** — `exec('open <url>')` on macOS / `xdg-open` on Linux. If the browser doesn't open, the user needs the URL displayed so they can copy it manually. The flow must handle this gracefully.

## Existing Codebase / Prior Art

- `scripts/postinstall.js` — S01 output. Uses `@clack/prompts` + `picocolors`. Pattern for all subsequent clack usage.
- `src/wizard.ts` — Current first-run wizard. Raw ANSI + readline. Handles only optional tool API keys (Brave, Context7, Jina). Does NOT handle LLM auth. To be replaced by `src/onboarding.ts` in S03.
- `src/cli.ts` — Boot sequence. Calls `loadStoredEnvKeys()` + `runWizardIfNeeded()` before `InteractiveMode`. The onboarding call will replace `runWizardIfNeeded()`.
- `src/loader.ts` — First-launch banner (ASCII logo + "Setting up your environment..."). Has inline copy of logo — S02 will consolidate with `src/logo.ts`.
- `node_modules/@mariozechner/pi-ai/dist/utils/oauth/` — OAuth provider implementations. Each exports a `login()` function and an `OAuthProviderInterface`. Key providers: `anthropicOAuthProvider`, `githubCopilotOAuthProvider`, `openaiCodexOAuthProvider`.
- `node_modules/@mariozechner/pi-coding-agent/dist/core/auth-storage.js` — `AuthStorage.login(providerId, callbacks)` orchestrates OAuth flows. `AuthStorage.set(provider, credential)` stores API keys. `AuthStorage.hasAuth(provider)` checks for any form of auth.
- `node_modules/@mariozechner/pi-coding-agent/dist/core/model-registry.js` — `getAvailable()` returns models filtered by `hasAuth(provider)`. After onboarding stores credentials, these models become available.
- `node_modules/@mariozechner/pi-coding-agent/dist/modes/interactive/components/login-dialog.js` — TUI login dialog. Uses `exec('open <url>')` to open browser. Reference for browser-opening pattern.
- `node_modules/@mariozechner/pi-ai/dist/env-api-keys.js` — `getEnvApiKey()` maps provider names to env vars. Documents the env var → provider mapping.
- `/Users/lexchristopherson/Developer/claude-code-resources/get-shit-done/assets/` — SVG assets containing the GSD block-letter ASCII art.

> See `.gsd/DECISIONS.md` for all architectural and pattern decisions.

## Relevant Requirements

- R008 (npm install experience) — postinstall quality
- R012 (new: first-run onboarding) — LLM auth before TUI

## Scope

### In Scope

- ASCII logo shared constant (`src/logo.ts`)
- Logo in postinstall and first-launch banner
- Unified onboarding wizard (`src/onboarding.ts`) using `@clack/prompts`
- LLM provider selection: Anthropic (OAuth + API key), OpenAI, GitHub Copilot, OpenAI Codex, other providers
- OAuth browser flow driven from clack prompts
- API key collection with masked input
- Optional tool API keys (Brave, Context7, Jina) — migrated from current wizard
- Boxed summary of what was configured
- Skip-all path for users who want to configure later
- Clean terminal handoff from wizard to TUI

### Out of Scope / Non-Goals

- Model selection / scoped-models configuration during onboarding (handled by `/scoped-models` in TUI)
- Workspace configuration (working directory selection, etc.)
- Extension/skill configuration
- Daemon/service installation (like openclaw's launchd/systemd setup)
- Interactive onboarding inside the TUI (this is pre-TUI only)
- Windows-specific browser-opening testing beyond basic `start` command

## Technical Constraints

- Onboarding runs before `InteractiveMode` — cannot use TUI components
- Must use `@clack/prompts` for all interactive UI (already a production dependency from S01)
- OAuth callbacks require a TTY (browser opening + code paste) — non-TTY skips silently
- `authStorage.login()` expects `OAuthLoginCallbacks` with `onAuth`, `onPrompt`, optionally `onManualCodeInput`
- API key credentials use `{ type: 'api_key', key: string }` format
- OAuth credentials use `{ type: 'oauth', refresh, access, expires }` format
- Must handle the case where browser doesn't open (display URL for manual copy)
- Clack must fully clean up terminal state before TUI takes over

## Integration Points

- `AuthStorage` from `@mariozechner/pi-coding-agent` — credential storage and OAuth orchestration
- `getOAuthProviders()` / `getOAuthProvider()` from `@mariozechner/pi-ai/oauth` — provider registry
- `getEnvApiKey()` from `@mariozechner/pi-ai` — env var → provider mapping (for detecting existing env-based auth)
- `ModelRegistry.getAvailable()` — affected by auth changes; models appear after onboarding stores credentials
- `src/cli.ts` boot sequence — onboarding call site
- `InteractiveMode` — TUI that takes over after onboarding completes
- `child_process.exec` — browser opening for OAuth URLs

## Open Questions

- **Auth code format** — Anthropic's OAuth returns a code in `code#state` format. The `loginAnthropic` function handles parsing. We just need to pass the raw pasted string to `onPromptCode`. Verify this works with clack's `p.text()`.
- **Browser opening failure** — On headless servers or WSL, `open`/`xdg-open` may fail. The flow should display the URL prominently and not block on browser opening failure. Need to handle the `exec` error case.
- **Credential validation** — Should we validate API keys by making a test API call? Or just accept the format? Test calls add latency and complexity. Format-only validation (prefix check) is simpler and faster. Lean toward format-only.

# S04: End-to-end onboarding integration — Research

**Date:** 2026-03-11

## Summary

S04 is a pure integration and verification slice. All code exists on the S03 branch — `src/onboarding.ts` (536 lines), `src/cli.ts` wiring, `src/logo.ts`, and the S01 branded postinstall. The work is: merge S01→S02→S03 to main in order, rebase S04, fix merge conflicts, then prove the full end-to-end flow on a real TTY: fresh state → onboarding wizard → OAuth/API key → TUI launch → authenticated chat.

Three prerequisite branches (S01, S02, S03) must be squash-merged to main before S04 can begin its real work. S04's branch currently sits at the same commit as main with zero M002 changes. The merge order is strict: S01 first (adds `@clack/prompts` + `picocolors` as direct deps, rewrites postinstall), S02 second (depends on S01's deps, adds `src/logo.ts`, updates `src/loader.ts`), S03 third (adds `src/onboarding.ts`, wires it into `cli.ts`, deletes `wizard.ts`). Each merge has a known conflict surface — `scripts/postinstall.js`, `src/logo.ts`, `src/tests/app-smoke.test.ts`, and `src/resources/extensions/gsd/auto.ts` are all touched by multiple branches.

The #1 risk is the **clack → TUI terminal handoff**. Clack's `@clack/core` `Prompt` class calls `setRawMode(true)` on each prompt start and `setRawMode(false)` in `Prompt.close()`. The TUI's `ProcessTerminal.start()` saves `wasRaw = process.stdin.isRaw || false` before setting raw mode. If clack leaves raw mode clean (false), the TUI starts correctly. But if an uncaught exception crashes mid-prompt before `Prompt.close()` fires, raw mode leaks. The onboarding code's try/catch handles most cases, but an async rejection inside clack internals could bypass it. This can only be retired by real TTY exercise — not code reading.

The #2 risk is a confirmed **double logo on first launch**. `src/loader.ts` prints the GSD banner when `~/.gsd/` doesn't exist (before `initResources` creates it). Then `runOnboarding()` also renders the logo via `renderLogo()`. Both write to stderr. On the very first launch, users see the logo twice. Fix options: suppress the loader banner when interactive + TTY (since onboarding handles it), or remove the logo from onboarding's intro, or accept it as harmless (different messages: "Setting up your environment..." vs "Welcome to GSD — let's get you set up").

## Recommendation

1. **Squash-merge S01 → S02 → S03 to main** in strict order. Each merge is a separate commit with clean conflict resolution. S01 wins for postinstall. S02 wins for loader.ts and logo.ts. S03 wins for cli.ts, onboarding.ts, and wizard.ts deletion. Expect conflicts in: `scripts/postinstall.js` (S01↔S02↔S03), `src/logo.ts` (S02↔S03), `src/tests/app-smoke.test.ts` (S01↔S02↔S03), `.gsd/STATE.md` (all three).
2. **Rebase S04 onto main** after all merges. S04 should then have all M002 code.
3. **Fix the double-logo issue** — suppress the loader.ts first-launch banner when `process.stdin.isTTY` is true (since onboarding will handle the welcome on first launch). Non-TTY contexts still show the loader banner as before.
4. **Add R012 to REQUIREMENTS.md** — the first-run LLM onboarding requirement referenced in M002-CONTEXT but missing from the requirements file.
5. **Build and run `npm run build`** to verify clean compilation after merge.
6. **Interactive TTY testing** — the core prove-it work:
   - Delete `~/.gsd/agent/auth.json` → run `gsd` → wizard appears → select Anthropic OAuth → browser opens → complete auth → TUI launches → send message → receive response
   - Skip all → TUI launches without crash
   - Verify cursor and input work correctly after wizard→TUI handoff
   - Verify returning user skips wizard
   - Verify non-TTY skips silently

## Don't Hand-Roll

| Problem | Existing Solution | Why Use It |
|---------|------------------|------------|
| Branch merging with conflict resolution | `git merge --squash` + manual conflict resolution | Three branches have overlapping file changes; squash merge keeps main history clean |
| OAuth flow orchestration | `authStorage.login(providerId, callbacks)` from pi-coding-agent | Already handles PKCE, token exchange, credential storage, refresh. Provider logic in pi-ai. |
| Interactive CLI prompts | `@clack/prompts` v1.1.0 (direct dep after S01 merge) | Raw mode management, cancel handling, branded output. Already used in onboarding.ts. |
| Browser opening | `exec(open/xdg-open/start)` pattern in onboarding.ts `openBrowser()` | Same cross-platform pattern as pi's LoginDialogComponent. |
| Credential persistence | `AuthStorage.set(provider, credential)` | File-locked JSON storage with atomic writes. |
| Env hydration | `loadStoredEnvKeys()` from onboarding.ts | Maps stored credentials to `process.env` for extensions. Runs every boot. |

## Existing Code and Patterns

- `src/onboarding.ts` (S03 branch) — Complete 536-line clack-based wizard. Exports `shouldRunOnboarding()`, `runOnboarding()`, `loadStoredEnvKeys()`. Handles 9 LLM providers (OAuth + API key), 6 tool keys, skip paths, retry on OAuth failure. All error paths are try/catch wrapped.
- `src/cli.ts` (S03 branch) — Boot sequence wired: `loadStoredEnvKeys(authStorage)` → `shouldRunOnboarding(authStorage)` check → `runOnboarding(authStorage)` → `ModelRegistry` → `InteractiveMode.run()`. Print mode skips onboarding entirely.
- `src/logo.ts` (S02/S03 branches) — Shared `GSD_LOGO` constant + `renderLogo(color)`. Both branches have identical content; S02 is canonical since it also wires it into loader.ts.
- `scripts/postinstall.js` (S01 branch) — Complete clack-based postinstall with spinners, staged progress, boxed summary. S02 branch updates it to import shared logo. S03 has only minor changes from main (stale).
- `src/loader.ts` (S02 branch) — Updated to use `renderLogo()` from shared logo.ts instead of inline ASCII. Main/S03 still have inline logo.
- `node_modules/@mariozechner/pi-ai/dist/utils/oauth/anthropic.js` — Anthropic OAuth: calls `onAuth({url})` to show URL, `onPrompt({message: "Paste the authorization code:"})` to get `code#state` string. User pastes from browser redirect. No callback server.
- `node_modules/@mariozechner/pi-tui/dist/terminal.js` — `ProcessTerminal.start()` saves `wasRaw = process.stdin.isRaw` then sets raw mode. On `stop()`, restores to `wasRaw`. Critical for handoff correctness — clack must leave `isRaw === false` before TUI starts.
- `node_modules/@clack/core/dist/index.mjs` — `Prompt.close()` calls `W(input, false)` which does `setRawMode(false)`. Each prompt manages its own raw mode lifecycle independently.

## Constraints

- **Three unmerged branches block S04** — S01, S02, S03 must be squash-merged to main before S04 can rebase. S04's branch is currently identical to main with zero M002 changes.
- **Merge order is strict** — S02 depends on S01's `@clack/prompts` dep. S03's `onboarding.ts` imports from S02's `logo.ts`. S03 also has its own `logo.ts` (branched from main) that conflicts with S02's.
- **`@clack/prompts` is transitive until S01 merges** — S01 adds it as a direct dependency in `package.json`. S03's dynamic import fallback works but is fragile. After S01 merge, this is resolved.
- **Clack writes to stdout, logo/onboarding writes to stderr** — mixing is fine on a normal TTY but could cause visual issues in edge cases (piped stdout).
- **OAuth providers with callback servers (Codex, Gemini CLI, Antigravity) start HTTP servers on fixed ports** — port 1455 for Codex. If another process uses that port, OAuth fails. `onManualCodeInput` fallback handles this.
- **Anthropic OAuth code format is `code#state`** — the provider's `loginAnthropic()` splits on `#`. Clack's `p.text()` returns a plain string, which works. No validation needed on the onboarding side.
- **`ProcessTerminal.start()` calls `stdin.resume()`** — clack's `Prompt.close()` calls `input.unpipe()` but does NOT pause stdin. ProcessTerminal calls `resume()` anyway. No conflict here.
- **Interactive paths cannot be automated** — OAuth browser flows, clack prompt interaction, and TUI handoff verification all require a human on a real TTY. S04's core deliverable is proving these work.

## Common Pitfalls

- **Double logo on first launch** — Confirmed. `loader.ts` prints the banner when `~/.gsd/` doesn't exist (line 21), then `runOnboarding()` prints it again via `renderLogo()`. Fix: check `process.stdin.isTTY` in loader.ts — if interactive, skip the loader banner since onboarding will show a proper welcome. Non-TTY contexts (where onboarding doesn't run) still get the loader banner.
- **Merge conflict in postinstall.js** — S01 completely rewrites it (raw ANSI → clack-based). S02 modifies S01's version to use shared logo. S03 has minor tweaks to the old main version. Resolution: S01 wins base, then S02's logo changes on top. S03's postinstall changes are stale and should be dropped.
- **Merge conflict in logo.ts** — S02 creates it as a new file. S03 also creates an identical file (branched independently from main). Git will flag this as a conflict even though content is identical. Resolution: either version works; S02 is canonical.
- **Stale wizard.ts reference** — S03/T03 already fixed the smoke test imports from `wizard.ts` to `onboarding.ts`. After merging, verify no remaining references to `wizard.ts` in the codebase.
- **Test suite pre-existing failures** — Tests 47 and 50 in `app-smoke.test.ts` fail (AGENTS.md syncing). These are pre-existing and unrelated to onboarding. Don't block S04 on them.
- **OAuth browser opening on headless/SSH** — `openBrowser()` ignores `exec` errors silently. The URL is displayed via `p.log.info()`. If testing on SSH/headless, copy the URL manually. The onboarding code handles this correctly, but users need to know to look for the URL.

## Open Risks

- **Clack → TUI terminal raw mode handoff** — The #1 risk. Each clack prompt calls `setRawMode(false)` in `Prompt.close()`. If all prompts close cleanly, `process.stdin.isRaw` is `false` when the TUI starts → ProcessTerminal saves `wasRaw=false` → clean handoff. If an async exception bypasses `close()`, raw mode leaks. The onboarding try/catch catches most cases, but edge cases in clack's readline interactions or event emitter errors could slip through. **Must be proven on a real TTY. No code review can retire this.**
- **Clack cursor/ANSI state leak** — Even if raw mode is clean, clack hides the cursor during prompts (`\x1b[?25l`) and shows it on close (`\x1b[?25h`). If close is skipped, the cursor stays hidden. ProcessTerminal calls `hideCursor()` on start, so a leaked hidden cursor wouldn't be noticed — but if the TUI exits abnormally, the cursor stays hidden. Low probability.
- **stdin readline interface leak** — Clack's `Prompt.close()` calls `rl.close()` which releases the readline interface. ProcessTerminal creates its own stdin listener via `setEncoding` + `on('data')`. If clack's readline isn't fully closed, it could intercept keystrokes before ProcessTerminal. The `input.unpipe()` in `Prompt.close()` should prevent this, but edge cases exist.
- **First-launch timing: loader banner vs onboarding** — The loader banner runs in `loader.ts` (the entry point), which runs *before* `cli.ts` (which runs onboarding). There's a gap: `initResources()` runs between them and creates `~/.gsd/`. On a re-run, the loader banner won't show (because `~/.gsd/` exists), but onboarding won't run either (because the LLM is now authed). So the double-logo only happens on the absolute first launch. Cosmetic issue only.

## Skills Discovered

| Technology | Skill | Status |
|------------|-------|--------|
| @clack/prompts | — | none found |
| OAuth CLI flows | — | none found (generic OAuth skills exist but not pi-specific) |
| CLI onboarding wizard | — | none found |

No relevant skills to install. The work is tightly coupled to pi-coding-agent's AuthStorage API and gsd's specific boot sequence.

## Sources

- `src/onboarding.ts` on S03 branch — full 536-line implementation with all provider flows (source: `git show gsd/M002/S03:src/onboarding.ts`)
- `src/cli.ts` on S03 branch — boot sequence with onboarding wired in (source: `git show gsd/M002/S03:src/cli.ts`)
- `@clack/core` Prompt.close() raw mode handling — `W(input, false)` sets `setRawMode(false)` per prompt (source: `node_modules/@clack/core/dist/index.mjs`)
- ProcessTerminal.start() — saves `wasRaw = process.stdin.isRaw`, sets raw mode, resumes stdin (source: `node_modules/@mariozechner/pi-tui/dist/terminal.js:27-28`)
- Anthropic OAuth provider — `onAuth({url})` + `onPrompt({message})`, user pastes `code#state`, no callback server (source: `node_modules/@mariozechner/pi-ai/dist/utils/oauth/anthropic.js`)
- GitHub Copilot OAuth — device code flow with `onAuth(url, instructions)` + `onProgress` polling (source: `node_modules/@mariozechner/pi-ai/dist/utils/oauth/github-copilot.js`)
- Callback server providers — Codex (port 1455), Gemini CLI, Antigravity all set `usesCallbackServer: true` (source: rg across `node_modules/@mariozechner/pi-ai/dist/utils/oauth/*.js`)
- S03/T03 summary — 9/14 verification checks pass (automated), 5 require human UAT (source: `.gsd/milestones/M002/slices/S03/tasks/T03-SUMMARY.md`)
- Branch divergence — S04 identical to main; S01 has 2 commits, S02 has 5 commits, S03 has 9 commits ahead of main (source: `git log --oneline` comparisons)
- Conflict surface — `postinstall.js`, `logo.ts`, `app-smoke.test.ts`, `auto.ts` modified by multiple branches (source: `git diff --name-only` per branch)

# S01: Branded postinstall with clack

**Goal:** Replace the raw-ANSI postinstall script with a structured, branded flow using `@clack/prompts` and `picocolors` — spinners, stages, boxed summary, suppressed subprocess noise.
**Demo:** `npm pack && npm install -g ./gsd-pi-*.tgz` shows branded installer output with animated spinners during patch and Playwright steps, a boxed summary of results, and no raw subprocess noise.

## Must-Haves

- Branded intro header with product name and version
- Animated spinner during patch-package execution (not frozen — must use async subprocess)
- Animated spinner during Playwright chromium download
- Subprocess stdout/stderr captured — not inherited to terminal
- Boxed summary note showing results (✓ success / ⚠ warning per step)
- Clean outro with "run `gsd` to get started"
- Graceful handling of non-TTY (clack detects this; verify it degrades cleanly)
- Graceful handling of subprocess failures (warning, not crash)

## Proof Level

- This slice proves: integration (real `npm install` from packed tarball)
- Real runtime required: yes
- Human/UAT required: yes (visual quality judgment)

## Verification

- `node scripts/postinstall.js` runs to completion (exit 0) and produces structured output
- `npm pack && npm install -g ./gsd-pi-*.tgz` in a temp prefix shows branded output
- Subprocess failure simulation: verify the script handles `npx patch-package` failure gracefully
- Non-TTY: `node scripts/postinstall.js | cat` produces readable output without broken sequences
- Human visual check: output looks professional and branded

## Observability / Diagnostics

- Runtime signals: exit code 0 on success (postinstall should never fail the install)
- Inspection surfaces: stderr output (postinstall writes to stderr per npm convention)
- Failure visibility: each sub-step shows ✓ or ⚠ with human-readable message
- Redaction constraints: none

## Integration Closure

- Upstream surfaces consumed: `package.json` (postinstall hook, dependencies, files array)
- New wiring introduced in this slice: `@clack/prompts` and `picocolors` added to dependencies
- What remains before the milestone is truly usable end-to-end: nothing — S01 is the only slice

## Tasks

- [x] **T01: Add dependencies and rewrite postinstall.js** `est:30m`
  - Why: Core implementation — replace raw ANSI with clack-based structured output. Must use async subprocess execution (not `execSync`) because clack's spinner uses `setInterval` and `execSync` blocks the event loop, freezing the animation.
  - Files: `package.json`, `scripts/postinstall.js`
  - Do:
    1. Add `@clack/prompts` and `picocolors` to `dependencies` in package.json
    2. Run `npm install` to pull them in
    3. Rewrite `scripts/postinstall.js`:
       - `p.intro()` with branded header (product name + version, styled with picocolors)
       - Async helper function that wraps `child_process.exec` in a Promise (captures stdout+stderr, resolves on exit)
       - Spinner for "Applying patches..." → runs `npx patch-package` via async exec → stop with ✓ or ⚠
       - Spinner for "Setting up browser tools..." → runs `npx playwright install chromium` via async exec → stop with ✓ or ⚠
       - `p.note()` with boxed summary showing all results
       - `p.outro()` with "Run gsd to get started"
    4. Keep writing to stderr (npm postinstall convention)
    5. Handle the edge case where clack itself fails to import (graceful fallback to minimal console output)
  - Verify: `node scripts/postinstall.js` runs to completion with structured output
  - Done when: postinstall shows branded intro, animated spinners, boxed summary, clean outro

- [x] **T02: Verify with real npm pack + install** `est:15m`
  - Why: The postinstall runs in npm's subprocess environment, which has constraints (env vars, cwd, PATH) that differ from running the script directly. Must prove it works in the real install context.
  - Files: (no file changes — verification only)
  - Do:
    1. `npm pack` to create tarball
    2. `npm install -g --prefix /tmp/gsd-installer-test ./gsd-pi-*.tgz` to install from tarball
    3. Verify output shows branded flow
    4. Test non-TTY: pipe output through `cat` or redirect
    5. Test subprocess failure: temporarily break patch-package path and verify graceful warning
    6. Clean up temp files and tarball
  - Verify: `npm pack && npm install -g --prefix /tmp/gsd-installer-test ./gsd-pi-*.tgz` shows branded output
  - Done when: real npm install from tarball produces professional branded output; subprocess failures show clean warnings; non-TTY produces readable output

## Files Likely Touched

- `package.json` (add dependencies)
- `scripts/postinstall.js` (full rewrite)

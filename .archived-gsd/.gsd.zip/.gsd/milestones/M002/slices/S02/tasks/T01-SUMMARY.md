---
id: T01
parent: S02
milestone: M002
provides:
  - Shared GSD_LOGO constant and renderLogo() function in src/logo.ts
  - Postinstall script renders logo from shared module
  - Loader first-launch banner renders logo from shared module
key_files:
  - src/logo.ts
  - scripts/postinstall.js
  - src/loader.ts
key_decisions:
  - Used raw ANSI escape codes instead of adding picocolors as a direct dependency — keeps the module dependency-free since picocolors is only a transitive dep via @clack
patterns_established:
  - Color functions passed as arguments to renderLogo() — callers control styling, logo module stays pure data + join logic
observability_surfaces:
  - none
duration: 10m
verification_result: passed
completed_at: 2025-03-11
blocker_discovered: false
---

# T01: Create shared logo module and wire into postinstall + loader

**Created `src/logo.ts` as single source of truth for the GSD block-letter ASCII logo, wired into both postinstall and first-launch banner.**

## What Happened

Created `src/logo.ts` exporting `GSD_LOGO` (readonly string array of 6 raw lines, 27 chars wide) and `renderLogo(color)` which applies a color function to each line and joins with newlines.

Updated `scripts/postinstall.js` to import `renderLogo` from `../dist/logo.js` (shipped in dist/, available at consumer install time) and replaced the inline logo concatenation with `renderLogo(colorCyan)`.

Updated `src/loader.ts` to import `renderLogo` from `./logo.js` and replaced the inline 6-line ASCII art block with the shared function call.

Both consumers define a local `colorCyan` wrapper using raw ANSI codes (`\x1b[36m` / `\x1b[0m`), keeping the logo module free of color dependencies.

## Verification

- `npm run build` — compiles cleanly, produces `dist/logo.js` + `dist/logo.d.ts`
- `node scripts/postinstall.js` — shows cyan GSD block-letter logo above "Get Shit Done" tagline and status messages ✅
- `node -e "import('./dist/logo.js')"` — module loads, exports 6-line array and function ✅
- Logo max line width: 27 chars — fits 80-column terminals ✅
- `dist/loader.js` contains `import { renderLogo } from './logo.js'` — correctly wired ✅

### Slice-level checks
- ✅ `node scripts/postinstall.js` shows the ASCII logo before the clack intro bar
- ✅ Module exports verified via direct import
- ⏳ Visual check in first-launch context (requires UAT — loader only shows banner when `~/.gsd/` doesn't exist)

## Diagnostics

None — visual output only. If logo import fails at runtime, both postinstall and loader will throw on the import line (not silently degrade), which is correct since the module ships in dist/.

## Deviations

- Plan suggested picocolors for color rendering. Used raw ANSI escape codes instead since picocolors is not a direct dependency (only transitive via @clack). This avoids adding a dependency for a single color constant and matches the existing pattern in both files.

## Known Issues

None.

## Files Created/Modified

- `src/logo.ts` — New shared logo module with `GSD_LOGO` constant and `renderLogo()` function
- `scripts/postinstall.js` — Replaced inline logo with import from `../dist/logo.js`
- `src/loader.ts` — Replaced inline logo with import from `./logo.js`

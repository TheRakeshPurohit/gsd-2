# S02: ASCII logo in postinstall + first-launch banner

**Goal:** Add the GSD block-letter ASCII logo to the postinstall output and consolidate the logo into a shared constant so both `scripts/postinstall.js` and `src/loader.ts` use the same source.
**Demo:** `npm install -g gsd-pi` shows the cyan GSD block-letter logo above the clack install flow. Running `gsd` for the first time also shows the same logo in the first-launch banner.

## Must-Haves

- Shared logo constant in `src/logo.ts` (the block letters from the SVG asset)
- Postinstall script imports and renders the logo before `p.intro()`
- First-launch banner in `src/loader.ts` uses the same shared constant instead of its inline copy
- Logo rendered in cyan using picocolors (matching brand color `#7dcfff`)
- Logo renders cleanly in 80-column terminals (it's 27 chars wide — fine)

## Proof Level

- This slice proves: integration
- Real runtime required: yes
- Human/UAT required: yes (visual quality)

## Verification

- `node scripts/postinstall.js` shows the ASCII logo before the clack intro bar
- `node -e "import('./src/logo.ts')"` — verify the module exports correctly (or build + check dist)
- Visual check: logo appears in postinstall and first-launch contexts

## Observability / Diagnostics

- Runtime signals: none (visual output only)
- Inspection surfaces: none
- Failure visibility: if logo import fails, postinstall still works (logo is optional decoration)
- Redaction constraints: none

## Integration Closure

- Upstream surfaces consumed: `@clack/prompts` and `picocolors` from S01
- New wiring introduced: `src/logo.ts` shared module, imported by postinstall and loader
- What remains before the milestone is truly usable end-to-end: S03 (onboarding wizard)

## Tasks

- [x] **T01: Create shared logo module and wire into postinstall + loader** `est:15m`
  - Why: Consolidate the ASCII logo into a single source of truth so both postinstall and loader use the same art. Currently loader.ts has an inline copy and postinstall has none (we removed it in S01).
  - Files: `src/logo.ts` (new), `scripts/postinstall.js`, `src/loader.ts`
  - Do:
    1. Create `src/logo.ts` exporting:
       - `GSD_LOGO` — the raw block-letter strings as an array of lines (no ANSI codes)
       - `renderLogo(color: (s: string) => string): string` — joins lines with the color function applied, returns the full colored block ready to write
    2. Update `scripts/postinstall.js`:
       - Import the logo (postinstall.js is ESM, but can't import .ts directly — so either: a) copy the logo lines inline with a comment pointing to the source, or b) import from `dist/logo.js` after build. Since postinstall runs at consumer install time and dist/ is shipped, option b works: import from `../dist/logo.js`)
       - Render the logo to stderr before `p.intro()` using picocolors cyan
    3. Update `src/loader.ts`:
       - Replace the inline ASCII art with an import from `./logo.js`
       - Use the `renderLogo()` function with a cyan ANSI wrapper
    4. Ensure `src/logo.ts` is included in tsconfig (it's in `src/`, so it should be)
    5. Run `npm run build` to verify compilation
  - Verify: `npm run build && node scripts/postinstall.js` shows logo + clack flow; `node dist/loader.js` shows logo in first-launch context
  - Done when: both postinstall and first-launch banner display the same GSD block-letter logo, sourced from a single module

## Files Likely Touched

- `src/logo.ts` (new)
- `scripts/postinstall.js`
- `src/loader.ts`

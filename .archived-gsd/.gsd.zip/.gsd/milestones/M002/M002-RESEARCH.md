# M002: Branded Installer & Onboarding Experience — Research

**Date:** 2026-03-11

## Summary

M002 has three surfaces: branded postinstall (S01 — done on branch, not merged to main), shared ASCII logo (S02 — done on branch, not merged to main), and first-run onboarding wizard (S03 — T01 built on branch, T02+T03 remaining). The implementation is significantly progressed — `src/onboarding.ts` already exists with a full clack-based flow covering LLM provider selection, OAuth login, API key collection, and tool keys. The remaining work is wiring (`cli.ts` integration, removing old `wizard.ts`) and integration testing (OAuth handoff, terminal cleanup, TUI launch).

The primary risk is the **clack → TUI terminal handoff**. Clack's `@clack/core` sets raw mode during prompts and restores it on completion (`setRawMode(false)` + stream close). InteractiveMode creates a fresh TUI with its own raw mode setup. The gap: clack writes to stdout, but pi's TUI uses a ProcessTerminal which takes over stdin/stdout. If clack's outro doesn't fully flush/reset cursor state, the TUI could start with corrupted rendering. This is a prove-it risk — must be exercised in a real terminal, not theorized about.

The secondary risk is **OAuth flow reliability outside the TUI**. The existing `onboarding.ts` wires `authStorage.login()` with clack callbacks, which is the correct API. However, providers with local callback servers (Codex, Gemini CLI, Antigravity) start an HTTP server on localhost, open a browser, then wait for the redirect. If the browser fails to open, the `onManualCodeInput` callback fires — the onboarding module handles this via `p.text()`. This pattern matches the TUI's LoginDialogComponent. The Anthropic flow is simpler (no callback server, user pastes `code#state` string). All paths look correct in the code but haven't been exercised at runtime yet.

**Recommendation:** Merge S01 and S02 branches to main first (they're prerequisite work — logo and postinstall), then continue S03 with T02 (wiring) and T03 (integration testing with real OAuth + TUI handoff). The highest-risk test is Anthropic OAuth → TUI handoff on a real TTY.

## Recommendation

1. **Merge S01 and S02 to main** — both are complete on their branches with passing verification. S03 was branched from main without them, so it has a duplicate `src/logo.ts` and stale `scripts/postinstall.js`. Merging S01+S02 first prevents conflicts.
2. **Rebase S03 onto main** after S01+S02 merge — resolve any conflicts in `src/logo.ts`, `scripts/postinstall.js`, `src/loader.ts`.
3. **Complete T02** — wire `src/onboarding.ts` into `cli.ts`, replace `runWizardIfNeeded` with `shouldRunOnboarding` + `runOnboarding`, delete or gut `wizard.ts`.
4. **Complete T03** — interactive integration test: fresh state → onboarding → OAuth → TUI → send message → get response. This is the real prove-it moment.
5. **Add `@clack/prompts` as a direct dependency** — it's currently transitive via pi-coding-agent. The dynamic import fallback is defensive but fragile. If pi ever drops clack, gsd's onboarding breaks silently. Adding it to `dependencies` costs nothing and eliminates the risk.

## Don't Hand-Roll

| Problem | Existing Solution | Why Use It |
|---------|------------------|------------|
| Interactive CLI prompts (select, password, confirm, text) | `@clack/prompts` v1.1.0 (already in node_modules) | Branded output, raw mode management, cancel handling, non-TTY detection. Already proven in S01 postinstall. |
| OAuth flow orchestration | `AuthStorage.login(providerId, callbacks)` from pi-coding-agent | Handles PKCE, token exchange, credential storage, refresh token management. Provider-specific logic lives in pi-ai. |
| Browser opening | `exec(open/xdg-open/start)` pattern from LoginDialogComponent | Standard cross-platform approach. Already battle-tested in pi's TUI. |
| Credential persistence | `AuthStorage.set(provider, credential)` | File-locked JSON storage with atomic writes. Already handles concurrent access. |
| Env hydration from stored keys | `loadStoredEnvKeys()` from existing wizard.ts (migrated to onboarding.ts) | Maps stored credentials to process.env vars so extensions see them. Already proven in M001. |

## Existing Code and Patterns

- `src/onboarding.ts` — **Already built (T01 complete)**. Full clack-based onboarding wizard with LLM provider selection (9 options), OAuth flow, API key flow, tool keys, summary. Exports `shouldRunOnboarding()`, `runOnboarding()`, `loadStoredEnvKeys()`.
- `src/wizard.ts` — **To be replaced**. Raw readline + ANSI codes for optional tool keys only. `loadStoredEnvKeys()` function migrated to `onboarding.ts`. Delete this file in T02.
- `src/cli.ts` — **Boot sequence**. Currently calls `loadStoredEnvKeys(authStorage)` + `runWizardIfNeeded(authStorage)` before session creation. T02 replaces the wizard call with `shouldRunOnboarding()` + `runOnboarding()`.
- `src/logo.ts` — **Already built (S02 T01)**. Shared `GSD_LOGO` constant + `renderLogo(color)` function. Used by onboarding, postinstall, and loader.
- `src/loader.ts` — **First-launch banner**. Has inline logo copy (S02 branch updated it to use shared logo, but main still has inline). Will be resolved by S02 merge.
- `scripts/postinstall.js` — **S01 branch has clack version; main has raw ANSI version**. Must merge S01 to main to get the branded postinstall.
- `node_modules/@mariozechner/pi-ai/dist/utils/oauth/*.js` — OAuth provider implementations. Anthropic uses code paste (`code#state` format). GitHub Copilot uses device code flow with progress callbacks. Codex/Gemini/Antigravity use local callback servers with `onManualCodeInput`.
- `node_modules/@mariozechner/pi-coding-agent/dist/core/auth-storage.js` — `AuthStorage` class. `login(providerId, callbacks)` is the entry point; it calls the provider's `login()` method and stores the resulting OAuth credentials.
- `node_modules/@mariozechner/pi-coding-agent/dist/modes/interactive/components/login-dialog.js` — TUI login dialog. Reference for browser opening pattern (`exec(openCmd + url)`).

## Constraints

- **Onboarding runs before InteractiveMode** — cannot use any TUI components, must use clack exclusively
- **`@clack/prompts` is a transitive dependency** — not in gsd's direct `dependencies` (only `@mariozechner/pi-coding-agent` and `playwright` are direct deps). Dynamic import works today but is fragile.
- **OAuth providers with callback servers (Codex, Gemini CLI, Antigravity) start a local HTTP server** — `onManualCodeInput` is the fallback if the browser redirect doesn't work. Must handle gracefully.
- **Anthropic OAuth requires `code#state` format** — the provider's `loginAnthropic()` splits on `#`. Clack's `p.text()` returns a plain string, which works.
- **`authStorage.list()` returns provider IDs as strings** — must check against `LLM_PROVIDER_IDS` to distinguish LLM providers from tool key providers (brave, context7, etc.)
- **Three unmerged branches** — S01 (`gsd/M002/S01`), S02 (`gsd/M002/S02`), S03 (`gsd/M002/S03`) all contain independent changes. S02 is based on S01. S03 is based on main. Must merge in order.
- **Non-TTY must skip silently** — `shouldRunOnboarding()` checks `process.stdin.isTTY` and returns false for piped input, subagent, CI contexts
- **`process.env` hydration must happen before extension loading** — `loadStoredEnvKeys()` runs early in cli.ts, before `createAgentSession()`. Extensions rely on env vars like `BRAVE_API_KEY` being set.

## Common Pitfalls

- **Clack raw mode leak** — If an exception occurs during a clack prompt before `outro()` runs, the terminal may be left in raw mode. The `onboarding.ts` wraps the flow in try/catch and calls `p.cancel()` on Ctrl+C (which triggers cleanup), but any uncaught async exception could leak. **Mitigation**: ensure all code paths either call `p.outro()` or `p.cancel()` — the current implementation does this correctly.
- **OAuth browser fails to open** — On headless servers, WSL, or SSH sessions, `exec('open ...')` or `xdg-open` will fail silently. The current implementation handles this: `openBrowser()` ignores errors, and the URL is displayed via `p.log.info()` so the user can manually open it. **Verify**: test on a headless/SSH environment.
- **Empty API key stored as "configured"** — The tool keys step stores `{ type: 'api_key', key: '' }` when the user skips a tool key (to prevent re-prompting). The `loadStoredEnvKeys()` function correctly checks `cred.key` is truthy before setting env, so empty keys don't leak into process.env. But `authStorage.has(provider)` returns true for empty keys — this is by design (skip detection).
- **shouldRunOnboarding false positive with tool-only auth** — If a user only has tool keys (brave, context7) but no LLM auth, `shouldRunOnboarding()` should return true. The current implementation checks `LLM_PROVIDER_IDS.includes(id)` against `authStorage.list()`, which correctly ignores tool-only providers.
- **Duplicate logo on first launch** — `loader.ts` prints a first-launch banner with the logo when `~/.gsd/` doesn't exist. Then `onboarding.ts` also renders the logo. After S02 merge, both use the shared logo — but they'd appear twice on first launch. **Mitigation**: either suppress the loader banner when onboarding will run, or accept the double logo as harmless (it's "setting up" then "welcome").
- **S03 branch divergence** — S03 was branched from main, not from S02. It has its own copy of `src/logo.ts` and the old postinstall. When merging, resolve conflicts carefully — S02's changes to `loader.ts` and `postinstall.js` should win.

## Open Risks

- **Clack → TUI terminal handoff corruption** — The #1 risk. Clack's `outro()` restores cursor visibility and disables raw mode, but doesn't guarantee all ANSI state is flushed. If the TUI's `ProcessTerminal` sees stale escape sequences in the stdin buffer, rendering could be corrupted. **Must be proven via real TTY testing in T03.** No amount of code reading can retire this risk.
- **OAuth provider API changes** — The OAuth providers are in `@mariozechner/pi-ai` (pinned version). If provider endpoints change (Anthropic, GitHub, OpenAI), the flows break. This is a shared risk with pi itself — when pi updates, gsd benefits. Not a gsd-specific risk.
- **Callback server port conflicts** — Codex uses port 1455, Gemini CLI uses its own port. If another process is using that port, the OAuth flow fails. The `onManualCodeInput` fallback handles this, but the error message may be confusing. Low risk — same risk exists in pi's TUI.
- **R012 (first-run onboarding) is not formally in REQUIREMENTS.md** — The CONTEXT.md references R012 but it doesn't exist in the requirements file. Should be added during roadmap planning.

## Candidate Requirements

The following surfaced during research and should be considered for addition to `REQUIREMENTS.md`:

| Candidate | Class | Rationale | Recommendation |
|-----------|-------|-----------|----------------|
| R012: First-run LLM onboarding | launchability | Main UX gap — users install gsd but can't use it without discovering `/login`. M002-CONTEXT already references this. | **Add** — table stakes for the product |
| R013: Branded postinstall output | quality-attribute | `npm install -g gsd-pi` should look professional, not dump raw ASCII. S01 already done. | **Add** — validates S01 work |
| R014: Skip-all onboarding path | resilience | Users must be able to skip everything and configure later. Current impl supports this. | **Add as sub-requirement of R012** — not separate |
| R015: Non-TTY graceful degradation | quality-attribute | CI, piped input, subagent contexts must not crash on onboarding. Already handled. | **Already covered by R009** (failure visibility) |
| R016: `@clack/prompts` as direct dependency | continuity | Currently transitive — could break if pi drops clack | **Advisory** — add to deps during execution, not a requirement |

## Skills Discovered

| Technology | Skill | Status |
|------------|-------|--------|
| @clack/prompts | — | none found |
| OAuth CLI flows | jezweb/claude-skills@oauth-integrations (360 installs) | available — not relevant (generic OAuth, not pi-specific) |
| CLI onboarding wizard | — | none found |

No skills are relevant to install. The work is tightly coupled to pi-coding-agent's AuthStorage API and gsd's specific boot sequence. Generic OAuth skills wouldn't help.

## Sources

- `@clack/prompts` v1.1.0 API: `select`, `password`, `text`, `confirm`, `spinner`, `note`, `intro`, `outro`, `cancel`, `isCancel`, `log.*` — all used in `src/onboarding.ts` (source: node_modules inspection)
- `@clack/core` raw mode handling: sets `setRawMode(true)` during prompts, restores `setRawMode(false)` + stream close on completion (source: node_modules/@clack/core/dist/index.mjs)
- `AuthStorage.login()` callback interface: `OAuthLoginCallbacks` with `onAuth`, `onPrompt`, `onProgress`, `onManualCodeInput` (source: node_modules/@mariozechner/pi-ai/dist/utils/oauth/types.d.ts)
- OAuth provider details: Anthropic (code paste, no callback server), GitHub Copilot (device code, no callback server), Codex (callback server on :1455), Gemini CLI (callback server), Antigravity (callback server) (source: node_modules/@mariozechner/pi-ai/dist/utils/oauth/*.js)
- Browser opening pattern: `exec(open/xdg-open/start + url)` — same in both LoginDialogComponent and onboarding.ts (source: node_modules/@mariozechner/pi-coding-agent/dist/modes/interactive/components/login-dialog.js)
- Provider→env var mapping: `getEnvApiKey()` in pi-ai documents all mappings (source: node_modules/@mariozechner/pi-ai/dist/env-api-keys.js)
- Branch state: S01 (gsd/M002/S01, unmerged to main), S02 (gsd/M002/S02, branched from S01, unmerged), S03 (gsd/M002/S03, branched from main, T01 complete, T02+T03 pending) (source: git log inspection)
